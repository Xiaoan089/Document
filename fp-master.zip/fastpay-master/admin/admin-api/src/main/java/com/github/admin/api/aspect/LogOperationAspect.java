package com.github.admin.api.aspect;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.client.SysLogOperationServiceClient;
import com.github.admin.common.enums.OperationStatusEnum;
import com.github.admin.common.request.SysLogOperationRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.admin.common.utils.HttpContextUtils;
import com.github.admin.common.utils.IpUtils;
import com.github.admin.common.utils.JsonUtils;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

/**
 * 操作日志，切面处理类
 */
@Aspect
@Component
@Slf4j
public class LogOperationAspect {
    @Resource
    private SysLogOperationServiceClient sysLogOperationServiceClient;

    @Pointcut("@annotation(com.github.admin.api.annation.LogOperation)")
    public void logPointCut() {

    }

    @Around("logPointCut()")
    public Object around(ProceedingJoinPoint point) throws Throwable {
        long beginTime = System.currentTimeMillis();
        try {
            //执行方法
            Object result = point.proceed();

            //执行时长(毫秒)
            long time = System.currentTimeMillis() - beginTime;
            //保存日志
            saveLog(point, time, OperationStatusEnum.SUCCESS.value());

            return result;
        } catch (Exception e) {
            //执行时长(毫秒)
            long time = System.currentTimeMillis() - beginTime;
            //保存日志
            saveLog(point, time, OperationStatusEnum.FAIL.value());

            throw e;
        }
    }

    private void saveLog(ProceedingJoinPoint joinPoint, long time, Integer status) throws Exception {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = joinPoint.getTarget().getClass().getDeclaredMethod(signature.getName(), signature.getParameterTypes());
        LogOperation annotation = method.getAnnotation(LogOperation.class);

        SysLogOperationRequest logRequest = new SysLogOperationRequest();
        if (annotation != null) {
            //注解上的描述
            logRequest.setOperation(annotation.value());
            logRequest.setDescription(annotation.description());
            logRequest.setSysType(annotation.sysType());
        }

        //登录用户信息
        UserDetail user = SecurityUser.getUser();
        if (user != null) {
            logRequest.setCreatorName(user.getUsername());
            logRequest.setUserId(user.getId());
        }

        logRequest.setStatus(status);
        logRequest.setRequestTime((int) time);

        //请求相关信息
        HttpServletRequest request = HttpContextUtils.getHttpServletRequest();
        logRequest.setIp(IpUtils.getIpAddr(request));
        logRequest.setUserAgent(request.getHeader(HttpHeaders.USER_AGENT));
        logRequest.setRequestUri(request.getRequestURI());
        logRequest.setRequestMethod(request.getMethod());

        //请求参数
        Object[] args = joinPoint.getArgs();
        try {
            String params = JsonUtils.toJsonString(args[0]);
            logRequest.setRequestParams(params);
        } catch (Exception e) {

        }

        //保存到DB
        Result save = sysLogOperationServiceClient.save(logRequest);
        if (!save.isSuccess()) {
            log.error("保存日志失败,method = {},user = {}",method,user);
            return;
        }
        log.info("保存日志成功!!!!");
    }
}
