package com.github.admin.api.config;

import com.github.admin.api.properties.RedissonClusterProperties;
import com.github.admin.api.properties.RedissonProperties;
import com.github.admin.api.properties.RedissonSentinelProperties;
import com.github.admin.api.properties.RedissonSingletonProperties;
import com.github.admin.common.constant.Constant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.Codec;
import org.redisson.codec.JsonJacksonCodec;
import org.redisson.config.ClusterServersConfig;
import org.redisson.config.Config;
import org.redisson.config.SentinelServersConfig;
import org.redisson.config.SingleServerConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;

import javax.annotation.Resource;
import java.util.List;


@Configuration
@Slf4j
public class RedisConfig {

    /**
     * 设置序列化
     *
     * @param redisConnectionFactory
     * @return
     */
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory);
        Jackson2JsonRedisSerializer jsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);
        redisTemplate.setKeySerializer(RedisSerializer.string());
        redisTemplate.setHashKeySerializer(RedisSerializer.string());
        redisTemplate.setValueSerializer(jsonRedisSerializer);
        redisTemplate.setHashValueSerializer(jsonRedisSerializer);
        return redisTemplate;
    }

    @Resource
    private RedissonProperties redissonProperties;

    @Bean
    public RedissonClient redissonClient() {
        Config config = new Config();
        Codec codec = new JsonJacksonCodec();

        if (redissonProperties == null) {
            log.error("redisson配置异常:创建redissonClient失败");
            return null;
        }

        Integer model = redissonProperties.getModel();
        if (model == null) {
            log.error("redisson配置异常:创建redissonClient失败,modeldel未配置");
            return null;
        }

        if (model.equals(1)) {
            SingleServerConfig singleServerConfig = config.useSingleServer();
            RedissonSingletonProperties properties = redissonProperties.getSingleton();
            singleServerConfig.setAddress(Constant.REDIS_PREFIX + properties.getNode());
            singleServerConfig.setPassword(properties.getPassword());
            singleServerConfig.setDatabase(Integer.valueOf(properties.getDatabase()));
            config.setCodec(codec);
            return Redisson.create(config);
        }

        if (model.equals(2)) {
            SentinelServersConfig sentinelServersConfig = config.useSentinelServers();
            RedissonSentinelProperties properties = redissonProperties.getSentinel();
            sentinelServersConfig.setMasterName(properties.getMaster());
            sentinelServersConfig.setSentinelPassword(properties.getPassword());
            sentinelServersConfig.setSentinelAddresses(sentinelServersConfig.getSentinelAddresses());
            sentinelServersConfig.setDatabase(Integer.valueOf(properties.getDatabase()));
            config.setCodec(codec);
            return Redisson.create(config);
        }

        if (model.equals(2)) {
            ClusterServersConfig clusterServersConfig = config.useClusterServers();
            RedissonClusterProperties redissonClusterProperties = redissonProperties.getCluster();
            clusterServersConfig.setPassword(redissonClusterProperties.getPassword());
            clusterServersConfig.setNodeAddresses(redissonClusterProperties.getNodes());
            config.setCodec(codec);
            return Redisson.create(config);
        }

        log.error("redisson配置异常:创建redissonClient失败,model配置异常,model = {}", model);
        return null;
    }
}
