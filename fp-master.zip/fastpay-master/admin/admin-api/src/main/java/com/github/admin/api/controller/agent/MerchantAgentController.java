package com.github.admin.api.controller.agent;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.client.SysMerchantAgentServiceClient;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantAgentServiceClient;
import com.github.trans.front.client.MerchantServiceClient;
import com.github.trans.front.common.entity.Merchant;
import com.github.trans.front.common.entity.MerchantAgent;
import com.github.trans.front.common.request.MerchantAgentRequest;
import com.github.trans.front.common.request.MerchantRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "代理管理")
public class MerchantAgentController {

    @Resource
    private SysMerchantAgentServiceClient sysMerchantAgentServiceClient;

    @Resource
    private MerchantAgentServiceClient merchantAgentServiceClient;

    @Resource
    private MerchantServiceClient merchantServiceClient;

    @PostMapping("/merchantAgent")
    @RequiresPermissions("sys:merchantagent:save")
    @ApiOperation("保存商户代理")
    @LogOperation(value = "保存",description = "保存商户代理")
    public Result save(@RequestBody @Validated(AddGroup.class) MerchantAgentRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantAgentServiceClient.save(request);
    }

    @GetMapping("/merchantAgent/findAll")
    @ApiOperation("查询所有商户代理")
    public Result<List<MerchantAgent>> findAll() {
        return merchantAgentServiceClient.findAll();
    }

    @GetMapping("/merchantAgent/page")
    @RequiresPermissions("sys:merchantagent:info")
    @ApiOperation("分页查询商户代理")
    public Result<DataPage<MerchantAgent>> page(MerchantAgentRequest request) {
        return sysMerchantAgentServiceClient.page(request);
    }

    @PutMapping("/merchantAgent")
    @ApiOperation("修改商户代理")
    @LogOperation(value = "修改",description = "修改商户代理")
    @RequiresPermissions("sys:merchantagent:update")
    public Result update(@RequestBody @Validated(UpdateGroup.class) MerchantAgentRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantAgentServiceClient.update(request);
    }

    @DeleteMapping("/merchantAgent/delete")
    @ApiOperation("删除商户代理")
    @LogOperation(value = "删除",description = "删除商户代理")
    @RequiresPermissions("sys:merchantagent:delete")
    public Result delete(@RequestBody List<Long> ids) {
        MerchantAgentRequest request = new MerchantAgentRequest();
        request.setUserDetail(SecurityUser.getUser());
        request.setIds(ids);
        return sysMerchantAgentServiceClient.delete(request);
    }

    @GetMapping("/merchantAgent/findById/{id}")
    @ApiOperation("根据id查询商户代理")
    @RequiresPermissions("sys:merchantagent:info")
    public Result<MerchantAgent> findById(@PathVariable("id") Long id) {
        return sysMerchantAgentServiceClient.findById(id);
    }

    @GetMapping("/merchantAgent/findMerchantByAgentId")
    @ApiOperation("根据代理ID查询商户")
    public Result<List<Merchant>> findMerchantByAgentId(MerchantAgentRequest request) {
        return merchantAgentServiceClient.findMerchantByAgentId(request);
    }

    @PutMapping("/merchantAgent/updateAgentPassword")
    @ApiOperation("修改商户代理密码")
    @LogOperation(value = "修改",description = "修改商户代理密码")
    public Result updateAgentPassword(@RequestBody MerchantAgentRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantAgentServiceClient.updateAgentPassword(request);
    }

    @PutMapping("/merchantAgent/updateAgentFundPassword")
    @ApiOperation("修改商户代理资金密码")
    @LogOperation(value = "修改",description = "修改商户代理资金密码")
    public Result updateAgentFundPassword(@RequestBody MerchantAgentRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantAgentServiceClient.updateAgentFundPassword(request);
    }


    @GetMapping("/merchantAgent/findMerchantPageByAgentId/page")
    @ApiOperation("根据代理ID查询直属商户")
    public Result<DataPage<Merchant>> findMerchantPageByAgentId(MerchantRequest request) {
        request.setAgentId(request.getId());
        return merchantServiceClient.page(request);
    }

}
