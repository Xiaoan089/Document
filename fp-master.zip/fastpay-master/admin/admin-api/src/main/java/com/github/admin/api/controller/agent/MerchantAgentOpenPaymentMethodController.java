package com.github.admin.api.controller.agent;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.trans.front.client.MerchantAgentOpenPaymentMethodServiceClient;
import com.github.trans.front.common.request.AgentFeeRequest;
import com.github.trans.front.common.request.MerchantAgentRequest;
import com.github.trans.front.common.response.AgentFeeResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@Api(tags = "代理支付方式")
public class MerchantAgentOpenPaymentMethodController {

    @Resource
    private MerchantAgentOpenPaymentMethodServiceClient merchantAgentOpenPaymentMethodServiceClient;


    @GetMapping("/merchantAgent/open/method/findAgentFeeByAgentId")
    @ApiOperation("根据代理ID查询代理费率")
    public Result<AgentFeeResponse> findAgentFeeByAgentId(MerchantAgentRequest request) {
        return merchantAgentOpenPaymentMethodServiceClient.findAgentFeeByAgentId(request);
    }

    @PutMapping("/merchantAgent/open/method/agentFeeSetting")
    @ApiOperation("修改商户代理费率")
    @LogOperation(value = "修改",description = "保存商户代理费率")
    public Result save(@RequestBody AgentFeeRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return merchantAgentOpenPaymentMethodServiceClient.agentFeeSetting(request);
    }


}
