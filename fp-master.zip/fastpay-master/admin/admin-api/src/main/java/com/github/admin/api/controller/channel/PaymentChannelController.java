package com.github.admin.api.controller.channel;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.PaymentChannelServiceClient;
import com.github.trans.front.common.entity.PaymentChannel;
import com.github.trans.front.common.entity.ThirdChannelAccount;
import com.github.trans.front.common.entity.ThirdChannelAccountRelation;
import com.github.trans.front.common.request.PaymentChannelRequest;
import com.github.trans.front.common.request.ThirdChannelAccountRequest;
import com.github.trans.front.common.response.PaymentChannelAndAccountResponse;
import com.github.trans.front.common.response.ThirdChannelAccountAndMethodResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "支付渠道")
public class PaymentChannelController {

    @Resource
    private PaymentChannelServiceClient paymentChannelServiceClient;

    @GetMapping("/payment/channel/page")
    @RequiresPermissions("sys:paymentchannel:info")
    @ApiOperation("分页查询支付渠道")
    public Result<DataPage<PaymentChannel>> page(PaymentChannelRequest request){
        return paymentChannelServiceClient.page(request);
    }

    @PutMapping("/payment/channel")
    @ApiOperation("修改支付渠道")
    @LogOperation(value = "修改",description = "修改支付渠道")
    @RequiresPermissions("sys:paymentchannel:update")
    public Result update(@RequestBody @Validated(UpdateGroup.class) PaymentChannelRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentChannelServiceClient.update(request);
    }

    @PostMapping("/payment/channel")
    @ApiOperation("保存支付渠道")
    @LogOperation(value = "保存",description = "保存支付渠道")
    @RequiresPermissions("sys:paymentchannel:save")
    public Result save(@RequestBody @Validated(AddGroup.class) PaymentChannelRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentChannelServiceClient.save(request);
    }

    @DeleteMapping("/payment/channel/delete")
    @ApiOperation("删除支付渠道")
    @LogOperation(value = "删除",description = "删除支付渠道")
    @RequiresPermissions("sys:paymentchannel:delete")
    public Result delete(@RequestBody List<Long> ids){
        PaymentChannelRequest request = new PaymentChannelRequest();
        request.setIds(ids);
        request.setUserDetail(SecurityUser.getUser());
        return paymentChannelServiceClient.delete(request);
    }

    @GetMapping("/payment/channel/findById/{id}")
    @ApiOperation("根据ID查询支付渠道")
    @RequiresPermissions("sys:paymentchannel:info")
    public Result<PaymentChannel> findById(@PathVariable("id") Long id) {
        return paymentChannelServiceClient.findById(id);
    }

    @GetMapping("/payment/channel/findChannelAccountByChannrlId/{id}")
    @ApiOperation("根据支付渠道ID查询渠道对应的支付账号")
    @RequiresPermissions("sys:paymentchannel:info")
    public Result<ThirdChannelAccountAndMethodResponse> findChannelAccountByChannelId(@PathVariable("id") Long id){
        PaymentChannelRequest request = new PaymentChannelRequest();
        request.setId(id);
        return paymentChannelServiceClient.findChannelAccountByChannelId(request);
    }

    @GetMapping("/payment/channel/findChannelAndAccount")
    @ApiOperation("查询所有支付渠道和渠道账号")
    public Result<PaymentChannelAndAccountResponse> findChannelAndAccount(){
        return paymentChannelServiceClient.findChannelAndAccount();
    }

    @PutMapping("/payment/channel/updateStatus")
    @ApiOperation("修改支付渠道状态")
    @LogOperation(value = "修改",description = "修改支付渠道状态")
    public Result updateStatus(@RequestBody PaymentChannelRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentChannelServiceClient.updateStatus(request);
    }

    @GetMapping("/payment/channel/findNotBindChannel/{id}")
    @ApiOperation("根据渠道ID查询未绑定渠道的三方账号")
    public Result<List<ThirdChannelAccount>> findNotBindChannel(@PathVariable("id") Long id){
        return paymentChannelServiceClient.findNotBindChannel(id);
    }


    @GetMapping("/payment/channel/findBindChannelAccount/{id}")
    @ApiOperation("根据渠道ID查询渠道对应的三方账号")
    public Result<List<ThirdChannelAccountRelation>> findBindChannelAccount(@PathVariable("id") Long id){
        return paymentChannelServiceClient.findBindChannelAccount(id);
    }


    @PostMapping("/payment/channel/saveChannelAndChannelAccount")
    @ApiOperation("保存渠道和渠道对应的账号")
    @LogOperation(value = "保存",description = "保存渠道和渠道对应的账号")
    public Result saveChannelAndChannelAccount(@RequestBody PaymentChannelRequest request){
        return paymentChannelServiceClient.saveChannelAndChannelAccount(request);
    }


    @DeleteMapping("/payment/channel/deleteChannelAndChannelAccount")
    @ApiOperation("移除渠道和渠道对应的账号")
    @LogOperation(value = "删除",description = "删除渠道和渠道对应的账号")
    public Result deleteChannelAndChannelAccount(@RequestBody PaymentChannelRequest request){
        return paymentChannelServiceClient.deleteChannelAndChannelAccount(request);
    }


}
