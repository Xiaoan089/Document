package com.github.admin.api.controller.channel;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.PaymentChannelTypeServiceClient;
import com.github.trans.front.common.entity.PaymentChannelType;
import com.github.trans.front.common.request.PaymentChannelTypeRequest;
import com.github.trans.front.common.response.ChannelAccountResonse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "支付渠道类型")
public class PaymentChannelTypeController {

    @Resource
    private PaymentChannelTypeServiceClient paymentChannelTypeServiceClient;

    @GetMapping("/payment/channel/type/page")
    @RequiresPermissions("sys:paymentChannelType:info")
    @ApiOperation("分页查询支付渠道类型")
    public Result<DataPage<PaymentChannelType>> page(PaymentChannelTypeRequest request){
        return paymentChannelTypeServiceClient.page(request);
    }

    @PutMapping("/payment/channel/type")
    @RequiresPermissions("sys:paymentChannelType:update")
    @ApiOperation("修改支付渠道类型")
    @LogOperation(value = "修改",description = "修改支付渠道类型")
    public Result update(@RequestBody @Validated({UpdateGroup.class}) PaymentChannelTypeRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentChannelTypeServiceClient.update(request);
    }

    @PostMapping("/payment/channel/type")
    @RequiresPermissions("sys:paymentChannelType:save")
    @ApiOperation("保存支付渠道类型")
    @LogOperation(value = "保存",description = "保存支付渠道类型")
    public Result save(@RequestBody @Validated({AddGroup.class})PaymentChannelTypeRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentChannelTypeServiceClient.save(request);
    }

    @DeleteMapping("/payment/channel/type/delete")
    @RequiresPermissions("sys:paymentChannelType:delete")
    @ApiOperation("删除支付渠道类型")
    @LogOperation(value = "删除",description = "删除支付渠道类型")
    public Result delete(@RequestBody List<Long> ids){
        return paymentChannelTypeServiceClient.delete(ids);
    }

    @GetMapping("/payment/channel/type/findById/{id}")
    @ApiOperation("根据支付渠道类型ID查询支付渠道类型")
    @RequiresPermissions("sys:paymentChannelType:info")
    public Result<PaymentChannelType> findById(@PathVariable("id") Long id) {
        return paymentChannelTypeServiceClient.findById(id);
    }

    @GetMapping("/payment/channel/type/findAll")
    @ApiOperation("查询所有支付渠道类型")
    public Result<List<PaymentChannelType>> findAll(){
        return paymentChannelTypeServiceClient.findAll();
    }


}
