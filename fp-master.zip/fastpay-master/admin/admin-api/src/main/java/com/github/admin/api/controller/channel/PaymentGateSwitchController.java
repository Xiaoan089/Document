package com.github.admin.api.controller.channel;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.PaymentGateSwitchServiceClient;
import com.github.trans.front.common.entity.PaymentGateSwitch;
import com.github.trans.front.common.request.PaymentGateSwitchRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "支付网关总开关")
public class PaymentGateSwitchController {

    @Resource
    private PaymentGateSwitchServiceClient paymentGateSwitchServiceClient;

    @GetMapping("/payment/gate/switch/page")
    @RequiresPermissions("sys:paymentgateswitch:info")
    @ApiOperation("分页查询支付网关总开关")
    public Result<DataPage<PaymentGateSwitch>> page(PaymentGateSwitchRequest request){
        return paymentGateSwitchServiceClient.page(request);
    }

    @PutMapping("/payment/gate/switch")
    @ApiOperation("修改支付网关总开关")
    @LogOperation(value = "修改",description = "修改支付网关总开关")
    @RequiresPermissions("sys:paymentgateswitch:update")
    public Result update(@RequestBody @Validated(UpdateGroup.class) PaymentGateSwitchRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentGateSwitchServiceClient.update(request);
    }

    @PostMapping("/payment/gate/switch")
    @RequiresPermissions("sys:paymentgateswitch:save")
    @ApiOperation("保存支付网关总开关")
    @LogOperation(value = "保存",description = "保存支付网关总开关")
    public Result save(@RequestBody @Validated(AddGroup.class) PaymentGateSwitchRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentGateSwitchServiceClient.save(request);
    }

    @DeleteMapping("/payment/gate/switch/delete")
    @ApiOperation("删除支付网关总开关")
    @RequiresPermissions("sys:paymentgateswitch:delete")
    @LogOperation(value = "删除",description = "删除支付网关总开关")
    public Result delete(@RequestBody List<Long> ids){
        PaymentGateSwitchRequest request = new PaymentGateSwitchRequest();
        request.setIds(ids);
        return paymentGateSwitchServiceClient.delete(request);
    }

    @GetMapping("/payment/gate/switch/findById/{id}")
    @ApiOperation("根据id查询支付网关总开关")
    @RequiresPermissions("sys:paymentgateswitch:info")
    public Result findById(@PathVariable("id") Long id){
        return paymentGateSwitchServiceClient.findById(id);
    }

}
