package com.github.admin.api.controller.channel;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.PaymentMethodServiceClient;
import com.github.trans.front.common.entity.PaymentMethod;
import com.github.trans.front.common.request.PaymentMethodRequest;
import com.github.trans.front.common.response.PaymentMethodResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "支付方式")
public class PaymentMethodController {

    @Resource
    private PaymentMethodServiceClient paymentMethodServiceClient;

    @GetMapping("/payment/method/findAll")
    @ApiOperation("查询所有支付方式")
    public Result<PaymentMethodResponse> findAll(){
        return paymentMethodServiceClient.findAll();
    }

    @GetMapping("/payment/method/findByPayDirection")
    @ApiOperation("根据支付方向查询支付方式")
    public Result<List<PaymentMethod>> findByPayDirection(PaymentMethodRequest request){
        return paymentMethodServiceClient.findByPayDirection(request);
    }

    @PostMapping("/payment/method")
    @RequiresPermissions("sys:paymentmethod:save")
    @ApiOperation("保存支付方式")
    @LogOperation(value = "保存",description = "保存支付方式")
    public Result save(@RequestBody @Validated(AddGroup.class)PaymentMethodRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentMethodServiceClient.save(request);
    }

    @PutMapping("/payment/method")
    @RequiresPermissions("sys:paymentmethod:update")
    @ApiOperation("修改支付方式")
    @LogOperation(value = "修改",description = "修改支付方式")
    public Result update(@RequestBody @Validated(UpdateGroup.class)PaymentMethodRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return paymentMethodServiceClient.update(request);
    }

    @GetMapping("/payment/method/{id}")
    @ApiOperation("根据id查询支付方式")
    @RequiresPermissions("sys:paymentmethod:info")
    public Result<PaymentMethod> findById(@PathVariable("id") Long id) {
        return paymentMethodServiceClient.findById(id);
    }

    @DeleteMapping("/payment/method/delete")
    @RequiresPermissions("sys:paymentmethod:delete")
    @ApiOperation("删除支付方式")
    @LogOperation(value = "删除",description = "删除支付方式")
    public Result delete(@RequestBody List<Long> ids){
        PaymentMethodRequest request = new PaymentMethodRequest();
        request.setIds(ids);
        return paymentMethodServiceClient.delete(request);
    }

    @GetMapping("/payment/method/page")
    @ApiOperation("分页查询支付方式")
    @RequiresPermissions("sys:paymentmethod:page")
    public Result<DataPage<PaymentMethod>> page(PaymentMethodRequest request){
        return paymentMethodServiceClient.page(request);
    }


}
