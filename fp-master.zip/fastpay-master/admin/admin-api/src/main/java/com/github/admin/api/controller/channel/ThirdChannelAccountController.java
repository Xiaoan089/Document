package com.github.admin.api.controller.channel;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.ThirdChannelAccountServiceClient;
import com.github.trans.front.common.entity.ThirdChannelAccount;
import com.github.trans.front.common.request.ThirdChannelAccountRequest;
import com.github.trans.front.common.response.MerchantGroupAndMethoidResponse;
import com.github.trans.front.common.response.ThirdAccountMethodResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "三方渠道账号")
public class ThirdChannelAccountController {

    @Resource
    private ThirdChannelAccountServiceClient thirdChannelAccountServiceClient;

    @GetMapping("/thirdchannelaccount/page")
    @ApiOperation("分页查询三方渠道账号")
    @RequiresPermissions("sys:thirdchannelaccount:info")
    public Result<DataPage<ThirdChannelAccount>> page(ThirdChannelAccountRequest request){
        return thirdChannelAccountServiceClient.page(request);
    }

    @PutMapping("/thirdchannelaccount")
    @ApiOperation("修改三方渠道账号")
    @LogOperation(value = "修改",description = "修改三方渠道账号")
    @RequiresPermissions("sys:thirdchannelaccount:update")
    public Result update(@RequestBody ThirdChannelAccountRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return thirdChannelAccountServiceClient.update(request);
    }

    @PutMapping("/thirdchannelaccount/updateStatus")
    @ApiOperation("修改三方渠道状态")
    @LogOperation(value = "修改",description = "修改三方渠道状态")
    @RequiresPermissions("sys:thirdchannelaccount:update")
    public Result updateStatus(@RequestBody ThirdChannelAccountRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return thirdChannelAccountServiceClient.updateStatus(request);
    }

    @PostMapping("/thirdchannelaccount")
    @ApiOperation("保存三方渠道账号")
    @LogOperation(value = "保存",description = "保存三方渠道账号")
    @RequiresPermissions("sys:thirdchannelaccount:save")
    public Result save(@RequestBody @Validated(AddGroup.class) ThirdChannelAccountRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return thirdChannelAccountServiceClient.save(request);
    }

    @DeleteMapping("/thirdchannelaccount/delete")
    @ApiOperation("删除三方渠道账号")
    @LogOperation(value = "删除",description = "删除三方渠道账号")
    @RequiresPermissions("sys:thirdchannelaccount:delete")
    public Result delete(@RequestBody List<Long> ids){
        ThirdChannelAccountRequest request = new ThirdChannelAccountRequest();
        request.setIds(ids);
        request.setUserDetail(SecurityUser.getUser());
        return thirdChannelAccountServiceClient.delete(request);
    }

    @GetMapping("/thirdchannelaccount/findById/{id}")
    @ApiOperation("根据ID查询三方渠道账号")
    @RequiresPermissions("sys:thirdchannelaccount:info")
    public Result<ThirdChannelAccount> findById(@PathVariable("id") Long id) {
        return thirdChannelAccountServiceClient.findById(id);
    }

    @GetMapping("/thirdchannelaccount/findGroupAndMethod")
    @ApiOperation("添加支付账号时查询商户分组和支付方式")
    public Result<MerchantGroupAndMethoidResponse> findGroupAndMethod() {
        return thirdChannelAccountServiceClient.findGroupAndMethod();
    }

    @GetMapping("/thirdchannelaccount/findThirdChannelAccountMethodByAccountId/{id}")
    @ApiOperation("根据支付账号id查询支付方式")
    public Result<ThirdAccountMethodResponse> findThirdChannelAccountMethodByAccountId(@PathVariable("id") Long id) {
        return thirdChannelAccountServiceClient.findThirdChannelAccountMethodByAccountId(id);
    }

    @PutMapping("/thirdchannelaccount/updateGroupByAccountId")
    @ApiOperation("修改三方渠道对应的商户分组")
    @LogOperation(value = "修改",description = "修改三方渠道对应的商户分组")
    public Result updateGroupByAccountId(@RequestBody ThirdChannelAccountRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return thirdChannelAccountServiceClient.updateGroupByAccountId(request);
    }

    @PutMapping("/thirdchannelaccount/updateAccountMethod")
    @ApiOperation("修改三方渠道账号对应的支付方式")
    @LogOperation(value = "修改",description = "修改三方渠道账号对应的支付方式")
    public Result updateAccountMethod(@RequestBody ThirdChannelAccountRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return thirdChannelAccountServiceClient.updateAccountMethod(request);
    }

    @GetMapping("/thirdchannelaccount/findThirdChannelAccountFeeByAccountId/{id}")
    @ApiOperation("根据支付账号id查询费率")
    public Result<ThirdAccountMethodResponse> findThirdChannelAccountFeeByAccountId(@PathVariable("id") Long id) {
        return thirdChannelAccountServiceClient.findThirdChannelAccountFeeByAccountId(id);
    }

}
