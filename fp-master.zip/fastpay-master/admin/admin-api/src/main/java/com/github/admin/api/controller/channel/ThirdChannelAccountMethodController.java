package com.github.admin.api.controller.channel;

import com.github.framework.core.Result;
import com.github.trans.front.client.ThirdChannelAccountMethodServicedClient;
import com.github.trans.front.common.entity.ThirdChannelAccountMethod;
import com.github.trans.front.common.request.ThirdChannelAccountMethodRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "三方渠道账号的支付方式")
public class ThirdChannelAccountMethodController {

    @Resource
    private ThirdChannelAccountMethodServicedClient thirdChannelAccountMethodServicedClient;


    @GetMapping("/thirdChannelAccountMethod/findByThirdChannelAccount")
    @ApiOperation("根据三方渠道账号ID查询支付方式")
    public Result<List<ThirdChannelAccountMethod>> findByThirdChannelAccount(ThirdChannelAccountMethodRequest request){
        return thirdChannelAccountMethodServicedClient.findByThirdChannelAccount(request);
    }

}
