package com.github.admin.api.controller.channel;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.ThirdChannelTradeInServiceClient;
import com.github.trans.front.common.entity.ThirdChannelTradeIn;
import com.github.trans.front.common.request.ThirdChannelTradeInRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@Api(tags = "三方渠道代收交易流水")
public class ThirdChannelTradeInController {

    @Resource
    private ThirdChannelTradeInServiceClient thirdChannelTradeInServiceClient;

    @GetMapping("/thirdChannelTradeIn/page")
    @ApiOperation("分页查询三方渠道代收交易流水")
    @RequiresPermissions("sys:thirdchanneltradein:info")
    public Result<DataPage<ThirdChannelTradeIn>> page(ThirdChannelTradeInRequest request) {
        return thirdChannelTradeInServiceClient.page(request);
    }

    @GetMapping("/thirdChannelTradeIn/findById/{tradeNo}")
    @ApiOperation("根据交易号查询三方渠道代收交易流水")
    @RequiresPermissions("sys:thirdchanneltradein:info")
    public Result<ThirdChannelTradeIn> findByTradeNo(@PathVariable("tradeNo") String tradeNo) {
        return thirdChannelTradeInServiceClient.findByTradeNo(tradeNo);
    }
}
