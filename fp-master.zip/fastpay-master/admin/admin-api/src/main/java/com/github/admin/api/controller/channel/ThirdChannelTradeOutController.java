package com.github.admin.api.controller.channel;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;;
import com.github.trans.front.client.ThirdChannelTradeOutServiceClient;
import com.github.trans.front.common.entity.ThirdChannelTradeOut;
import com.github.trans.front.common.request.ThirdChannelTradeOutRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@Api(tags = "三方渠道代付交易流水")
public class ThirdChannelTradeOutController {

    @Resource
    private ThirdChannelTradeOutServiceClient thirdChannelTradeOutServiceClient;

    @GetMapping("/thirdChannelTradeOut/page")
    @ApiOperation("分页查询三方渠道代付交易流水")
    @RequiresPermissions("sys:thirdchanneltradeout:info")
    public Result<DataPage<ThirdChannelTradeOut>> page(ThirdChannelTradeOutRequest request) {
        return thirdChannelTradeOutServiceClient.page(request);
    }

    @GetMapping("/thirdChannelTradeOut/findById/{tradeNo}")
    @ApiOperation("分页查询三方渠道代付交易流水")
    @RequiresPermissions("sys:thirdchanneltradeout:info")
    public Result<ThirdChannelTradeOut> findById(@PathVariable("tradeNo") String tradeNo) {
        return thirdChannelTradeOutServiceClient.findByTradeNo(tradeNo);
    }
}
