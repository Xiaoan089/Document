package com.github.admin.api.controller.channel;

import com.github.framework.core.Result;
import com.github.trans.front.client.ThirdNotifyServiceClient;
import com.github.trans.front.common.entity.ThirdNotify;
import com.github.trans.front.common.request.ThirdNotifyRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "三方回调记录")
public class ThirdNotifyController {

    @Resource
    private ThirdNotifyServiceClient thirdNotifyServiceClient;


    @GetMapping("/thind/notify/findList")
    @ApiOperation("查询三方回调记录")
    public Result<List<ThirdNotify>> findList(ThirdNotifyRequest request) {
        return thirdNotifyServiceClient.findList(request);
    }

}
