package com.github.admin.api.controller.channel;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.ThirdPaymentOperationLogServiceClient;
import com.github.trans.front.common.entity.ThirdPaymentOperationLog;
import com.github.trans.front.common.request.ThirdPaymentOperationLogRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@Api(tags = "支付操作日志")
public class ThirdPaymentOperationLogController {


    @Resource
    private ThirdPaymentOperationLogServiceClient thirdPaymentOperationLogServiceClient;


    @GetMapping("/third/payment/operation/log/page")
    @ApiOperation("分页查询支付操作日志")
    public Result<DataPage<ThirdPaymentOperationLog>> page(ThirdPaymentOperationLogRequest request){
        return thirdPaymentOperationLogServiceClient.page(request);
    }



}
