package com.github.admin.api.controller.merchant;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.admin.client.SysMerchantServiceClient;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantServiceClient;
import com.github.trans.front.common.entity.Merchant;
import com.github.trans.front.common.entity.MerchantIpWhitelist;
import com.github.trans.front.common.request.MerchantDepositOrderRequest;
import com.github.trans.front.common.request.MerchantRequest;
import com.github.trans.front.common.request.MerchantWithdrawOrderRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户")
public class MerchantController {

    @Resource
    private SysMerchantServiceClient sysMerchantServiceClient;

    @Resource
    private MerchantServiceClient merchantServiceClient;

    @PostMapping("/merchant")
    @ApiOperation("保存商户")
    @RequiresPermissions("sys:merchant:save")
    public Result save(@RequestBody MerchantRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantServiceClient.save(request);
    }

    @PutMapping("/merchant")
    @ApiOperation("修改商户")
    @LogOperation(value = "修改",description = "修改商户")
    @RequiresPermissions("sys:merchant:update")
    public Result update(@RequestBody MerchantRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantServiceClient.update(request);
    }


    @GetMapping("/merchant/page")
    @ApiOperation("分页查询商户")
    @RequiresPermissions("sys:merchant:info")
    public Result<DataPage<Merchant>> page(MerchantRequest request){
        return sysMerchantServiceClient.page(request);
    }

    @DeleteMapping("/merchant/delete")
    @ApiOperation("删除商户")
    @LogOperation(value = "删除",description = "删除商户")
    @RequiresPermissions("sys:merchant:delete")
    public Result delete(@RequestBody List<Long> ids){
        MerchantRequest request = new MerchantRequest();
        request.setUserDetail(SecurityUser.getUser());
        request.setIds(ids);
        return sysMerchantServiceClient.delete(request);
    }

    @GetMapping("/merchant/findById/{id}")
    @ApiOperation("根据id查询商户")
    @RequiresPermissions("sys:merchant:info")
    public Result<Merchant> findById(@PathVariable("id") Long id) {
        return sysMerchantServiceClient.findById(id);
    }

    @GetMapping("/merchant/findIpWhitelist")
    @ApiOperation("查询商户白名单")
    public Result<List<MerchantIpWhitelist>> findIpWhitelist(MerchantRequest request) {
        return merchantServiceClient.findIpWhitelist(request);
    }

    @GetMapping("/merchant/findMerchantNotBindGroup")
    @ApiOperation("查询未绑定商户分组的商户")
    public Result<List<Merchant>> findMerchantNotBindGroup() {
        return merchantServiceClient.findMerchantNotBindGroup();
    }

    @DeleteMapping("/merchant/deleteMerchantGroupRelation")
    @ApiOperation("移除商户和商户分组中间表")
    @LogOperation(value = "删除",description = "删除商户和商户分组中间表")
    public Result deleteMerchantGroupRelation(@RequestBody MerchantRequest request) {
        return merchantServiceClient.deleteMerchantGroupRelation(request);
    }

    @PutMapping("/merchant/updatePassword")
    @ApiOperation("修改商户密码")
    @LogOperation(value = "修改",description = "修改商户密码")
    public Result updatePassword(@RequestBody MerchantRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantServiceClient.updatePassword(request);
    }

    @PutMapping("/merchant/updateFundPassword")
    @ApiOperation("修改商户资金密码")
    @LogOperation(value = "修改",description = "修改商户资金密码")
    public Result updateFundPassword(@RequestBody MerchantRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysMerchantServiceClient.updateFundPassword(request);
    }

    @PutMapping("/merchant/updateMerchantGroupRelation")
    @ApiOperation("修改商户分组")
    @LogOperation(value = "修改",description = "修改商户分组")
    public Result updateMerchantGroupRelation(@RequestBody MerchantRequest request) {
        return merchantServiceClient.updateMerchantGroupRelation(request);
    }

    @PostMapping("/merchant/depositorder")
    @ApiOperation("保存商户充值")
    @LogOperation(value = "保存",description = "保存商户提现")
    public Result depositorder(@RequestBody MerchantDepositOrderRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return merchantServiceClient.depositorder(request);
    }

    @PutMapping("/merchant/depositorder")
    @ApiOperation("修改商户充值")
    @LogOperation(value = "修改",description = "修改商户充值")
    public Result updateDepositorder(@RequestBody MerchantDepositOrderRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return merchantServiceClient.updateDepositorder(request);
    }

    @PostMapping("/merchant/withdrawOrder")
    @ApiOperation("保存商户提现")
    @LogOperation(value = "保存",description = "保存商户提现")
    public Result saveWithdrawOrder(@RequestBody MerchantWithdrawOrderRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return merchantServiceClient.saveWithdrawOrder(request);
    }

    @PutMapping("/merchant/withdrawOrder")
    @ApiOperation("修改商户提现")
    @LogOperation(value = "修改",description = "修改商户提现")
    public Result updateWithdrawOrder(@RequestBody MerchantWithdrawOrderRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return merchantServiceClient.updateWithdrawOrder(request);
    }
}
