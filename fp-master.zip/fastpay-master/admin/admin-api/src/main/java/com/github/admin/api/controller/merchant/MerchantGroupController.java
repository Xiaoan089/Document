package com.github.admin.api.controller.merchant;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantGroupServiceClient;
import com.github.trans.front.common.entity.Merchant;
import com.github.trans.front.common.entity.MerchantGroup;
import com.github.trans.front.common.entity.ThirdChannelAccountRelation;
import com.github.trans.front.common.request.ChannelAccountTypeRequest;
import com.github.trans.front.common.request.MerchantGroupRequest;
import com.github.trans.front.common.request.ThirdChannelAccountRelationRequest;
import com.github.trans.front.common.response.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户分组")
public class MerchantGroupController {

    @Resource
    private MerchantGroupServiceClient merchantGroupServiceClient;

    @GetMapping("/merchant/group/findAll")
    @ApiOperation("查询所有商户分组")
    public Result<List<MerchantGroup>> findAll(){
        return merchantGroupServiceClient.findAll();
    }

    @GetMapping("/merchant/group/page")
    @ApiOperation("分页查询商户分组")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true)
    })
    public Result<DataPage<MerchantGroup>> page(MerchantGroupRequest request){
        return merchantGroupServiceClient.page(request);
    }

    @PostMapping("/merchant/group")
    @ApiOperation("保存商户分组")
    @Parameters({
            @Parameter(name = "groupName", description = "名称", required = true),
            @Parameter(name = "merchantList", description = "商户集合", required = true),
            @Parameter(name = "channelTypeList", description = "商户分组对应支付渠道类型", required = true),
            @Parameter(name = "id", description = "商户分组对应支付渠道类型ID", required = true),
            @Parameter(name = "paymentTypeInchecked", description = "商户分组对应代收支付渠道是否选中", required = true)
    })
    @LogOperation(value = "保存",description = "保存商户分组")
    public Result save(@RequestBody @Validated(AddGroup.class) ChannelAccountTypeRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return merchantGroupServiceClient.save(request);
    }

    @PutMapping("/merchant/group")
    @ApiOperation("修改商户分组")
    @Parameters({
            @Parameter(name = "id", description = "分组id", required = true),
            @Parameter(name = "groupName", description = "名称", required = true),
    })
    @LogOperation(value = "修改",description = "修改商户分组")
    public Result update(@RequestBody @Validated(UpdateGroup.class) ChannelAccountTypeRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return merchantGroupServiceClient.update(request);
    }

    @DeleteMapping("/merchant/group/delete")
    @ApiOperation("删除商户分组")
    @LogOperation(value = "删除",description = "删除商户分组")
    public Result delete(@RequestBody List<Long> ids){
        MerchantGroupRequest request = new MerchantGroupRequest();
        request.setIds(ids);
        request.setUserDetail(SecurityUser.getUser());
        return merchantGroupServiceClient.delete(request);
    }

    @GetMapping("/merchant/group/findMerchantByGroupId")
    @ApiOperation("根据分组ID分页查询商户")
    public Result<DataPage<Merchant>> findMerchantByGroupId(MerchantGroupRequest request) {
        return merchantGroupServiceClient.findMerchantByGroupId(request);
    }

    // 新增

    @GetMapping("/merchant/group/findPaymentChannelType")
    @ApiOperation("新增商户分组时查询支付渠道类型")
    public Result<ChannelTypeResponse> findPaymentChannelType(){
        return merchantGroupServiceClient.findPaymentChannelType();
    }

    @GetMapping("/merchant/group/findPaymentChannelByChannelTypeId")
    @ApiOperation("新增商户分组时查询支付渠道")
    public Result<PaymentChannelTypeResponse> findPaymentChannelByChannelTypeId(ThirdChannelAccountRelationRequest request){
        return merchantGroupServiceClient.findPaymentChannelByChannelTypeId(request);
    }


    @GetMapping("/merchant/group/findPaymentChannelAccount")
    @ApiOperation("查询支付渠道对应的渠道账号")
    public Result<List<ThirdChannelAccountRelation>> findPaymentChannelAccount(ThirdChannelAccountRelationRequest request){
        return merchantGroupServiceClient.findPaymentChannelAccount(request);
    }

    //修改

    @GetMapping("/merchant/group/findById/{id}")
    @ApiOperation("根据id查询商户分组")
    public Result<MerchantGroupResponse> findById(@PathVariable("id") Long id) {
        return merchantGroupServiceClient.findById(id);
    }

    @GetMapping("/merchant/group/findPaymentChannelByChannelTypeIdIsChecked")
    @ApiOperation("修改商户分组时查询支付渠道,并且判断是否选中")
    public Result<PaymentChannelTypeResponse> findPaymentChannelByChannelTypeIdIsChecked(ThirdChannelAccountRelationRequest request){
        return merchantGroupServiceClient.findPaymentChannelByChannelTypeIdIsChecked(request);
    }

    @GetMapping("/merchant/group/findPaymentChannelAccountIsChecked")
    @ApiOperation("修改查询支付渠道对应的渠道账号,并且判断是否选中")
    public Result<List<ThirdChannelAccountRelation>> findPaymentChannelAccountIsChecked(ThirdChannelAccountRelationRequest request){
        return merchantGroupServiceClient.findPaymentChannelAccountIsChecked(request);
    }

}
