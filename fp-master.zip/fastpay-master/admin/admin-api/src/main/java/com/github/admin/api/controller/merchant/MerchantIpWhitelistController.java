package com.github.admin.api.controller.merchant;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantIpWhitelistServiceClient;
import com.github.trans.front.common.entity.MerchantIpWhitelist;
import com.github.trans.front.common.request.MerchantIpWhitelistRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户白名单")
public class MerchantIpWhitelistController {

    @Resource
    private MerchantIpWhitelistServiceClient merchantIpWhitelistServiceClient;

    @GetMapping("/merchantIpWhitelist/page")
    @ApiOperation("分页查询商户白名单")
    public Result<DataPage<MerchantIpWhitelist>> page(MerchantIpWhitelistRequest request){
        return merchantIpWhitelistServiceClient.page(request);
    }

    @PostMapping("/merchantIpWhitelist")
    @ApiOperation("保存商户白名单")
    @LogOperation(value = "保存",description = "保存商户白名单")
    public Result save(@RequestBody MerchantIpWhitelistRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return merchantIpWhitelistServiceClient.save(request);
    }

    @PutMapping("/merchantIpWhitelist")
    @ApiOperation("修改商户白名单")
    @LogOperation(value = "修改",description = "修改商户白名单")
    public Result update(@RequestBody MerchantIpWhitelistRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return merchantIpWhitelistServiceClient.update(request);
    }

    @DeleteMapping("/merchantIpWhitelist/delete")
    @ApiOperation("删除商户白名单")
    @LogOperation(value = "删除",description = "删除商户白名单")
    public Result delete(@RequestBody List<Long> ids){
        MerchantIpWhitelistRequest request = new MerchantIpWhitelistRequest();
        request.setUserDetail(SecurityUser.getUser());
        request.setIds(ids);
        return merchantIpWhitelistServiceClient.delete(request);
    }

    @GetMapping("/merchantIpWhitelist/findById/{id}")
    @ApiOperation("根据ID查询商户白名单")
    public Result<MerchantIpWhitelist> findById(@PathVariable("id") Long id) {
        return merchantIpWhitelistServiceClient.findById(id);
    }
}
