package com.github.admin.api.controller.merchant;

import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.trans.front.client.MerchantNotifyServiceClient;
import com.github.trans.front.common.entity.MerchantNotify;
import com.github.trans.front.common.request.MerchantNotifyRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户代收代付回调记录")
public class MerchantNotifyController {


    @Resource
    private MerchantNotifyServiceClient merchantNotifyServiceClient;

    @ApiOperation("查询商户回调记录")
    @GetMapping("/merchant/notify/findMercahntNotifyList")
    public Result<List<MerchantNotify>> findMercahntNotifyList(MerchantNotifyRequest request){
        return merchantNotifyServiceClient.findMercahntNotifyList(request);
    }

    @ApiOperation("批量通知商户")
    @PostMapping("/merchant/notify/batchNotify")
    Result batchNotify(@RequestBody MerchantNotifyRequest request) {
        request.setModifiedUser(SecurityUser.getUser().getUsername());
        return merchantNotifyServiceClient.batchNotify(request);
    }
}
