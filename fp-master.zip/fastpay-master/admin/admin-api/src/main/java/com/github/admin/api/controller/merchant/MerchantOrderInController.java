package com.github.admin.api.controller.merchant;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantOrderInServiceClient;
import com.github.trans.front.common.entity.MerchantOrderIn;
import com.github.trans.front.common.entity.ThirdChannelTradeIn;
import com.github.trans.front.common.request.MerchantOrderInRequest;
import com.github.trans.front.common.response.MerchantOrderInProfitDetailsResponse;
import com.github.trans.front.common.response.PaymentCollectionMakeUpResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户代收订单")
public class MerchantOrderInController {

    @Resource
    private MerchantOrderInServiceClient merchantOrderInServiceClient;

    @GetMapping("/merchantOrderIn/page")
    @ApiOperation("分页查询商户代收订单")
    public Result<DataPage<MerchantOrderIn>> page(MerchantOrderInRequest request) {
        return merchantOrderInServiceClient.page(request);
    }

    @ApiOperation("批量代收失败")
    @PostMapping("/merchantOrderIn/fail")
    @LogOperation(value = "批量代收失败",description = "批量代收失败")
    Result fail(@RequestBody MerchantOrderInRequest request) {
        request.setModifiedUser(SecurityUser.getUser().getUsername());
        return merchantOrderInServiceClient.fail(request);
    }

    @ApiOperation("批量代收成功")
    @PostMapping("/merchantOrderIn/success")
    @LogOperation(value = "批量代收成功",description = "批量代收成功")
    Result success(@RequestBody MerchantOrderInRequest request) {
        request.setModifiedUser(SecurityUser.getUser().getUsername());
        return merchantOrderInServiceClient.success(request);
    }

    @GetMapping("/merchantOrderIn/payment/details")
    @ApiOperation("查询商户代收订单支付详情")
    public Result<List<ThirdChannelTradeIn>> paymentDetails(MerchantOrderInRequest request) {
        return merchantOrderInServiceClient.paymentDetails(request);
    }

    @GetMapping("/merchantOrderIn/profit/details")
    @ApiOperation("查询商户代收订单利润详情")
    public Result<MerchantOrderInProfitDetailsResponse> profitDetails(MerchantOrderInRequest request) {
        return merchantOrderInServiceClient.profitDetails(request);
    }

    @PostMapping("/merchantOrderIn/makeUp/beFore")
    @ApiOperation("代收补单")
    @LogOperation(value = "补单",description = "代收补单")
    public Result<PaymentCollectionMakeUpResponse> makeUpBeFore(@RequestBody MerchantOrderInRequest request){
        request.setModifiedUser(SecurityUser.getUser().getUsername());
        return merchantOrderInServiceClient.makeUpBeFore(request);
    }
}
