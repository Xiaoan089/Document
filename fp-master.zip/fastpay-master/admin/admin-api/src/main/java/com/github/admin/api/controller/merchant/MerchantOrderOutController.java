package com.github.admin.api.controller.merchant;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantOrderOutServiceClient;
import com.github.trans.front.common.entity.MerchantOrderOut;
import com.github.trans.front.common.entity.ThirdChannelTradeOut;
import com.github.trans.front.common.request.MerchantOrderOutRequest;
import com.github.trans.front.common.response.MerchantOrderOutProfitDetailsResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户代付订单")
public class MerchantOrderOutController {

    @Resource
    private MerchantOrderOutServiceClient merchantOrderOutServiceClient;

    @GetMapping("/merchantOrderOut/page")
    @ApiOperation("分页查询商户代付订单")
    public Result<DataPage<MerchantOrderOut>> page(MerchantOrderOutRequest request) {
        return merchantOrderOutServiceClient.page(request);
    }

    @ApiOperation("批量代付失败")
    @PostMapping("/merchantOrderOut/fail")
    @LogOperation(value = "批量代付失败",description = "批量代付失败")
    Result fail(@RequestBody MerchantOrderOutRequest request) {
        request.setModifiedUser(SecurityUser.getUser().getUsername());
        return merchantOrderOutServiceClient.fail(request);
    }

    @ApiOperation("批量代付成功")
    @PostMapping("/merchantOrderOut/success")
    @LogOperation(value = "批量代付成功",description = "批量代付成功")
    Result success(@RequestBody MerchantOrderOutRequest request) {
        request.setModifiedUser(SecurityUser.getUser().getUsername());
        return merchantOrderOutServiceClient.success(request);
    }

    @GetMapping("/merchantOrderOut/payment/details")
    @ApiOperation("查询商户代付订单支付详情")
    public Result<List<ThirdChannelTradeOut>> paymentDetails(MerchantOrderOutRequest request) {
        return merchantOrderOutServiceClient.paymentDetails(request);
    }

    @GetMapping("/merchantOrderOut/profit/details")
    @ApiOperation("查询商户代付订单利润详情")
    public Result<MerchantOrderOutProfitDetailsResponse> profitDetails(MerchantOrderOutRequest request) {
        return merchantOrderOutServiceClient.profitDetails(request);
    }
}
