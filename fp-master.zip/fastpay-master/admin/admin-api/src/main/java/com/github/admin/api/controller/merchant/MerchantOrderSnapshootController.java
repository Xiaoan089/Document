package com.github.admin.api.controller.merchant;

import com.github.framework.core.Result;
import com.github.trans.front.client.MerchantOrderSnapshootServiceClient;
import com.github.trans.front.common.entity.MerchantOrderSnapshoot;
import com.github.trans.front.common.request.MerchantOrderSnapshootRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户代收代付订单快照")
public class MerchantOrderSnapshootController {

    @Resource
    private MerchantOrderSnapshootServiceClient merchantOrderSnapshootServiceClient;

    @GetMapping("/thind/notify/findByMerchantOrderSnapshoot")
    @ApiOperation("分页查询商户代收代付订单快照")
    public Result<List<MerchantOrderSnapshoot>> findByMerchantOrderSnapshoot(MerchantOrderSnapshootRequest request) {
        return merchantOrderSnapshootServiceClient.findByMerchantOrderSnapshoot(request);
    }
}
