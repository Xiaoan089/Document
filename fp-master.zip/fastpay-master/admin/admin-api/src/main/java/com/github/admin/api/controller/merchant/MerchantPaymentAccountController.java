package com.github.admin.api.controller.merchant;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantPaymentAccountServiceClient;
import com.github.trans.front.common.entity.MerchantPaymentAccount;
import com.github.trans.front.common.request.MerchantPaymentAccountRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户支付账号")
public class MerchantPaymentAccountController {

    @Resource
    private MerchantPaymentAccountServiceClient merchantPaymentAccountServiceClient;

    @PostMapping("/merchant/payment/account")
    @ApiOperation("保存商户支付账号")
    @LogOperation(value = "保存",description = "保存商户支付账号")
    public Result save(@RequestBody MerchantPaymentAccountRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return merchantPaymentAccountServiceClient.save(request);
    }

    @GetMapping("/merchant/payment/account/page")
    @ApiOperation("分页查询商户支付账号")
    public Result<DataPage<MerchantPaymentAccount>> page(MerchantPaymentAccountRequest request){
        return merchantPaymentAccountServiceClient.page(request);
    }

    @PutMapping("/merchant/payment/account")
    @ApiOperation("修改商户支付账号")
    @LogOperation(value = "修改",description = "修改商户支付账号")
    public Result update(@RequestBody MerchantPaymentAccountRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return merchantPaymentAccountServiceClient.update(request);
    }

    @DeleteMapping("/merchant/payment/account/delete")
    @ApiOperation("删除商户支付账号")
    @LogOperation(value = "删除",description = "删除商户支付账号")
    public Result delete(@RequestBody List<Long> ids){
        MerchantPaymentAccountRequest request = new MerchantPaymentAccountRequest();
        request.setIds(ids);
        request.setUserDetail(SecurityUser.getUser());
        return merchantPaymentAccountServiceClient.delete(request);
    }

    @GetMapping("/merchant/payment/account/findByPaymentAccountId/{id}")
    @ApiOperation("根据商户支付账号ID查询商户支付账号和对应的支付方式")
    public Result<MerchantPaymentAccount> findByPaymentAccountId(@PathVariable("id") Long id){
        return merchantPaymentAccountServiceClient.findByPaymentAccountId(id);
    }

    @GetMapping("/merchant/payment/account/findMerchantPaymentAccountAndMethod")
    @ApiOperation("根据商户merchantId查询商户支付账号和对应的支付方式")
    public Result<List<MerchantPaymentAccount>> findMerchantPaymentAccountAndMethod(MerchantPaymentAccountRequest request) {
        return merchantPaymentAccountServiceClient.findMerchantPaymentAccountAndMethod(request);
    }


    @GetMapping("/merchant/payment/account/findMerchantFeeByMerchantIdAndAccountId")
    @ApiOperation("根据商户Id和支付账号Id查询商户费率")
    public Result<MerchantPaymentAccount> findMerchantFeeByMerchantIdAndAccountId(MerchantPaymentAccountRequest request) {
        return merchantPaymentAccountServiceClient.findMerchantFeeByMerchantIdAndAccountId(request);
    }

}
