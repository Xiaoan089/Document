package com.github.admin.api.controller.merchant;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantPaymentReversalServiceClient;
import com.github.trans.front.common.entity.MerchantPaymentReversal;
import com.github.trans.front.common.request.MerchantPaymentReversalRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@Api(tags = "商户冲正记录")
public class MerchantPaymentReversalController {


    @Resource
    private MerchantPaymentReversalServiceClient merchantPaymentReversalServiceClient;


    @GetMapping("/merchant/payment/reversal/page")
    @ApiOperation("分页查询商户代付冲正记录")
    public Result<DataPage<MerchantPaymentReversal>> page(MerchantPaymentReversalRequest request){
        return merchantPaymentReversalServiceClient.page(request);
    }

    @PostMapping("/merchantOrderOut/reversal")
    @ApiOperation("代付订单冲正")
    @LogOperation(value = "冲正",description = "代付冲正")
    public Result orderReversal(@RequestBody MerchantPaymentReversalRequest request) {
        request.setModifiedUser(SecurityUser.getUser().getUsername());
        return merchantPaymentReversalServiceClient.orderReversal(request);
    }
}
