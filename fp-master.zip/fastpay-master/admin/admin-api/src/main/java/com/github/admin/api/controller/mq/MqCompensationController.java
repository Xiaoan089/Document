package com.github.admin.api.controller.mq;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MqCompensationServiceClient;
import com.github.trans.front.common.entity.MqCompensation;
import com.github.trans.front.common.request.MqCompensationRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@Api(tags = "MQ补偿记录")
public class MqCompensationController {


    @Resource
    private MqCompensationServiceClient mqCompensationServiceClient;


    @GetMapping("/mq/compensation/page")
    @ApiOperation("分页查询MQ补偿记录")
    public Result<DataPage<MqCompensation>> page(MqCompensationRequest request){
        return mqCompensationServiceClient.page(request);
    }





}
