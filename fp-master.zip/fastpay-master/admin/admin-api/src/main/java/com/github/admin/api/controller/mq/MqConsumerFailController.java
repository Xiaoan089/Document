package com.github.admin.api.controller.mq;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MqConsumerFailServiceClient;
import com.github.trans.front.common.entity.MqConsumerFail;
import com.github.trans.front.common.request.MqConsumerFailRequest;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class MqConsumerFailController {

    @Resource
    private MqConsumerFailServiceClient mqConsumerFailServiceClient;

    @GetMapping("/mq/consumer/fail/page")
    @ApiOperation("分页查询MQ消费失败记录")
    @RequiresPermissions("sys:consumer:info")
    public Result<DataPage<MqConsumerFail>> page(MqConsumerFailRequest request){
        return mqConsumerFailServiceClient.page(request);
    }

}
