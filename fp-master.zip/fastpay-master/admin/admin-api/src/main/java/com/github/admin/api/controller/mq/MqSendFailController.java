package com.github.admin.api.controller.mq;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MqSendFailServiceClient;
import com.github.trans.front.common.entity.MqSendFail;
import com.github.trans.front.common.request.MqSendFailRequest;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class MqSendFailController {


    @Resource
    private MqSendFailServiceClient mqSendFailServiceClient;


    @GetMapping("/mq/send/fail/page")
    @ApiOperation("分页查询MQ发送失败记录")
    @RequiresPermissions("sys:send:info")
    public Result<DataPage<MqSendFail>> page(MqSendFailRequest request){
        return mqSendFailServiceClient.page(request);
    }

}
