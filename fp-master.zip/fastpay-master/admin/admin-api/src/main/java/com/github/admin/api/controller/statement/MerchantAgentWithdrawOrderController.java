package com.github.admin.api.controller.statement;


import com.github.admin.api.annation.LogOperation;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantAgentWithdrawOrderServiceClient;
import com.github.trans.front.common.entity.MerchantAgentWithdrawOrder;
import com.github.trans.front.common.request.MerchantAgentWithdrawOrderRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@Api(tags = "代理提现")
public class MerchantAgentWithdrawOrderController {

    @Resource
    private MerchantAgentWithdrawOrderServiceClient merchantAgentWithdrawOrderServiceClient;

    @GetMapping("/merchantagentwithdraworder/page")
    @ApiOperation("分页查询代理提现")
    @RequiresPermissions("sys:merchantagentwithdraworder:info")
    public Result<DataPage<MerchantAgentWithdrawOrder>> page(MerchantAgentWithdrawOrderRequest request){
        return merchantAgentWithdrawOrderServiceClient.page(request);
    }

    @GetMapping("/merchantagentwithdraworder/findById/{id}")
    @ApiOperation("根据ID查询代理提现")
    @RequiresPermissions("sys:merchantagentwithdraworder:info")
    public Result<MerchantAgentWithdrawOrder> findById(@PathVariable("id") Long id){
        return merchantAgentWithdrawOrderServiceClient.findById(id);
    }

    @PostMapping("/merchantagentwithdraworder")
    @ApiOperation("保存代理提现")
    @LogOperation(value = "保存",description = "保存代理提现")
    @RequiresPermissions("sys:merchantagentwithdraworder:save")
    public Result save(@RequestBody MerchantAgentWithdrawOrderRequest request){
        return merchantAgentWithdrawOrderServiceClient.save(request);
    }

    @PutMapping("/merchantagentwithdraworder")
    @ApiOperation("修改代理提现")
    @LogOperation(value = "修改",description = "修改代理提现")
    @RequiresPermissions("sys:merchantagentwithdraworder:update")
    public Result update(@RequestBody MerchantAgentWithdrawOrderRequest request){
        return merchantAgentWithdrawOrderServiceClient.update(request);
    }

}
