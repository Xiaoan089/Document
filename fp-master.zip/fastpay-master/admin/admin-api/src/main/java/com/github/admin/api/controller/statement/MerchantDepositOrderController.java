package com.github.admin.api.controller.statement;

import com.github.admin.api.annation.LogOperation;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantDepositOrderServiceClient;
import com.github.trans.front.common.entity.MerchantDepositOrder;
import com.github.trans.front.common.request.MerchantDepositOrderRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户充值订单")
public class MerchantDepositOrderController {

    @Resource
    private MerchantDepositOrderServiceClient merchantDepositOrderServiceClient;

    @GetMapping("/merchantdepositorder/page")
    @ApiOperation("分页查询商户充值订单")
    @RequiresPermissions("sys:merchantdepositorder:info")
    public Result<DataPage<MerchantDepositOrder>> page(MerchantDepositOrderRequest request){
        return merchantDepositOrderServiceClient.page(request);
    }

    @GetMapping("/merchantdepositorder/findById/{id}")
    @ApiOperation("根据ID查询商户充值订单")
    public Result<MerchantDepositOrder> findById(@PathVariable("id") Long id){
        return merchantDepositOrderServiceClient.findById(id);
    }

    @PostMapping("/merchantdepositorder")
    @ApiOperation("保存商户充值订单")
    @LogOperation(value = "保存",description = "保存商户充值订单")
    @RequiresPermissions("sys:merchantdepositorder:save")
    public Result save(@RequestBody MerchantDepositOrderRequest request){
        return merchantDepositOrderServiceClient.save(request);
    }

    @PutMapping("/merchantdepositorder")
    @ApiOperation("修改商户充值订单")
    @LogOperation(value = "修改",description = "修改商户充值订单")
    @RequiresPermissions("sys:merchantdepositorder:update")
    public Result update(@RequestBody MerchantDepositOrderRequest request){
        return merchantDepositOrderServiceClient.update(request);
    }

    @DeleteMapping("/merchantdepositorder/delete")
    @ApiOperation("删除商户充值订单")
    @LogOperation(value = "删除",description = "删除商户充值订单")
    public Result delete(@RequestBody List<Long> ids){
        return merchantDepositOrderServiceClient.delete(ids);
    }
    

}
