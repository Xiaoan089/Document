package com.github.admin.api.controller.statement;
import com.github.admin.api.annation.LogOperation;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantWithdrawOrderServiceClient;
import com.github.trans.front.common.entity.MerchantWithdrawOrder;
import com.github.trans.front.common.request.MerchantWithdrawOrderRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "商户提现订单")
public class MerchantWithdrawOrderController {

    @Resource
    private MerchantWithdrawOrderServiceClient merchantWithdrawOrderServiceClient;

    @GetMapping("/merchantwithdraworder/page")
    @ApiOperation("分页查询商户提现订单")
    @RequiresPermissions("sys:merchantwithdraworder:info")
    public Result<DataPage<MerchantWithdrawOrder>> page(MerchantWithdrawOrderRequest request){
        return merchantWithdrawOrderServiceClient.page(request);
    }

    @GetMapping("/merchantwithdraworder/findById/{id}")
    @ApiOperation("根据ID查询商户提现订单")
    @RequiresPermissions("sys:merchantwithdraworder:info")
    public Result<MerchantWithdrawOrder> findById(@PathVariable("id") Long id){
        return merchantWithdrawOrderServiceClient.findById(id);
    }

    @PostMapping("/merchantwithdraworder/save")
    @ApiOperation("保存商户提现订单")
    @LogOperation(value = "保存",description = "保存商户提现订单")
    @RequiresPermissions("sys:merchantwithdraworder:save")
    public Result save(@RequestBody MerchantWithdrawOrderRequest request){
        return merchantWithdrawOrderServiceClient.save(request);
    }

    @PutMapping("/merchantwithdraworder/update")
    @ApiOperation("修改商户提现订单")
    @LogOperation(value = "修改",description = "修改商户提现订单")
    @RequiresPermissions("sys:merchantwithdraworder:update")
    public Result update(@RequestBody MerchantWithdrawOrderRequest request){
        return merchantWithdrawOrderServiceClient.update(request);
    }

    @DeleteMapping("/merchantwithdraworder/delete")
    @ApiOperation("删除商户提现订单")
    @LogOperation(value = "删除",description = "删除商户提现订单")
    public Result delete(@RequestBody List<Long> ids){
        return merchantWithdrawOrderServiceClient.delete(ids);
    }

}
