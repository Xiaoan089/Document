package com.github.admin.api.controller.statement;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.SystemReportServiceClient;
import com.github.trans.front.common.entity.AgentOrderStatistics;
import com.github.trans.front.common.entity.MerchantOrderStatistics;
import com.github.trans.front.common.entity.ThirdOrderStatistics;
import com.github.trans.front.common.request.MerchantOrderStatisticsRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "系统报表")
public class SystemReportController {


    @Resource
    private SystemReportServiceClient systemReportServiceClient;


    @GetMapping("/system/report/findMerchantOrderStatistics")
    @ApiOperation("分页查询系统报表")
    public Result<List<MerchantOrderStatistics>> findMerchantOrderStatistics(MerchantOrderStatisticsRequest request) {
        return systemReportServiceClient.findMerchantOrderStatistics(request);
    }

    @GetMapping("/system/report/findMerchantOrderStatisticsByDateStr")
    @ApiOperation("分页查询商户报表")
    public Result<DataPage<MerchantOrderStatistics>> findMerchantOrderStatisticsByDateStr(MerchantOrderStatisticsRequest request) {
        return systemReportServiceClient.findMerchantOrderStatisticsByDateStr(request);
    }

    @GetMapping("/system/report/findAgentOrderStatisticsByDateStr")
    @ApiOperation("分页查询代理报表")
    public Result<DataPage<AgentOrderStatistics>> findAgentOrderStatisticsByDateStr(MerchantOrderStatisticsRequest request) {
        return systemReportServiceClient.findAgentOrderStatisticsByDateStr(request);
    }

    @GetMapping("/system/report/findThirdOrderStatisticsByDateStr")
    @ApiOperation("分页查询三方报表")
    public Result<DataPage<ThirdOrderStatistics>> findThirdOrderStatisticsByDateStr(MerchantOrderStatisticsRequest request) {
        return systemReportServiceClient.findThirdOrderStatisticsByDateStr(request);
    }

}
