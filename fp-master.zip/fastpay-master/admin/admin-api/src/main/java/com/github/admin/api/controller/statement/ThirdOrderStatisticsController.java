package com.github.admin.api.controller.statement;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.ThirdOrderStatisticsServiceClient;
import com.github.trans.front.common.entity.ThirdOrderStatistics;
import com.github.trans.front.common.request.ThirdOrderStatisticsRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "三方订单统计表")
public class ThirdOrderStatisticsController {

    @Resource
    private ThirdOrderStatisticsServiceClient thirdOrderStatisticsServiceClient;

    @GetMapping("/third/order/findStatisticsByChannelAccount")
    @ApiOperation("三方订单统计表")
    public Result<List<ThirdOrderStatistics>> findStatisticsByChannelAccount(ThirdOrderStatisticsRequest request){
        return thirdOrderStatisticsServiceClient.findStatisticsByChannelAccount(request);
    }

    @ApiOperation("根据具体时间查询三方报表")
    @GetMapping("/third/order/findThirdOrderStatisticsByDateStr")
    Result<DataPage<ThirdOrderStatistics>> findThirdOrderStatisticsByDateStr(ThirdOrderStatisticsRequest request){
        return thirdOrderStatisticsServiceClient.findThirdOrderStatisticsByDateStr(request);
    }

}
