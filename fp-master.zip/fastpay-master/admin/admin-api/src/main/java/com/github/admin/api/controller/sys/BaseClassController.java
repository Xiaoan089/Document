package com.github.admin.api.controller.sys;

import com.github.admin.client.BaseClassServiceClient;
import com.github.admin.common.entity.GenBaseClass;
import com.github.admin.common.request.BaseClassRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

/**
 * 基类管理
 */
@AllArgsConstructor
@RestController
@RequestMapping("devtools/baseclass")
public class BaseClassController {

    @Resource
    private BaseClassServiceClient baseClassServiceClient;

    @GetMapping("page")
    public Result<DataPage<GenBaseClass>> page(BaseClassRequest request) {
        return baseClassServiceClient.page(request);
    }

    @GetMapping("list")
    public Result<List<GenBaseClass>> list() {
        return baseClassServiceClient.list();
    }

    @GetMapping("{id}")
    public Result<GenBaseClass> get(@PathVariable("id") Long id) {
       return baseClassServiceClient.getById(id);
    }

    @PostMapping
    public Result save(@RequestBody BaseClassRequest entity) {
        return baseClassServiceClient.save(entity);
    }

    @PutMapping
    public Result update(@RequestBody BaseClassRequest entity) {
       return baseClassServiceClient.update(entity);
    }

    @DeleteMapping
    public Result delete(@RequestBody List<Long> ids) {
        return baseClassServiceClient.delete(ids);
    }
}
