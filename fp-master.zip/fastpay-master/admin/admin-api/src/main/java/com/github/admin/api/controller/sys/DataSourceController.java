package com.github.admin.api.controller.sys;

import com.github.admin.client.DataSourceServiceClient;
import com.github.admin.common.entity.GenDataSource;
import com.github.admin.common.request.GenDataSourceRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

/**
 * 数据源管理
 */
@AllArgsConstructor
@RestController
@RequestMapping("/devtools/datasource")
public class DataSourceController {

    @Resource
    private DataSourceServiceClient dataSourceServiceClient;

    @GetMapping("/page")
    public Result<DataPage<GenDataSource>> page(GenDataSourceRequest request) {
        return dataSourceServiceClient.page(request);
    }

    @GetMapping("/list")
    public Result<List<GenDataSource>> list() {
        return dataSourceServiceClient.list();
    }

    @GetMapping("/{id}")
    public Result<GenDataSource> get(@PathVariable("id") Long id) {
        return dataSourceServiceClient.get(id);
    }

    @GetMapping("/test/{id}")
    public Result<String> test(@PathVariable("id") Long id) {
        return dataSourceServiceClient.test(id);
    }

    @PostMapping
    public Result save(@RequestBody GenDataSourceRequest entity) {
       return dataSourceServiceClient.save(entity);
    }

    @PutMapping
    public Result update(@RequestBody GenDataSourceRequest entity) {
        return dataSourceServiceClient.update(entity);
    }

    @DeleteMapping
    public Result delete(@RequestBody List<Long> ids) {
        return dataSourceServiceClient.delete(ids);
    }
}
