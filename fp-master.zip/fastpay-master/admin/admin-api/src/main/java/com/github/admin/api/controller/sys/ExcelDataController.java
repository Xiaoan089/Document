package com.github.admin.api.controller.sys;

import com.alibaba.excel.EasyExcel;
import com.github.admin.api.listener.ExcelDataListener;
import com.github.admin.api.utils.ExcelUtils;
import com.github.admin.client.ExcelDataServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.TbExcelData;
import com.github.admin.common.excel.ExcelDataExcel;
import com.github.admin.common.request.ExcelDataRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * Excel导入演示
 */

@RestController
@RequestMapping("/demo/excel")
public class ExcelDataController {

    @Resource
    private ExcelDataServiceClient excelDataServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
    })
    @RequiresPermissions("demo:excel:all")
    public Result<DataPage<TbExcelData>> page(ExcelDataRequest request) {
        return excelDataServiceClient.page(request);
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("demo:excel:all")
    public Result<TbExcelData> get(@PathVariable("id") Long id) {
        return excelDataServiceClient.findById(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("demo:excel:all")
    public Result save(@RequestBody ExcelDataRequest request) {
        return excelDataServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("demo:excel:all")
    public Result update(@RequestBody ExcelDataRequest request) {
        return excelDataServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("demo:excel:all")
    public Result delete(@RequestBody Long[] ids) {
        return excelDataServiceClient.delete(ids);
    }

    @PostMapping("/import")
    @Operation(summary = "导入")
    @RequiresPermissions("demo:excel:all")
    public Result importExcel(@RequestBody MultipartFile file) throws IOException {
        EasyExcel.read(file.getInputStream(), ExcelDataExcel.class, new ExcelDataListener<>(excelDataServiceClient)).sheet().doRead();
        return Result.ok();
    }

    @GetMapping("/export")
    @Operation(summary = "导出")
    @RequiresPermissions("demo:excel:all")
    public void export(@Parameter(hidden = true) ExcelDataRequest request, HttpServletResponse response) throws Exception {
        List<TbExcelData> list = new ArrayList<>();
        Result<List<TbExcelData>> result = excelDataServiceClient.list(request);
        if (result.isSuccess()) {
            list = result.getData();
        }
        ExcelUtils.exportExcelToTarget(response, null, "Excel导入演示", list, ExcelDataExcel.class);
    }

}
