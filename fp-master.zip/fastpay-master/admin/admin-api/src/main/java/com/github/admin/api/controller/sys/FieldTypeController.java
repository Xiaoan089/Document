package com.github.admin.api.controller.sys;
import com.github.admin.client.FieldTypeServiceClient;
import com.github.admin.common.entity.GenFieldType;
import com.github.admin.common.request.GenFieldTypeRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

@RestController
public class FieldTypeController {

    @Resource
    private FieldTypeServiceClient fieldTypeServiceClient;

    @GetMapping("/devtools/fieldtype/page")
    public Result<DataPage<GenFieldType>> page(GenFieldTypeRequest request) {
       return fieldTypeServiceClient.page(request);
    }

    @GetMapping("/devtools/fieldtype/{id}")
    public Result<GenFieldType> get(@PathVariable("id") Long id) {
       return fieldTypeServiceClient.getById(id);
    }

    @GetMapping("/devtools/fieldtype/list")
    public Result<Set<String>> list() {
        return fieldTypeServiceClient.findAllAttrType();
    }

    @PostMapping("/devtools/fieldtype")
    public Result save(@RequestBody GenFieldTypeRequest entity) {
        return fieldTypeServiceClient.save(entity);
    }

    @PutMapping("/devtools/fieldtype")
    public Result update(@RequestBody GenFieldTypeRequest entity) {
        return fieldTypeServiceClient.update(entity);
    }

    @DeleteMapping("/devtools/fieldtype")
    public Result delete(@RequestBody List<Long> ids) {
        return fieldTypeServiceClient.deleteBatchIds(ids);
    }
}
