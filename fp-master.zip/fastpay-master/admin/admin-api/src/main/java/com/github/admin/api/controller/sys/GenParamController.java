package com.github.admin.api.controller.sys;

import com.alibaba.fastjson2.JSON;
import com.github.admin.client.SysParamsServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.dto.ParamSetting;
import com.github.admin.common.request.GenParamRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.trans.front.common.request.SysParamsRequest;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 代码生成参数配置
 */

@RestController
@RequestMapping("/devtools/param")
public class GenParamController {

    @Resource
    private SysParamsServiceClient sysParamsServiceClient;

    @GetMapping("/info")
    public Result<ParamSetting> info() {
        SysParamsRequest sysParamsRequest = new SysParamsRequest();
        sysParamsRequest.setParamCode(Constant.DEV_TOOLS_PARAM_KEY);
        sysParamsRequest.setClazz(ParamSetting.class);
        return sysParamsServiceClient.getValueObject(sysParamsRequest);
    }

    @PostMapping
    public Result saveConfig(@RequestBody GenParamRequest param) {
        SysParamsRequest sysParamsRequest = new SysParamsRequest();
        sysParamsRequest.setParamCode(Constant.DEV_TOOLS_PARAM_KEY);
        sysParamsRequest.setParamValue(JSON.toJSONString(param));
        sysParamsRequest.setUserDetail(SecurityUser.getUser());
        sysParamsRequest.setParamType(1);
        return sysParamsServiceClient.updateValueByCode(sysParamsRequest);
    }
}
