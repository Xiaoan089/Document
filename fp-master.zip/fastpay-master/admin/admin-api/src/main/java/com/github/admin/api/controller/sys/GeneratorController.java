package com.github.admin.api.controller.sys;

import com.github.admin.client.GeneratorServiceClient;
import com.github.admin.common.entity.GenTableInfo;
import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.request.GenTableFieldRequest;
import com.github.admin.common.request.SysMenuRequest;
import com.github.admin.common.request.TableInfoRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 代码生成
 */
@AllArgsConstructor
@RestController
@RequestMapping("/devtools")
public class GeneratorController {

    @Resource
    private GeneratorServiceClient generatorServiceClient;

    @GetMapping("/table/page")
    public Result<DataPage<GenTableInfo>> pageTable(TableInfoRequest request) {
        return generatorServiceClient.pageTable(request);
    }

    @GetMapping("/table/{id}")
    public Result<GenTableInfo> getTable(@PathVariable("id") Long id) {
        return generatorServiceClient.getTable(id);
    }

    @PutMapping("/table")
    public Result updateTable(@RequestBody TableInfoRequest request) {
        return generatorServiceClient.updateTable(request);
    }

    @DeleteMapping("/table")
    public Result deleteTable(@RequestBody List<Long> ids) {
        return generatorServiceClient.deleteTable(ids);
    }

    /**
     * 获取数据源中所有表
     */
    @GetMapping("/datasource/table/list/{id}")
    public Result<List<GenTableInfo>> getDataSourceTableList(@PathVariable("id") Long id) {
        return generatorServiceClient.getDataSourceTableList(id);
    }

    /**
     * 导入数据源中的表
     */
    @PostMapping("/datasource/table")
    public Result datasourceTable(@RequestBody TableInfoRequest request) {
        return generatorServiceClient.datasourceTable(request);
    }

    /**
     * 更新列数据
     */
    @PutMapping("/table/field/{tableId}")
    public Result updateTableField(@PathVariable("tableId") Long tableId, @RequestBody List<GenTableFieldRequest> tableFieldList) {
        return generatorServiceClient.updateTableField(tableId, tableFieldList);
    }

    @GetMapping("/dict")
    public Result<List<SysDictType>> dict() {
        return generatorServiceClient.dict();
    }

    /**
     * 生成代码
     */
    @PostMapping("/generator")
    public Result generator(@RequestBody TableInfoRequest request) {
        return generatorServiceClient.generator(request);
    }

    /**
     * 创建菜单
     */
    @PostMapping("/menu")
    public Result menu(@RequestBody SysMenuRequest request) {
        return generatorServiceClient.menu(request);
    }
}
