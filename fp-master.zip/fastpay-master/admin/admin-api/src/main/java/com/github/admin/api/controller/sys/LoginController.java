package com.github.admin.api.controller.sys;
import com.github.admin.api.service.CaptchaService;
import com.github.admin.client.SysLogLoginServiceClient;
import com.github.admin.client.SysUserServiceClient;
import com.github.admin.client.SysUserTokenServiceClient;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.enums.LoginOperationEnum;
import com.github.admin.common.enums.LoginStatusEnum;
import com.github.admin.common.enums.UserStatusEnum;
import com.github.admin.common.exception.ErrorCode;
import com.github.admin.common.request.LoginRequest;
import com.github.admin.common.request.SysLogLoginRequest;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.admin.common.utils.IpUtils;
import com.github.admin.common.utils.PasswordUtils;
import com.github.admin.common.utils.AssertUtils;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@RestController
@Api(tags = "登录管理")
@Slf4j
public class LoginController {

    @Resource
    private SysUserServiceClient sysUserServiceClient;

    @Resource
    private SysUserTokenServiceClient sysUserTokenServiceClient;

    @Resource
    private SysLogLoginServiceClient sysLogLoginServiceClient;

    @Resource
    private CaptchaService captchaService;

    @GetMapping("/captcha")
    @ApiOperation(value = "验证码")
    public void captcha(String uuid, HttpServletResponse response) throws IOException {
        //uuid不能为空
        AssertUtils.isBlank(uuid, ErrorCode.IDENTIFIER_NOT_NULL);

        //生成验证码
        captchaService.create(response, uuid);
    }

    @PostMapping("/login")
    @ApiOperation(value = "登录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "username", value = "用户名", paramType = "query", required = true, dataType = "int"),
    })
    public Result login(@Validated @RequestBody LoginRequest loginRequest,HttpServletRequest request) {

        //验证码是否正确
        boolean checkCaptcha = captchaService.validate(loginRequest.getUuid(), loginRequest.getCaptcha());

        if (!checkCaptcha) {
            return Result.fail(AdminErrorMsgEnum.VERIFICATION_CODE_ERROR);
        }

        loginRequest.setSysType(1);
        SysUserRequest sysUserRequest = new SysUserRequest();
        sysUserRequest.setUsername(loginRequest.getUsername());
        sysUserRequest.setSysType(loginRequest.getSysType());
        Result<SysUser> result = sysUserServiceClient.getByUsername(sysUserRequest);
        if (!result.isSuccess()) {
            log.error("登录获取用户失败, username:{}", loginRequest.getUsername());
            return Result.fail(AdminErrorMsgEnum.SYSTEM_ERROR);
        }
        SysUser user = result.getData();
        SysLogLoginRequest sysLogLoginRequest = new SysLogLoginRequest();
        sysLogLoginRequest.setOperation(LoginOperationEnum.LOGIN.value());
        sysLogLoginRequest.setCreateDate(new Date());
        sysLogLoginRequest.setIp(IpUtils.getIpAddr(request));
        sysLogLoginRequest.setUserAgent(request.getHeader(HttpHeaders.USER_AGENT));
        sysLogLoginRequest.setIp(IpUtils.getIpAddr(request));

        if (user == null) {
            log.error("登录获取用户为空, username:{}", loginRequest.getUsername());
            return Result.fail(AdminErrorMsgEnum.USER_NOT_EXISTS);
        }

        sysLogLoginRequest.setUserId(user.getId());
        sysLogLoginRequest.setSysType(loginRequest.getSysType());

        //密码错误
        if (!PasswordUtils.matches(loginRequest.getPassword(), user.getPassword())) {
            sysLogLoginRequest.setStatus(LoginStatusEnum.FAIL.value());
            sysLogLoginRequest.setCreateUser(user.getUsername());
            sysLogLoginRequest.setCreatorName(user.getUsername());
            sysLogLoginServiceClient.save(sysLogLoginRequest);
            return Result.fail(AdminErrorMsgEnum.WRONG_PASSWORD);
        }

        //账号停用
        if (user.getStatus() == UserStatusEnum.DISABLE.value()) {
            sysLogLoginRequest.setStatus(LoginStatusEnum.LOCK.value());
            sysLogLoginRequest.setCreateUser(user.getUsername());
            sysLogLoginRequest.setCreatorName(user.getUsername());
            sysLogLoginServiceClient.save(sysLogLoginRequest);
            return Result.fail(AdminErrorMsgEnum.ACCOUNT_DEACTIVATED);
        }

        //登录成功
        sysLogLoginRequest.setStatus(LoginStatusEnum.SUCCESS.value());
        sysLogLoginRequest.setCreateUser(user.getUsername());
        sysLogLoginRequest.setCreatorName(user.getUsername());
        sysLogLoginServiceClient.save(sysLogLoginRequest);

        return sysUserTokenServiceClient.createToken(user.getId());
    }

    @PostMapping("/logout")
    @Operation(summary = "退出")
    public Result logout(HttpServletRequest request) {
        SysLogLoginRequest sysLogLoginRequest = new SysLogLoginRequest();
        UserDetail user = SecurityUser.getUser();
        SecurityUser.getSubject().logout();
        sysLogLoginRequest.setOperation(LoginOperationEnum.LOGOUT.value());
        sysLogLoginRequest.setIp(IpUtils.getIpAddr(request));
        sysLogLoginRequest.setUserAgent(request.getHeader(HttpHeaders.USER_AGENT));
        sysLogLoginRequest.setIp(IpUtils.getIpAddr(request));
        sysLogLoginRequest.setStatus(LoginStatusEnum.SUCCESS.value());
        sysLogLoginRequest.setCreateUser(user.getUsername());
        sysLogLoginRequest.setCreatorName(user.getUsername());
        sysLogLoginRequest.setCreateDate(new Date());
        sysLogLoginRequest.setUserId(user.getId());
        sysLogLoginRequest.setSysType(1);

        //退出
        sysUserTokenServiceClient.logout(user.getId());

        //用户信息
        sysLogLoginServiceClient.save(sysLogLoginRequest);
        return Result.ok();
    }

}
