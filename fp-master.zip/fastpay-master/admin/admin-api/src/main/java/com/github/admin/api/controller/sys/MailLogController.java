package com.github.admin.api.controller.sys;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.client.SysMailLogServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysMailLog;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;


/**
 * 邮件发送记录
 */
@AllArgsConstructor
@RestController
@RequestMapping("/sys/maillog")
@Tag(name = "邮件发送记录")
public class MailLogController {

    @Resource
    private SysMailLogServiceClient sysMailLogServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "templateId", description = "templateId"),
            @Parameter(name = "mailTo", description = "mailTo"),
            @Parameter(name = "status", description = "status")
    })
    @RequiresPermissions("sys:mail:log")
    public Result<DataPage<SysMailLog>> page(@Parameter(hidden = true) @RequestParam Map<String, Object> params) {
        SysMailLogRequest mailLogRequest = BeanUtil.toBean(params, SysMailLogRequest.class);
        return sysMailLogServiceClient.page(mailLogRequest);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:mail:log")
    public Result delete(@RequestBody Long[] ids) {
        return sysMailLogServiceClient.delete(ids);
    }

}
