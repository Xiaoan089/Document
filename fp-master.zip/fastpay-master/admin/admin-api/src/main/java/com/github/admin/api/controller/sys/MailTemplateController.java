package com.github.admin.api.controller.sys;

import com.github.admin.client.SysMailTemplateServiceClient;
import com.github.admin.client.SysParamsServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysMailTemplate;
import com.github.admin.common.request.EmailConfigRequest;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.admin.common.request.SysMailTemplateRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.dto.EmailSetting;
import com.github.trans.front.common.request.SysParamsRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


/**
 * 邮件模板
 */
@RestController
@RequestMapping("sys/mailtemplate")
@Tag(name = "邮件模板")
public class MailTemplateController {

    @Resource
    private SysMailTemplateServiceClient sysMailTemplateServiceClient;

    @Resource
    private SysParamsServiceClient sysParamsServiceClient;

    private final static String KEY = Constant.MAIL_CONFIG_KEY;

    @GetMapping("page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "name", description = "name")
    })
    @RequiresPermissions("sys:mail:all")
    public Result<DataPage<SysMailTemplate>> page(@Parameter(hidden = true) SysMailTemplateRequest templateRequest) {
        return sysMailTemplateServiceClient.page(templateRequest);
    }

    @GetMapping("/config")
    @Operation(summary = "获取配置信息")
    @RequiresPermissions("sys:mail:all")
    public Result<EmailSetting> config() {
        SysParamsRequest sysParamsRequest = new SysParamsRequest();
        sysParamsRequest.setParamCode(KEY);
        sysParamsRequest.setClazz(EmailSetting.class);
        return sysParamsServiceClient.getValueObject(sysParamsRequest);
    }

    @PostMapping("/saveConfig")
    @Operation(summary = "保存配置信息")
    @RequiresPermissions("sys:mail:all")
    public Result saveConfig(@RequestBody EmailConfigRequest config) {
        return sysMailTemplateServiceClient.saveConfig(config);
    }

    @GetMapping("{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:mail:all")
    public Result<SysMailTemplate> info(@PathVariable("id") Long id) {
        return sysMailTemplateServiceClient.info(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:mail:all")
    public Result save(@RequestBody SysMailTemplateRequest request) {
        return sysMailTemplateServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:mail:all")
    public Result update(@RequestBody SysMailTemplateRequest request) {
        return sysMailTemplateServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:mail:all")
    public Result delete(@RequestBody List<Long> ids) {
        return sysMailTemplateServiceClient.delete(ids);
    }

    @PostMapping("/send")
    @Operation(summary = "发送邮件")
    @RequiresPermissions("sys:mail:all")
    public Result send(SysMailLogRequest mailLogRequest){
        return sysMailTemplateServiceClient.send(mailLogRequest);
    }

}
