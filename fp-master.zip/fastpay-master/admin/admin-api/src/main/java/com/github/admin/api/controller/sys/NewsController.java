package com.github.admin.api.controller.sys;

import com.github.admin.client.NewsServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.TbNews;
import com.github.admin.common.request.NewsRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;

/**
 * 新闻
 */

@RestController
@RequestMapping("/demo/news")
@Tag(name = "新闻管理")
public class NewsController {

    @Resource
    private NewsServiceClient newsServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "title", description = "标题"),
            @Parameter(name = Constant.START_DATE, description = "开始时间"),
            @Parameter(name = Constant.END_DATE, description = "结束时间"),
    })
    @RequiresPermissions("demo:news:all")
    public Result<DataPage<TbNews>> page(@Parameter(hidden = true) NewsRequest request) {
        return newsServiceClient.page(request);
    }

    @Operation(summary = "信息")
    @GetMapping("/{id}")
    @RequiresPermissions("demo:news:all")
    public Result<TbNews> info(@PathVariable("id") Long id) {
       return newsServiceClient.info(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("demo:news:all")
    public Result save(@RequestBody NewsRequest dto) {
        return newsServiceClient.save(dto);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("demo:news:all")
    public Result update(@RequestBody NewsRequest dto) {
       return newsServiceClient.update(dto);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("demo:news:all")
    public Result delete(@RequestBody Long[] ids) {
        return newsServiceClient.delete(Arrays.asList(ids));
    }

}
