package com.github.admin.api.controller.sys;

import com.github.admin.client.ProductServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.TbProduct;
import com.github.admin.common.request.ProductRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 产品管理
 */
@RestController
@RequestMapping("/demo/product")
public class ProductController {

    @Resource
    private ProductServiceClient productServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
    })
    @RequiresPermissions("demo:product:page")
    public Result<DataPage<TbProduct>> page(@Parameter(hidden = true) ProductRequest request) {
        return productServiceClient.page(request);
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("demo:product:info")
    public Result<TbProduct> findById(@PathVariable("id") Long id) {
        return productServiceClient.findById(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("demo:product:save")
    public Result save(@RequestBody ProductRequest request) {
        return productServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("demo:product:update")
    public Result update(@RequestBody ProductRequest request) {
        return productServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("demo:product:delete")
    public Result delete(@RequestBody List<Long> ids) {
        return productServiceClient.delete(ids);
    }

}
