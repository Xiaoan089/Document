package com.github.admin.api.controller.sys;

import cn.hutool.core.io.IoUtil;
import com.github.admin.api.utils.ProjectUtils;
import com.github.admin.common.request.ProjectRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;


/**
 * 项目名修改
 */
@RestController
@RequestMapping("/devtools/project")
public class ProjectController {

    @GetMapping
    public void project(ProjectRequest project, HttpServletResponse response) throws Exception {
        byte[] data = ProjectUtils.download(project);

        response.setHeader("Content-Disposition", "attachment; filename=\"" + project.getNewProjectName() + ".zip\"");
        response.addHeader("Content-Length", "" + data.length);
        response.setContentType("application/octet-stream; charset=UTF-8");

        IoUtil.write(response.getOutputStream(), false, data);
    }
}
