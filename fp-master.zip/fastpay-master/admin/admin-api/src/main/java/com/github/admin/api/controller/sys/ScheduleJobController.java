package com.github.admin.api.controller.sys;


import com.github.admin.client.ScheduleJobServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.ScheduleJob;
import com.github.admin.common.request.ScheduleJobRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 定时任务
 */
@RestController
@RequestMapping("/sys/schedule")
@Tag(name = "定时任务")
public class ScheduleJobController {
    @Resource
    private ScheduleJobServiceClient scheduleJobServiceClient;

    @GetMapping("page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "beanName", description = "beanName")
    })
    @RequiresPermissions("sys:schedule:page")
    public Result<DataPage<ScheduleJob>> page(@Parameter(hidden = true) ScheduleJobRequest request) {
        return scheduleJobServiceClient.page(request);
    }

    @GetMapping("{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:schedule:info")
    public Result<ScheduleJob> info(@PathVariable("id") Long id) {
        return scheduleJobServiceClient.findById(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:schedule:save")
    public Result save(@RequestBody ScheduleJobRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return scheduleJobServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:schedule:update")
    public Result update(@RequestBody ScheduleJobRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return scheduleJobServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:schedule:delete")
    public Result delete(@RequestBody List<Long> ids) {
        return scheduleJobServiceClient.deleteBatch(ids);
    }

    @PutMapping("/run")
    @Operation(summary = "立即执行")
    @RequiresPermissions("sys:schedule:run")
    public Result run(@RequestBody List<Long> ids) {
        return scheduleJobServiceClient.run(ids);
    }

    @PutMapping("/pause")
    @Operation(summary = "暂停")
    @RequiresPermissions("sys:schedule:pause")
    public Result pause(@RequestBody List<Long> ids) {
        return scheduleJobServiceClient.pause(ids);
    }

    @PutMapping("/resume")
    @Operation(summary = "恢复")
    @RequiresPermissions("sys:schedule:resume")
    public Result resume(@RequestBody List<Long> ids) {
        return scheduleJobServiceClient.resume(ids);
    }

}
