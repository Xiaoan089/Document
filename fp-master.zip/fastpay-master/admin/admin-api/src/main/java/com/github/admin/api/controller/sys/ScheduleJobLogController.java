package com.github.admin.api.controller.sys;

import com.github.admin.client.ScheduleJobLogServiceClient;
import com.github.admin.common.entity.ScheduleJobLog;
import com.github.admin.common.request.ScheduleJobLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;
import com.github.admin.common.constant.Constant;

import javax.annotation.Resource;

/**
 * 定时任务日志
 */
@RestController
@RequestMapping("/sys/scheduleLog")
@Tag(name = "定时任务日志")
public class ScheduleJobLogController {
    @Resource
    private ScheduleJobLogServiceClient scheduleJobLogServiceClient;

    @GetMapping("page")
    @Operation(summary = "分页")
    @Parameters(value = {
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "jobId", description = "jobId")
    })
    @RequiresPermissions("sys:schedule:log")
    public Result<DataPage<ScheduleJobLog>> page(@Parameter(hidden = true)ScheduleJobLogRequest request) {
        return scheduleJobLogServiceClient.page(request);
    }

    @GetMapping("{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:schedule:log")
    public Result<ScheduleJobLog> findById(@PathVariable("id") Long id) {
        return scheduleJobLogServiceClient.findById(id);
    }
}
