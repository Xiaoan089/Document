package com.github.admin.api.controller.sys;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.client.SysSmsServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysSms;
import com.github.admin.common.request.SysSmsRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 短信服务
 */
@AllArgsConstructor
@RestController
@RequestMapping("/sys/sms")
@Tag(name = "短信服务")
public class SmsController {

    @Resource
    private SysSmsServiceClient sysSmsServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
    })
    @RequiresPermissions("sys:sms:all")
    public Result<DataPage<SysSms>> page(@Parameter(hidden = true) SysSmsRequest sysSmsRequest) {
        return sysSmsServiceClient.page(sysSmsRequest);
    }

    @PostMapping
    @LogOperation(value = "保存",description = "asd")
    @Operation(summary = "保存")
    @RequiresPermissions("sys:sms:all")
    public Result save(@RequestBody SysSmsRequest request) {
       return sysSmsServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
//    @LogOperation("修改")
    @RequiresPermissions("sys:sms:all")
    public Result update(@RequestBody SysSmsRequest request) {
       return sysSmsServiceClient.update(request);
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:sms:all")
    public Result<SysSms> findById(@PathVariable("id") Long id) {
        return sysSmsServiceClient.findById(id);
    }

    @PostMapping("/send")
    @Operation(summary = "发送短信")
    @Parameters({
            @Parameter(name = "smsCode", description = "短信编码", required = true),
            @Parameter(name = "mobile", description = "手机好号", required = true),
            @Parameter(name = "params", description = "参数", required = true)
    })
//    @LogOperation("发送短信")
    @RequiresPermissions("sys:sms:all")
    public Result send(@RequestBody SysSmsRequest smsRequest) {
        return sysSmsServiceClient.send(smsRequest);

    }

    @DeleteMapping
    @Operation(summary = "删除")
//    @LogOperation("删除")
    @RequiresPermissions("sys:sms:all")
    public Result delete(@RequestBody List<Long> ids) {
        return sysSmsServiceClient.delete(ids);
    }

}
