package com.github.admin.api.controller.sys;

import com.github.admin.client.SysDeptServiceClient;
import com.github.admin.common.entity.SysDept;
import com.github.admin.common.request.SysDeptRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/sys/dept")
@Tag(name = "部门管理")
public class SysDeptController {

    @Resource
    private SysDeptServiceClient sysDeptServiceClient;

    @GetMapping("/list")
    @Operation(summary = "列表")
    @RequiresPermissions("sys:dept:list")
    public Result<List<SysDept>> list() {
        SysDeptRequest sysDeptRequest = new SysDeptRequest();
        return sysDeptServiceClient.list(sysDeptRequest);
    }

    @GetMapping("{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:dept:info")
    public Result<SysDept> get(@PathVariable("id") Long id) {
        SysDeptRequest sysDeptRequest = new SysDeptRequest();
        sysDeptRequest.setId(id);
        return sysDeptServiceClient.findById(sysDeptRequest);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:dept:save")
    public Result save(@RequestBody SysDeptRequest request) {
       return sysDeptServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:dept:update")
    public Result update(@RequestBody SysDeptRequest request) {
        return sysDeptServiceClient.update(request);
    }

    @DeleteMapping("{id}")
    @Operation(summary = "删除")
    @RequiresPermissions("sys:dept:delete")
    public Result delete(@PathVariable("id") List<Long> ids) {
        SysDeptRequest sysDeptRequest = new SysDeptRequest();
        sysDeptRequest.setId(ids.get(0));
        return sysDeptServiceClient.delete(sysDeptRequest);
    }

}
