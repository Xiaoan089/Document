package com.github.admin.api.controller.sys;

import com.github.admin.client.SysDictDataServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysDictData;
import com.github.admin.common.request.SysDictDataRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 字典数据
 */
@AllArgsConstructor
@RestController
@RequestMapping("/sys/dict/data")
@Tag(name = "字典数据")
public class SysDictDataController {


    @Resource
    private SysDictDataServiceClient sysDictDataServiceClient;

    @GetMapping("/page")
    @Operation(summary = "字典数据")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "dictLabel", description = "字典标签"),
            @Parameter(name = "dictValue", description = "字典值")
    })
    @RequiresPermissions("sys:dict:page")
    public Result<DataPage<SysDictData>> page(@Parameter(hidden = true) SysDictDataRequest request) {
        return sysDictDataServiceClient.page(request);
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:dict:info")
    public Result<SysDictData> findById(@PathVariable("id") Long id) {
        return sysDictDataServiceClient.findById(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:dict:save")
    public Result save(@RequestBody SysDictDataRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysDictDataServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:dict:update")
    public Result update(@RequestBody SysDictDataRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysDictDataServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:dict:delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysDictDataServiceClient.delete(ids);
    }

}
