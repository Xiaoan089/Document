package com.github.admin.api.controller.sys;

import com.github.admin.client.SysDictTypeServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.request.SysDictTypeRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 字典类型
 */
@RestController
@RequestMapping("/sys/dict/type")
@Tag(name = "字典类型")
public class SysDictTypeController {

    @Resource
    private SysDictTypeServiceClient sysDictTypeServiceClient;

    @GetMapping("/page")
    @Operation(summary = "字典类型")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "dictType", description = "字典类型"),
            @Parameter(name = "dictName", description = "字典名称")
    })
    @RequiresPermissions("sys:dict:page")
    public Result<DataPage<SysDictType>> page(@Parameter(hidden = true) SysDictTypeRequest request) {
        return sysDictTypeServiceClient.page(request);
    }

    @GetMapping("{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:dict:info")
    public Result<SysDictType> get(@PathVariable("id") Long id) {
        return sysDictTypeServiceClient.get(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:dict:save")
    public Result save(@RequestBody SysDictTypeRequest request) {
        return sysDictTypeServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:dict:update")
    public Result update(@RequestBody SysDictTypeRequest request) {
        return sysDictTypeServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:dict:delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysDictTypeServiceClient.delete(ids);
    }

    @GetMapping("/all")
    @Operation(summary = "所有字典数据")
    public Result<List<SysDictType>> all() {
        return sysDictTypeServiceClient.all();
    }

}
