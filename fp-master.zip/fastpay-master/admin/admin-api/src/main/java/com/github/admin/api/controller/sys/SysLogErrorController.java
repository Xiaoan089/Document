package com.github.admin.api.controller.sys;

import com.github.admin.api.utils.ExcelUtils;
import com.github.admin.client.SysLogErrorServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysLogError;
import com.github.admin.common.excel.SysLogErrorExcel;
import com.github.admin.common.request.SysLogErrorRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;


/**
 * 异常日志
 */
@AllArgsConstructor
@RestController
@RequestMapping("sys/log/error")
@Tag(name = "异常日志")
public class SysLogErrorController {

    @Resource
    private SysLogErrorServiceClient sysLogErrorServiceClient;

    @GetMapping("page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
    })
    @RequiresPermissions("sys:log:error")
    public Result<DataPage<SysLogError>> page(@Parameter(hidden = true)SysLogErrorRequest request) {
        return sysLogErrorServiceClient.page(request);
    }

    @GetMapping("export")
    @Operation(summary = "导出")
    @RequiresPermissions("sys:log:error")
    public void export(@Parameter(hidden = true) SysLogErrorRequest request, HttpServletResponse response) throws Exception {
        List<SysLogError> list = new ArrayList<>();
        Result<List<SysLogError>> result = sysLogErrorServiceClient.selectListSelective(request);
        if (result.isSuccess()) {
            list = result.getData();
        }
        ExcelUtils.exportExcelToTarget(response, null, "异常日志", list, SysLogErrorExcel.class);
    }

}
