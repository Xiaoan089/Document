package com.github.admin.api.controller.sys;

import com.github.admin.api.utils.ExcelUtils;
import com.github.admin.client.SysLogLoginServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysLogLogin;
import com.github.admin.common.excel.SysLogLoginExcel;
import com.github.admin.common.request.SysLogLoginRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 * 登录日志
 */

@RestController
@RequestMapping("/sys/log/login")
@Tag(name = "登录日志")
public class SysLogLoginController {

    @Resource
    private SysLogLoginServiceClient sysLogLoginServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "status", description = "状态  0：失败    1：成功    2：账号已锁定"),
            @Parameter(name = "creatorName", description = "用户名")
    })
    @RequiresPermissions("sys:log:login")
    public Result<DataPage<SysLogLogin>> page(@Parameter(hidden = true)SysLogLoginRequest request) {
        return sysLogLoginServiceClient.page(request);
    }

    @GetMapping("/export")
    @Operation(summary = "导出")
    @RequiresPermissions("sys:log:login")
    public void export(@Parameter(hidden = true) SysLogLoginRequest request, HttpServletResponse response) throws Exception {
        List<SysLogLogin> list = new ArrayList<>();
        Result<List<SysLogLogin>> result = sysLogLoginServiceClient.list(request);
        if (result.isSuccess()) {
            list = result.getData();
        }
        ExcelUtils.exportExcelToTarget(response, null, "登录日志", list, SysLogLoginExcel.class);
    }

}
