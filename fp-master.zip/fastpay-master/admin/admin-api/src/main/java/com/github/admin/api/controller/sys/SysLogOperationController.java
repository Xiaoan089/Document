package com.github.admin.api.controller.sys;

import com.github.admin.api.utils.ExcelUtils;
import com.github.admin.client.SysLogOperationServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysLogOperation;
import com.github.admin.common.excel.SysLogOperationExcel;
import com.github.admin.common.request.SysLogOperationRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;


/**
 * 操作日志
 */
@RestController
@RequestMapping("/sys/log/operation")
@Tag(name = "操作日志")
public class SysLogOperationController {

    @Resource
    private SysLogOperationServiceClient sysLogOperationServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "status", description = "状态  0：失败    1：成功")
    })
    @RequiresPermissions("sys:log:operation")
    public Result<DataPage<SysLogOperation>> page(@Parameter(hidden = true) SysLogOperationRequest request) {
        return sysLogOperationServiceClient.page(request);
    }

    @GetMapping("/export")
    @Operation(summary = "导出")
    @RequiresPermissions("sys:log:operation")
    public void export(HttpServletResponse response) throws Exception {
        List<SysLogOperation> list = new ArrayList<>();
        Result<List<SysLogOperation>> listResult = sysLogOperationServiceClient.selectListBySelective(new SysLogOperationRequest());
        if (listResult.isSuccess()) {
            list = listResult.getData();
        }
        ExcelUtils.exportExcelToTarget(response, null, "操作日志", list, SysLogOperationExcel.class);
    }

}
