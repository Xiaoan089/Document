package com.github.admin.api.controller.sys;

import com.github.admin.api.service.ShiroService;
import com.github.admin.client.SysMenuServiceClient;
import com.github.admin.common.entity.SysMenu;
import com.github.admin.common.enums.MenuTypeEnum;
import com.github.admin.common.request.SysMenuRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.admin.common.utils.HttpContextUtils;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;
import com.github.framework.core.group.SwaggerAddGroup;
import com.github.framework.swagger.annotition.ApiGroup;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

/**
 * 菜单管理
 */
@AllArgsConstructor
@RestController
@RequestMapping("/sys/menu")
@Api(value = "菜单管理")
public class SysMenuController {

    @Resource
    private SysMenuServiceClient sysMenuServiceClient;

    @Resource
    private ShiroService shiroServiceImpl;

    @GetMapping("/nav")
    @Operation(summary = "导航")
    public Result<List<SysMenu>> nav() {
        SysMenuRequest sysMenuRequest = new SysMenuRequest();
        sysMenuRequest.setMenuType(MenuTypeEnum.MENU.value());
        sysMenuRequest.setLanguage(HttpContextUtils.getLanguage());
        return sysMenuServiceClient.nav(sysMenuRequest);
    }

    @GetMapping("/permissions")
    @Operation(summary = "权限标识")
    public Result<Set<String>> permissions() {
        UserDetail user = SecurityUser.getUser();
        Set<String> set = shiroServiceImpl.getUserPermissions(user);
        return Result.ok(set);
    }

    @GetMapping("/list")
    @Operation(summary = "列表")
    @Parameter(name = "type", description = "菜单类型 0：菜单 1：按钮  null：全部")
    public Result<SysMenu> list(SysMenuRequest sysMenuRequest) {
        sysMenuRequest.setLanguage(HttpContextUtils.getLanguage());
        return sysMenuServiceClient.list(sysMenuRequest);
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:menu:info")
    public Result<SysMenu> findById(@PathVariable("id") Long id) {
        SysMenuRequest sysMenuRequest = new SysMenuRequest();
        sysMenuRequest.setId(id);
        sysMenuRequest.setLanguage(HttpContextUtils.getLanguage());
        return sysMenuServiceClient.findById(sysMenuRequest);
    }

    @PostMapping
    @ApiOperation(value = "保存")
    @RequiresPermissions("sys:menu:save")
    public Result save(@RequestBody SysMenuRequest request) {
        request.setLanguage(HttpContextUtils.getLanguage());
        return sysMenuServiceClient.save(request);
    }

    @PutMapping
    @ApiOperation(value = "修改")
    @RequiresPermissions("sys:menu:update")
    public Result update(@RequestBody SysMenuRequest request) {
        request.setLanguage(HttpContextUtils.getLanguage());
        return sysMenuServiceClient.update(request);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除")
    @RequiresPermissions("sys:menu:delete")
    public Result delete(@PathVariable("id") Long id) {
        SysMenuRequest sysMenuRequest = new SysMenuRequest();
        sysMenuRequest.setId(id);
        return sysMenuServiceClient.delete(sysMenuRequest);
    }

    @GetMapping("/select")
    @Operation(summary = "角色菜单权限")
    @RequiresPermissions("sys:menu:select")
    public Result<List<SysMenu>> select() {
        SysMenuRequest sysMenuRequest = new SysMenuRequest();
        sysMenuRequest.setLanguage(HttpContextUtils.getLanguage());
        return sysMenuServiceClient.select(sysMenuRequest);
    }
}
