package com.github.admin.api.controller.sys;

import com.github.admin.api.websocket.WebSocketServer;
import com.github.admin.client.SysNoticeServiceClient;
import com.github.admin.client.SysNoticeUserServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysNotice;
import com.github.admin.common.request.SysNoticeRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.admin.common.websocketdata.MessageData;
import com.github.admin.common.websocketdata.MessageDataUserList;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


/**
 * 通知管理
 */
@RestController
@RequestMapping("/sys/notice")
@Tag(name = "通知管理")
public class SysNoticeController {
    @Resource
    private WebSocketServer webSocketServer;

    @Resource
    private SysNoticeServiceClient sysNoticeServiceClient;
    @Resource
    private SysNoticeUserServiceClient sysNoticeUserServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
    })
    @RequiresPermissions("sys:notice:all")
    public Result<DataPage<SysNotice>> page(@Parameter(hidden = true) SysNoticeRequest sysNoticeRequest) {
        return sysNoticeServiceClient.page(sysNoticeRequest);
    }

    @GetMapping("/user/page")
    @Operation(summary = "获取被通知的用户")
    @Parameters({
            @Parameter(name = Constant.PAGE, description = "当前页码，从1开始"),
            @Parameter(name = Constant.LIMIT, description = "每页显示记录数"),
            @Parameter(name = Constant.ORDER_FIELD, description = "排序字段"),
            @Parameter(name = Constant.ORDER, description = "排序方式，可选值(asc、desc)")
    })
    @RequiresPermissions("sys:notice:all")
    public Result<DataPage<SysNotice>> userPage(@Parameter(hidden = true) SysNoticeRequest sysNoticeRequest) {
        return sysNoticeServiceClient.getNoticeUserPage(sysNoticeRequest);
    }

    @GetMapping("/mynotice/page")
    @Operation(summary = "获取我的通知")
    @Parameters({
            @Parameter(name = Constant.PAGE, description = "当前页码，从1开始"),
            @Parameter(name = Constant.LIMIT, description = "每页显示记录数"),
            @Parameter(name = Constant.ORDER_FIELD, description = "排序字段"),
            @Parameter(name = Constant.ORDER, description = "排序方式，可选值(asc、desc)")
    })
    public Result<DataPage<SysNotice>> myNoticePage(@Parameter(hidden = true) SysNoticeRequest sysNoticeRequest) {
        sysNoticeRequest.setReceiverId(SecurityUser.getUserId());
        return sysNoticeServiceClient.getMyNoticePage(sysNoticeRequest);
    }

    @PutMapping("/mynotice/read/{noticeId}")
    @Operation(summary = "标记我的通知为已读")
    public Result read(@PathVariable("noticeId") Long noticeId) {
        SysNoticeRequest sysNoticeRequest = new SysNoticeRequest();
        sysNoticeRequest.setNoticeId(noticeId);
        sysNoticeRequest.setReceiverId(SecurityUser.getUserId());
        return sysNoticeUserServiceClient.update(sysNoticeRequest);
    }

    @GetMapping("/mynotice/unread")
    @Operation(summary = "我的通知未读读")
    public Result<Integer> unRead() {
        return sysNoticeUserServiceClient.get(SecurityUser.getUserId());
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:notice:all")
    public Result<SysNotice> get(@PathVariable("id") Long id) {
        return sysNoticeServiceClient.get(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:notice:all")
    public Result save(@RequestBody SysNoticeRequest request) {
        Result<MessageDataUserList> result = sysNoticeServiceClient.save(request);
        if (!result.isSuccess()) {
            return result;
        }
        MessageDataUserList data = result.getData();
        if (data == null || data.getData() == null) {
            return Result.ok();
        }
        MessageData message = data.getData();
        if (request.getReceiverType() == 0) {
            webSocketServer.sendMessageAll(message);
            return Result.ok();
        }
        List<Long> userIdList = data.getUserIdList();
        if (CollectionUtils.isEmpty(userIdList)) {
            return Result.ok();
        }
        webSocketServer.sendMessage(userIdList, message);
        return Result.ok();
    }

    @PostMapping("/update")
    @Operation(summary = "修改")
    @RequiresPermissions("sys:notice:all")
    public Result update(@RequestBody SysNoticeRequest request) {
        Result<MessageDataUserList> result = sysNoticeServiceClient.update(request);
        if (!result.isSuccess()) {
            return result;
        }
        MessageDataUserList data = result.getData();
        if (data == null || data.getData() == null) {
            return Result.ok();
        }
        MessageData message = data.getData();
        if (request.getReceiverType() == 0) {
            webSocketServer.sendMessageAll(message);
            return Result.ok();
        }
        List<Long> userIdList = data.getUserIdList();
        if (CollectionUtils.isEmpty(userIdList)) {
            return Result.ok();
        }
        webSocketServer.sendMessage(userIdList, message);
        return Result.ok();
    }

    @DeleteMapping()
    @Operation(summary = "删除")
    @RequiresPermissions("sys:notice:all")
    public Result delete(@RequestBody List<Long> ids) {
        return sysNoticeServiceClient.delete(ids);
    }

}
