package com.github.admin.api.controller.sys;

import com.github.admin.client.SysOnlineServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysOnlineEntity;
import com.github.admin.common.request.SysOnlineRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 在线用户
 */
@AllArgsConstructor
@RestController
@RequestMapping("/sys/online")
@Tag(name = "在线用户")
public class SysOnlineController {

    @Resource
    private SysOnlineServiceClient sysOnlineServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
    })
    @RequiresPermissions("sys:online:all")
    public Result<DataPage<SysOnlineEntity>> page(@Parameter(hidden = true) SysOnlineRequest request) {
        return sysOnlineServiceClient.page(request);
    }

    @PostMapping("/logout")
    @Operation(summary = "踢出")
    @RequiresPermissions("sys:online:all")
    public Result logout(Long id) {
        return sysOnlineServiceClient.logout(id);
    }
}
