package com.github.admin.api.controller.sys;

import com.github.admin.api.utils.ExcelUtils;
import com.github.admin.client.SysParamsServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.excel.SysParamsExcel;

import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.entity.SysParams;
import com.github.trans.front.common.request.SysParamsRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * 参数管理
 */
@RestController
@RequestMapping("sys/params")
@Tag(name = "参数管理")
public class SysParamsController {
    private static final Logger log = LoggerFactory.getLogger(SysParamsController.class);
    @Resource
    private SysParamsServiceClient sysParamsServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "paramCode", description = "参数编码")
    })
    @RequiresPermissions("sys:params:page")
    public Result<DataPage<SysParams>> page(@Parameter(hidden = true) SysParamsRequest sysParamsRequest) {
        return sysParamsServiceClient.page(sysParamsRequest);
    }

    @GetMapping("{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:params:info")
    public Result<SysParams> get(@PathVariable("id") Long id) {
        return sysParamsServiceClient.findById(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:params:save")
    public Result save(@RequestBody SysParamsRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        request.setParamType(0);
        return sysParamsServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:params:update")
    public Result update(@RequestBody SysParamsRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysParamsServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:params:delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysParamsServiceClient.delete(ids);
    }

    @GetMapping("export")
    @Operation(summary = "导出")
    @RequiresPermissions("sys:params:export")
    @Parameter(name = "paramCode", description = "参数编码")
    public void export(@Parameter(hidden = true) SysParamsRequest request, HttpServletResponse response) throws Exception {
        Result<List<SysParams>> result = sysParamsServiceClient.list(request);
        if (!result.isSuccess()) {
            log.error("sysParamsController export list error,request = {},e = {}", request, result.getMessage());
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        List<SysParams> list = result.getData();
        if (CollectionUtils.isEmpty(list)) {
            log.info("sysParamsController export list is empty");
            return;
        }
        ExcelUtils.exportExcelToTarget(response, null, "参数管理", list, SysParamsExcel.class);
    }
}
