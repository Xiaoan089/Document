package com.github.admin.api.controller.sys;

import com.github.admin.client.SysPostServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysPost;
import com.github.admin.common.request.SysPostRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * 岗位管理
 */
@AllArgsConstructor
@RestController
@RequestMapping("sys/post")
@Tag(name = "岗位管理")
public class SysPostController {

    private SysPostServiceClient sysPostServiceClient;

    @GetMapping("page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)")
    })
    @RequiresPermissions("sys:post:page")
    public Result<DataPage<SysPost>> page(@Parameter(hidden = true) SysPostRequest sysPostRequest) {
        return sysPostServiceClient.page(sysPostRequest);
    }

    @GetMapping("list")
    @Operation(summary = "列表")
    public Result<List<SysPost>> list() {
        return sysPostServiceClient.list(SecurityUser.getSysType());
    }

    @GetMapping("{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:post:info")
    public Result<SysPost> get(@PathVariable("id") Long id) {
        SysPostRequest sysPostRequest = new SysPostRequest();
        sysPostRequest.setId(id);
        return sysPostServiceClient.findById(sysPostRequest);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:post:save")
    public Result save(@RequestBody SysPostRequest sysPostRequest) {
        return sysPostServiceClient.save(sysPostRequest);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:post:update")
    public Result update(@RequestBody SysPostRequest sysPostRequest) {
        return sysPostServiceClient.update(sysPostRequest);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:post:delete")
    public Result delete(@RequestBody List<Long> ids) {
        SysPostRequest sysPostRequest = new SysPostRequest();
        sysPostRequest.setIds(ids);
        return sysPostServiceClient.delete(sysPostRequest);
    }
}
