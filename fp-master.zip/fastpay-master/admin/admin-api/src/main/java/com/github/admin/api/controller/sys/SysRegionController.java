package com.github.admin.api.controller.sys;

import com.github.admin.client.SysRegionServiceClient;
import com.github.admin.common.dto.RegionProvince;
import com.github.admin.common.request.SysRegionRequest;
import com.github.admin.common.response.SysRegionResponse;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 行政区域
 */
@RestController
@RequestMapping("/sys/region")
@Tag(name = "行政区域")
public class SysRegionController {
    @Resource
    private SysRegionServiceClient sysRegionServiceClient;

    @GetMapping("/list")
    @Operation(summary = "列表")
    @Parameter(name = "pid", description = "上级ID")
    @RequiresPermissions("sys:region:list")
    public Result<List<SysRegionResponse>> list(SysRegionRequest request) {
        return sysRegionServiceClient.list(request);
    }

    @GetMapping("/tree")
    @Operation(summary = "树形数据")
    public Result<List<Map<String, Object>>> tree() {
        return sysRegionServiceClient.getTreeList();
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:region:info")
    public Result<SysRegionResponse> findById(@PathVariable("id") Long id) {
        return sysRegionServiceClient.findById(id);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:region:save")
    public Result save(@RequestBody SysRegionRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysRegionServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:region:update")
    public Result update(@RequestBody SysRegionRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysRegionServiceClient.update(request);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除")
    @RequiresPermissions("sys:region:delete")
    public Result delete(@PathVariable("id") Long id) {
        return sysRegionServiceClient.delete(id);
    }

    @GetMapping("/region")
    @Operation(summary = "地区列表")
    @Parameter(name = "threeLevel", description = "是否显示3级   true显示   false不显示")
    public Result<List<RegionProvince>> gerRegion(@RequestParam(value = "threeLevel", defaultValue = "true") boolean threeLevel) {
        return sysRegionServiceClient.getRegion(threeLevel);
    }

}
