package com.github.admin.api.controller.sys;

import com.github.admin.client.SysRoleServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysRole;
import com.github.admin.common.request.BaseAdminRequest;
import com.github.admin.common.request.SysRoleRequest;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.entity.UserDetail;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

import java.util.List;


/**
 * 角色管理
 */
@RestController
@RequestMapping("/sys/role")
@Tag(name = "角色管理")
public class SysRoleController {
    @Resource
    private SysRoleServiceClient sysRoleServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "name", description = "角色名")
    })
    @RequiresPermissions("sys:role:page")
    public Result<DataPage<SysRole>> page(@Parameter(hidden = true) SysRoleRequest sysRoleRequest) {
        return sysRoleServiceClient.page(sysRoleRequest);
    }

    @GetMapping("/list")
    @Operation(summary = "列表")
    @RequiresPermissions("sys:role:list")
    public Result<List<SysRole>> list() {
        UserDetail user = SecurityUser.getUser();
        SysRoleRequest sysRoleRequest = new SysRoleRequest();
        BaseAdminRequest.isSuperAdmin(sysRoleRequest,user);
        return sysRoleServiceClient.list(sysRoleRequest);
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:role:info")
    public Result<SysRole> get(@PathVariable("id") Long id) {
        SysRoleRequest sysRoleRequest = new SysRoleRequest();
        sysRoleRequest.setId(id);
        return sysRoleServiceClient.findByIdOnType(sysRoleRequest);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:role:save")
    public Result save(@RequestBody SysRoleRequest request) {
        return sysRoleServiceClient.save(request);
    }

    @PutMapping()
    @Operation(summary = "修改")
    @RequiresPermissions("sys:role:update")
    public Result update(@RequestBody SysRoleRequest request) {
        request.setUserDetail(SecurityUser.getUser());
        return sysRoleServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:role:delete")
    public Result delete(@RequestBody List<Long> ids) {
        SysRoleRequest sysRoleRequest = new SysRoleRequest();
        sysRoleRequest.setIds(ids);
        return sysRoleServiceClient.delete(sysRoleRequest);
    }
}
