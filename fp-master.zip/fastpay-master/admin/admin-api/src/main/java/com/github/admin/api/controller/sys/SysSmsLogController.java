package com.github.admin.api.controller.sys;

import com.github.admin.client.SysSmsLogServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysSmsLog;
import com.github.admin.common.request.SysSmsLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 短信日志
 */

@RestController
@RequestMapping("/sys/smslog")
@Tag(name = "短信日志")
public class SysSmsLogController {

    @Resource
    private SysSmsLogServiceClient sysSmsLogServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
    })
    @RequiresPermissions("sys:smslog:all")
    public Result<DataPage<SysSmsLog>> page(@Parameter(hidden = true) SysSmsLogRequest request) {
        return sysSmsLogServiceClient.page(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:smslog:all")
    public Result delete(@RequestBody List<Long> ids) {
        return sysSmsLogServiceClient.delete(ids);
    }
}
