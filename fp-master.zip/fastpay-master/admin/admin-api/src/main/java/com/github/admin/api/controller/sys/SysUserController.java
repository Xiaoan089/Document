package com.github.admin.api.controller.sys;

import com.github.admin.api.utils.ExcelUtils;
import com.github.admin.client.SysUserServiceClient;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.excel.SysUserExcel;
import com.github.admin.common.request.BaseAdminRequest;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.response.SysUserResponse;
import com.github.admin.common.user.SecurityUser;
import com.github.admin.common.utils.ConvertUtils;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.entity.UserDetail;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 用户管理
 */
@RestController
@RequestMapping("/sys/user")
@Tag(name = "用户管理")
@Slf4j
public class SysUserController {

    @Resource
    private SysUserServiceClient sysUserServiceClient;

    @GetMapping("/page")
    @Operation(summary = "分页")
    @Parameters({
            @Parameter(name = Constant.PAGE_NO, description = "当前页码，从1开始", required = true),
            @Parameter(name = Constant.PAGE_SIZE, description = "每页显示记录数", required = true),
            @Parameter(name = Constant.ORDER_BY_COLUMN, description = "排序字段"),
            @Parameter(name = Constant.BASE_REQUEST_ASC, description = "排序方式，可选值(asc、desc)"),
            @Parameter(name = "username", description = "用户名"),
            @Parameter(name = "gender", description = "性别"),
            @Parameter(name = "deptId", description = "部门ID")
    })
    @RequiresPermissions("sys:user:page")
    public Result<DataPage<SysUser>> page(@Parameter(hidden = true) SysUserRequest sysUserRequest) {
        UserDetail user = SecurityUser.getUser();

        if (BaseAdminRequest.isSuperAdmin(null,user)) {
            sysUserRequest.setIsSupperAdmin(Boolean.TRUE);
        }
        return sysUserServiceClient.page(sysUserRequest);
    }

    @GetMapping("/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:user:info")
    public Result<SysUser> findById(@PathVariable("id") Long id) {
        SysUserRequest sysUserRequest = new SysUserRequest();
        sysUserRequest.setId(id);
        sysUserRequest.setSysType(1);
        return sysUserServiceClient.findById(sysUserRequest);
    }

    @GetMapping("/info")
    @Operation(summary = "登录用户信息")
    public Result<SysUser> info() {
        SysUser data = ConvertUtils.sourceToTarget(SecurityUser.getUser(), SysUser.class);
        return Result.ok(data);
    }

    @PutMapping("/password")
    @Operation(summary = "修改密码")
    public Result password(@RequestBody SysUserRequest request) {
        request.setId(SecurityUser.getUserId());
        return sysUserServiceClient.password(request);
    }

    @PostMapping
    @Operation(summary = "保存")
    @RequiresPermissions("sys:user:save")
    public Result save(@RequestBody SysUserRequest request) {
        request.setSysType(request.getUserDetail().getSysType());
        return sysUserServiceClient.save(request);
    }

    @PutMapping
    @Operation(summary = "修改")
    @RequiresPermissions("sys:user:update")
    public Result update(@RequestBody SysUserRequest request) {
        request.setNewPassword(request.getPassword());
        request.setUserDetail(SecurityUser.getUser());
        return sysUserServiceClient.update(request);
    }

    @PutMapping("/app")
    @Operation(summary = "修改")
    @RequiresPermissions("sys:user:update")
    public Result updateUserInfo(@RequestBody SysUserRequest request) {
        return sysUserServiceClient.update(request);
    }

    @DeleteMapping
    @Operation(summary = "删除")
    @RequiresPermissions("sys:user:delete")
    public Result delete(@RequestBody List<Long> ids) {
        SysUserRequest sysUserRequest = new SysUserRequest();
        sysUserRequest.setIds(ids);
        return sysUserServiceClient.delete(sysUserRequest);
    }

    @GetMapping("/export")
    @Operation(summary = "导出")
    @RequiresPermissions("sys:user:export")
    @Parameter(name = "username", description = "用户名")
    public void export(@Parameter(hidden = true) SysUserRequest request,HttpServletResponse response) throws Exception {
        Result<List<SysUserResponse>> result = sysUserServiceClient.list(request);
        if (!result.isSuccess()) {
            log.error("sysUserController export list error,result = {}",result.getMessage());
            return;
        }
        List<SysUserResponse> list = result.getData();
        if(CollectionUtils.isEmpty(list)) {
            log.info("sysUserController export list is empty");
            return;
        }
        ExcelUtils.exportExcelToTarget(response, null, "用户管理", list, SysUserExcel.class);
    }
}
