package com.github.admin.api.controller.sys;

import com.github.admin.client.TemplateServiceClient;
import com.github.admin.common.entity.GenTemplate;
import com.github.admin.common.request.GenTemplateRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

/**
 * 模板管理
 */
@RestController
@RequestMapping("/devtools/template")
public class TemplateController {

    @Resource
    private TemplateServiceClient templateServiceClient;

    @GetMapping("/page")
    public Result<DataPage<GenTemplate>> page(GenTemplateRequest request) {
       return templateServiceClient.page(request);
    }

    @GetMapping("/{id}")
    public Result<GenTemplate> get(@PathVariable("id") Long id) {
        return templateServiceClient.getById(id);
    }

    @PostMapping
    public Result save(@RequestBody GenTemplateRequest entity) {
        return templateServiceClient.save(entity);
    }

    @PutMapping
    public Result update(@RequestBody GenTemplateRequest entity) {
        return templateServiceClient.update(entity);
    }

    @DeleteMapping
    public Result delete(@RequestBody List<Long> ids) {
        return templateServiceClient.deleteBatchIds(ids);
    }

    /**
     * 启用
     */
    @PutMapping("/enabled")
    public Result enabled(@RequestBody List<Long> ids) {
       return templateServiceClient.updateStatusBatchEnabled(ids);
    }

    /**
     * 禁用
     */
    @PutMapping("/disabled")
    public Result disabled(@RequestBody List<Long> ids) {
        return templateServiceClient.updateStatusBatchDisabled(ids);
    }
}
