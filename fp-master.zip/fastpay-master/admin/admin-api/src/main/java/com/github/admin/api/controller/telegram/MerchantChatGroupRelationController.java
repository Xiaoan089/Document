package com.github.admin.api.controller.telegram;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantChatGroupRelationClient;
import com.github.trans.front.common.entity.MerchantChatGroupRelation;
import com.github.trans.front.common.request.MerchantChatGroupRelationRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@Api(tags = "TG商户群组绑定")
public class MerchantChatGroupRelationController {


    @Resource
    private MerchantChatGroupRelationClient merchantChatGroupRelationClient;


    @GetMapping("/merchant/chat/group/relation/page")
    @ApiOperation("分页查询TG商户群组绑定")
    @RequiresPermissions("tg:merchantchatgrouprelation:info")
    public Result<DataPage<MerchantChatGroupRelation>> page(MerchantChatGroupRelationRequest request){
        return merchantChatGroupRelationClient.page(request);
    }

    @PutMapping("/merchant/chat/group/relation/updateStatus")
    @ApiOperation("修改TG商户群组绑定状态")
    @LogOperation(value = "修改",description = "修改TG商户群组绑定状态")
    Result updateStatus(@RequestBody MerchantChatGroupRelationRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return merchantChatGroupRelationClient.updateStatus(request);
    }


}
