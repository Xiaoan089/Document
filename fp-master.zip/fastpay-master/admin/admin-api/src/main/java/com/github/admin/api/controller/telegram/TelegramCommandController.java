package com.github.admin.api.controller.telegram;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.TelegramCommandServiceClient;
import com.github.trans.front.common.entity.TelegramCommand;
import com.github.trans.front.common.request.TelegramCommandRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@Api(tags = "TG命令")
public class TelegramCommandController {


    @Resource
    private TelegramCommandServiceClient telegramCommandServiceClient;


    @GetMapping("/telegram/command/page")
    @ApiOperation("分页查询TG命令")
    @RequiresPermissions("tg:tgcommand:info")
    public Result<DataPage<TelegramCommand>> page(TelegramCommandRequest request){
        return telegramCommandServiceClient.page(request);
    }

    @PutMapping("/telegram/command/updateStatus")
    @ApiOperation("修改TG命令状态")
    @LogOperation(value = "修改",description = "修改TG命令状态")
    Result updateStatus(@RequestBody TelegramCommandRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return telegramCommandServiceClient.updateStatus(request);
    }

    @GetMapping("/telegram/command/findById/{id}")
    @ApiOperation("根据ID查询TG命令")
    public Result<TelegramCommand> page(@PathVariable("id") Long id){
        return telegramCommandServiceClient.findById(id);
    }

    @PutMapping("/telegram/command")
    @ApiOperation("修改TG命令")
    @LogOperation(value = "修改",description = "修改TG命令")
    public Result<TelegramCommand> update(@RequestBody TelegramCommandRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return telegramCommandServiceClient.update(request);
    }

}
