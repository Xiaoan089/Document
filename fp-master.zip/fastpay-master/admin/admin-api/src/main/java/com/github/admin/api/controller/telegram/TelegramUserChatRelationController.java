package com.github.admin.api.controller.telegram;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.entity.UserDetail;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.TelegramUserChatRelationServiceClient;
import com.github.trans.front.common.entity.TelegramUserChatRelation;
import com.github.trans.front.common.request.TelegramUserChatRelationRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@Api(tags = "TG用户群组绑定")
public class TelegramUserChatRelationController {


    @Resource
    private TelegramUserChatRelationServiceClient telegramUserChatRelationServiceClient;


    @GetMapping("/telegram/user/chat/page")
    @ApiOperation("分页查询TG用户群组绑定")
    @RequiresPermissions("tg:tguserchatrelation:info")
    public Result<DataPage<TelegramUserChatRelation>> page(TelegramUserChatRelationRequest request){
        return telegramUserChatRelationServiceClient.page(request);
    }


    @PutMapping("/telegram/user/chat/updateStatus")
    @ApiOperation("修改TG用户群组绑定状态")
    @LogOperation(value = "修改",description = "修改TG用户群组绑定状态")
    Result updateStatus(@RequestBody TelegramUserChatRelationRequest request){
        UserDetail user = SecurityUser.getUser();
        request.setUserDetail(user);
        request.setModifiedUser(user.getUsername());
        return telegramUserChatRelationServiceClient.updateStatus(request);
    }

}
