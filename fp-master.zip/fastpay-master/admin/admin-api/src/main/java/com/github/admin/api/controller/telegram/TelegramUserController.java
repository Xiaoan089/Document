package com.github.admin.api.controller.telegram;

import com.github.admin.api.annation.LogOperation;
import com.github.admin.common.user.SecurityUser;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.TelegramUserServiceClient;
import com.github.trans.front.common.entity.TelegramCommand;
import com.github.trans.front.common.entity.TelegramUser;
import com.github.trans.front.common.request.TelegramUserRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(tags = "TG用户绑定")
public class TelegramUserController {


    @Resource
    private TelegramUserServiceClient telegramUserServiceClient;

    @GetMapping("/telegram/user/page")
    @ApiOperation("分页查询TG用户绑定")
    @RequiresPermissions("tg:tguser:info")
    public Result<DataPage<TelegramUser>> page(TelegramUserRequest request){
        return telegramUserServiceClient.page(request);
    }


    @PutMapping("/telegram/user/updateStatus")
    @ApiOperation("修改TG用户绑定状态")
    @LogOperation(value = "修改",description = "修改TG用户绑定状态")
    Result updateStatus(@RequestBody TelegramUserRequest request){
        request.setUserDetail(SecurityUser.getUser());
        return telegramUserServiceClient.updateStatus(request);
    }


    @GetMapping("/telegram/command/findBindUserByCommandId/{id}")
    @ApiOperation("查询TG自选命令绑定的用户")
    public Result<List<TelegramUser>> findBindUserById(@PathVariable("id")Long id){
        return telegramUserServiceClient.findBindUserByCommandId(id);
    }

}
