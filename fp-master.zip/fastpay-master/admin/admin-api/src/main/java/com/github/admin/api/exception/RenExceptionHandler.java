package com.github.admin.api.exception;

import cn.hutool.core.map.MapUtil;
import com.github.admin.client.SysLogErrorServiceClient;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.exception.ExceptionUtils;
import com.github.admin.common.request.SysLogErrorRequest;
import com.github.admin.common.utils.HttpContextUtils;
import com.github.admin.common.utils.IpUtils;
import com.github.admin.common.utils.JsonUtils;
import com.github.framework.core.Result;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;


/**
 * 异常处理器
 */
@Slf4j
@RestControllerAdvice
public class RenExceptionHandler {
    @Resource
    private SysLogErrorServiceClient sysLogErrorServiceClient;

    @ExceptionHandler(DuplicateKeyException.class)
    public Result handleDuplicateKeyException(DuplicateKeyException ex) {
        return Result.fail(AdminErrorMsgEnum.SYSTEM_ERROR);
    }

    @ExceptionHandler(UnauthorizedException.class)
    public Result handleUnauthorizedException(UnauthorizedException ex) {
        return Result.fail(AdminErrorMsgEnum.SYSTEM_ERROR);
    }

    @ExceptionHandler(FeignException.class)
    public Result handleFeignException(FeignException ex) {
        return Result.fail(AdminErrorMsgEnum.SYSTEM_ERROR);
    }

    @ExceptionHandler(Exception.class)
    public Result handleException(Exception ex) {
        log.error(ex.getMessage(), ex);
        saveLog(ex);
        return Result.fail(AdminErrorMsgEnum.SYSTEM_ERROR);
    }

    /**
     * 保存异常日志
     */
    private void saveLog(Exception ex) {
        SysLogErrorRequest logRequest = new SysLogErrorRequest();

        //请求相关信息
        HttpServletRequest request = HttpContextUtils.getHttpServletRequest();
        logRequest.setIp(IpUtils.getIpAddr(request));
        logRequest.setUserAgent(request.getHeader(HttpHeaders.USER_AGENT));
        logRequest.setRequestUri(request.getRequestURI());
        logRequest.setRequestMethod(request.getMethod());
        Map<String, String> params = HttpContextUtils.getParameterMap(request);
        if (MapUtil.isNotEmpty(params)) {
            logRequest.setRequestParams(JsonUtils.toJsonString(params));
        }

        //异常信息
        logRequest.setErrorInfo(ExceptionUtils.getErrorStackTrace(ex));

        //保存
        Result save = sysLogErrorServiceClient.save(logRequest);
        if (!save.isSuccess()) {
            log.error("记录异常信息失败,request = {}",request);
            return;
        }
        log.info("记录异常信息成功");
    }
}
