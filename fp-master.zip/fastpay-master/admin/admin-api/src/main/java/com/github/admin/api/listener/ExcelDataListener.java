package com.github.admin.api.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.github.admin.client.BaseServiceClient;
import com.github.admin.common.utils.ConvertUtils;
import com.github.admin.common.utils.JsonUtils;
import com.github.framework.core.Result;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Excel模板读取类
 */
@Slf4j
public class ExcelDataListener<E, T> extends AnalysisEventListener<T> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelDataListener.class);
    /**
     * 每隔2000条存储数据库，然后清理list，方便内存回收
     */
    private static final int BATCH_COUNT = 2000;
    private final List<E> list = new ArrayList<>();

    /**
     * 通过构造器注入Service
     */
    private final BaseServiceClient<E> baseServiceClient;

    /**
     * 构造方法
     *
     * @param baseServiceClient Service对象
     */
    public ExcelDataListener(BaseServiceClient<E> baseServiceClient) {
        this.baseServiceClient = baseServiceClient;
    }

    /**
     * 每条数据解析完，都会调用此方法
     */
    @Override
    public void invoke(T data, AnalysisContext context) {
        LOGGER.info("解析到一条数据:{}", JsonUtils.toJsonString(data));
        Result<Class<E>> classResult = baseServiceClient.currentModelClass();
        if (!classResult.isSuccess()) {
            log.error("excelDataListener error,result = {}",classResult);
            return;
        }
        E entity = ConvertUtils.sourceToTarget(data, classResult.getData());
        list.add(entity);

        // 达到BATCH_COUNT了，需要去存储一次数据库，防止数据几万条数据在内存，容易OOM
        if (list.size() >= BATCH_COUNT) {
            saveData();
            // 存储完成清理 list
            list.clear();
        }
    }
    /**
     * 所有数据解析完成了 都会来调用
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // 这里也要保存数据，确保最后遗留的数据也存储到数据库
        saveData();
        LOGGER.info("所有数据解析完成！");
    }

    /**
     * 加上存储数据库
     */
    private void saveData() {
        LOGGER.info("{}条数据，开始存储数据库！", list.size());
        Result result = baseServiceClient.insertBatch(list);
        if (!result.isSuccess()) {
            log.error("excelDataListener error,result = {}",result);
            return;
        }
        LOGGER.info("存储数据库成功！");
    }
}
