package com.github.admin.api.oauth2;


import com.github.admin.api.service.ShiroService;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.entity.SysUserToken;
import com.github.admin.common.exception.ErrorCode;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.utils.ConvertUtils;
import com.github.admin.common.utils.MessageUtils;
import com.github.admin.common.entity.UserDetail;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

@Component
public class Oauth2Realm extends AuthorizingRealm {

    @Resource
    private MessageSource messageSource;

    @Lazy
    @Resource
    private ShiroService shiroService;

    /**
     * 判断是否支持token的类型 ****important****
     * 每一个Ream都有一个supports方法，用于检测是否支持此Token,默认的采用了return false
     * @param token
     * @return
     */
    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof Oauth2Token;
    }
    /**
     * 授权 集合会与 @RequiresPermissions()声明的权限方法匹配，通常不调用权限的方法不会执行
     * @param
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        UserDetail user = (UserDetail) principals.getPrimaryPrincipal();

        //用户权限列表
        Set<String> permsSet = shiroService.getUserPermissions(user);

        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.setStringPermissions(permsSet);
        return info;
    }
    /**
     * 认证，登录的时候会调用
     * 调用时机
     * Subject subject = SecurityUtils.getSubject();
     * subject.login(token);
     * 在自定义token过滤器的executeLogin方法也会调用到上面两行，所以也会执行到下面的doGetAuthenticationInfo，每次请求都会认证
     * authenticationToken能强转成字符串，因为用的是自定义的String类型的token
     * @param
     * @return
     * @throws AuthenticationException
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        String accessToken = (String) token.getPrincipal();

        //根据accessToken，查询用户信息
        SysUserToken tokenEntity = shiroService.getByToken(accessToken);
        //token失效
        if (tokenEntity == null || tokenEntity.getExpireDate().getTime() < System.currentTimeMillis()) {
            throw new IncorrectCredentialsException(MessageUtils.getMessage(ErrorCode.TOKEN_INVALID));
        }

        //查询用户信息
        SysUserRequest sysUserRequest = new SysUserRequest();
        sysUserRequest.setId(tokenEntity.getUserId());
        sysUserRequest.setSysType(1);
        SysUser userEntity = shiroService.getUser(sysUserRequest);

        //转换成UserDetail对象
        UserDetail userDetail = ConvertUtils.sourceToTarget(userEntity, UserDetail.class);

        //获取用户对应的部门数据权限
        List<Long> deptIdList = shiroService.getDataScopeList(userDetail.getId());
        userDetail.setDeptIdList(deptIdList);

        //账号锁定
        if (userDetail.getStatus() == 0) {
            throw new LockedAccountException(MessageUtils.getMessage(ErrorCode.ACCOUNT_LOCK));
        }

        return new SimpleAuthenticationInfo(userDetail, accessToken, getName());
    }

//    /**
//     * 自定义密码验证匹配器
//     */
//    @PostConstruct
//    public void initCredentialsMatcher() {
//        setCredentialsMatcher(new SimpleCredentialsMatcher() {
//            @Override
//            public boolean doCredentialsMatch(AuthenticationToken authenticationToken, AuthenticationInfo authenticationInfo) {
//                UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
//                SimpleAuthenticationInfo info = (SimpleAuthenticationInfo) authenticationInfo;
//                // 获取明文密码及密码盐
//                String password = String.valueOf(token.getPassword());
//                String salt = CodecSupport.toString(info.getCredentialsSalt().getBytes());
//
//                return equals(ShiroUtil.encrypt(password, salt), info.getCredentials());
//            }
//        });
//    }
}
