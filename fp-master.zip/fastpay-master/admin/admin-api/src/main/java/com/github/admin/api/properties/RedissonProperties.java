package com.github.admin.api.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "spring.redis.redisson")
@Data
@Component
public class RedissonProperties {
    private Integer model;
    private RedissonSingletonProperties singleton;
    private RedissonSentinelProperties sentinel;
    private RedissonClusterProperties cluster;
}
