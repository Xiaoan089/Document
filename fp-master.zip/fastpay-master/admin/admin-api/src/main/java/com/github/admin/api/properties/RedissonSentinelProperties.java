package com.github.admin.api.properties;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
public class RedissonSentinelProperties {
    private List<String> nodes;
    private String master;
    private String password;
    private String database;
}
