package com.github.admin.api.properties;

import lombok.Data;

@Data
public class RedissonSingletonProperties {
    private String node;
    private String password;
    private String database;
}
