package com.github.admin.api.service;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.entity.SysUserToken;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.entity.UserDetail;

import java.util.List;
import java.util.Set;

/**
 * shiro相关接口

 */
public interface ShiroService {
    /**
     * 获取用户权限列表
     */
    Set<String> getUserPermissions(UserDetail user);

    SysUserToken getByToken(String token);

    /**
     * 根据用户ID，查询用户
     *
     * @param sysUserRequest
     */
    SysUser getUser(SysUserRequest sysUserRequest);

    /**
     * 获取用户对应的部门数据权限
     * @param userId  用户ID
     * @return        返回部门ID列表
     */
    List<Long> getDataScopeList(Long userId);
}
