package com.github.admin.api.service.impl;

import com.github.admin.api.service.ShiroService;
import com.github.admin.client.SysMenuServiceClient;
import com.github.admin.client.SysRoleDataScopeServiceClient;
import com.github.admin.client.SysUserServiceClient;
import com.github.admin.client.SysUserTokenServiceClient;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.entity.SysUserToken;
import com.github.admin.common.enums.SuperAdminEnum;
import com.github.admin.common.request.SysUserRequest;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Service
@Slf4j
public class ShiroServiceImpl implements ShiroService {
    @Resource
    private SysMenuServiceClient sysMenuServiceClient;

    @Resource
    private SysUserServiceClient sysUserServiceClient;

    @Resource
    private SysUserTokenServiceClient sysUserTokenServiceClient;

    @Resource
    private SysRoleDataScopeServiceClient sysRoleDataScopeServiceClient;

    @Override
    public Set<String> getUserPermissions(UserDetail user) {
        //系统管理员，拥有最高权限
        List<String> permissionsList = getPermissionsList(user);
        //用户权限列表
        Set<String> permsSet = new HashSet<>();
        for (String permissions : permissionsList) {
            if (StringUtils.isBlank(permissions)) {
                continue;
            }
            permsSet.addAll(Arrays.asList(permissions.trim().split(",")));
        }

        return permsSet;
    }

    private List<String> getPermissionsList(UserDetail user) {
        if (user.getSuperAdmin() == SuperAdminEnum.YES.value()) {
            Result<List<String>> result = sysMenuServiceClient.getPermissionsList(user);
            if (!result.isSuccess()) {
                log.error("getUserPermissions error,result = {}", result);
                return null;
            }
            return result.getData();
        }
        Result<List<String>> result = sysMenuServiceClient.getUserPermissionsList(user);
        if (!result.isSuccess()) {
            log.error("getUserPermissionsList error,result = {}", result);
            return null;
        }
        return result.getData();
    }

    @Override
    public SysUserToken getByToken(String token) {
        Result<SysUserToken> byToken = sysUserTokenServiceClient.getByToken(token);
        if (!byToken.isSuccess()) {
            log.error("getByToken error,result = {}", byToken);
            return null;
        }
        return byToken.getData();
    }

    @Override
    public SysUser getUser(SysUserRequest sysUserRequest) {
        Result<SysUser> sysUserEntityResult = sysUserServiceClient.findById(sysUserRequest);
        if (!sysUserEntityResult.isSuccess()) {
            log.error("selectById error,result = {}",sysUserEntityResult);
            return null;
        }
        return sysUserEntityResult.getData();
    }

    @Override
    public List<Long> getDataScopeList(Long userId) {
        Result<List<Long>> result = sysRoleDataScopeServiceClient.getDataScopeList(userId);
        if (!result.isSuccess()) {
            log.error("getDataScopeList error,result = {}",result);
            return null;
        }
        return result.getData();
    }
}
