package com.github.admin.api.service.impl;

import com.alibaba.fastjson2.JSON;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.framework.core.Result;
import com.github.framework.telegram.assembly.TelegramMessageAssembly;
import com.github.framework.telegram.config.TelegramConfig;
import com.github.framework.telegram.dto.TelegramMessage;
import com.github.framework.telegram.message.TelegramMessageTemplate;
import com.github.framework.telegram.service.TelegramService;
import com.pengrad.telegrambot.model.request.ParseMode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.File;

@Service
@Slf4j
public class TelegramServiceImpl implements TelegramService {

    @Resource
    private TelegramMessageTemplate telegramMessageTemplate;

    @Override
    public Result receiveMessage(Update update, HttpServletResponse response) {
        log.info("开始发送TG消息,update = {}", JSON.toJSONString(update));
        TelegramMessage telegramMessage = new TelegramMessage();
        Boolean assemblyResult = TelegramMessageAssembly.assemblyParse(telegramMessage, update, ParseMode.HTML);
        Message message = update.getMessage();
        String text = message.getText();
        if (StringUtils.isBlank(text) || !text.equals("/text")) {
            return Result.ok();
        }
        if (!assemblyResult) {
            log.error("封装TG对象失败,update = {}", update);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        telegramMessage.setMessage("test");
        telegramMessage.setTelegramBot(TelegramConfig.TELEGRAM_BOT);
        Result result = telegramMessageTemplate.sendTextMessage(telegramMessage);
        if (!result.isSuccess()) {
            log.error("发送TG消息失败:telegramMessage = {}", telegramMessage);
            return Result.fail(result.getCode(), result.getMessage());
        }
        telegramMessage.setFile(new File("/mnt/admin-api/需求图.jpg"));
        Result result1 = telegramMessageTemplate.sendPhoneMessage(telegramMessage);
        if (!result1.isSuccess()) {
            log.error("发送TG消息失败:telegramMessage = {}", telegramMessage);
            return Result.fail(result1.getCode(), result1.getMessage());
        }
        telegramMessage.setFile(new File("/mnt/admin-api/TG接入流程.pdf"));
        Result result2 = telegramMessageTemplate.sendDocumentMessage(telegramMessage);
        if (!result2.isSuccess()) {
            log.error("发送TG消息失败:telegramMessage = {}", telegramMessage);
            return Result.fail(result2.getCode(), result2.getMessage());
        }
        return Result.ok();
    }
}
