package com.github.admin.api.utils;

import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Component
public class RedissonUtils {

    @Resource
    private RedissonClient redissonClient;


    /**
     * 获取对象值
     *
     * @param key
     * @param <T>
     * @return
     */
    public <T> T getValue(String key) {
        RBucket<T> bucket = redissonClient.getBucket(key);
        return bucket.get();
    }

    /**
     * 获取对象空间
     *
     * @param key
     * @param <T>
     * @return
     */
    public <T> RBucket<T> getBucket(String key) {
        return redissonClient.getBucket(key);
    }

    /**
     * 设置对象的值
     * @param key  键
     * @param value 值
     * @return
     */
    public <T> void setValue(String key, T value) {
        setValue(key, value, 1000 * 60 * 30L);
    }


    /**
     * 设置对象的值
     *
     * @param key  键
     * @param value 值
     * @param time  缓存时间 单位秒 -1 永久缓存
     * @return
     */
    public <T> void setValue(String key, T value, Long time) {
        RBucket<Object> bucket = redissonClient.getBucket(key);
        if (time == -1L) {
            bucket.set(value);
        } else {
            bucket.set(value, time, TimeUnit.SECONDS);
        }
    }

    /**
     * 如果值已经存在则则不设置
     * @param key  键
     * @param value 值
     * @param time  缓存时间 单位秒
     * @return true 设置成功,false 值存在,不设置
     */
    public <T> Boolean trySetValue(String key, T value, Long time) {
        RBucket<Object> bucket = redissonClient.getBucket(key);
        boolean b;
        if (time == -1) {
            b = bucket.setIfAbsent(value);
        } else {
            b = bucket. setIfAbsent(value, Duration.ofSeconds(time));
        }
        return b;
    }

    /**
     * 如果值已经存在则则不设置
     *
     * @param key  键
     * @param value 值
     * @return true 设置成功,false 值存在,不设置
     */
    public <T> Boolean trySetValue(String key, T value) {
        return trySetValue(key, value, 1000 * 60 * 30L);
    }

    /**
     * 删除对象
     *
     * @param key 键
     * @return true 删除成功,false 不成功
     */
    public Boolean delete(String key) {
        return redissonClient.getBucket(key).delete();
    }
}
