package com.github.admin.api.utils;

import lombok.Data;
import org.telegram.telegrambots.meta.api.objects.InputFile;

@Data
public class TgMessage {
    private Long chantId;
    private String message;
    private Integer messageId;
    private String parseMode;
    private InputFile inputFile;
}
