//package com.github.admin.api.controller;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import javax.annotation.Resource;
//
//@SpringBootTest
//public class LoginControllerTest {
//    @Resource
//    private LoginController loginController;
//
//    @Test
//    void captchaTest(){
//        loginController.captcha("a18c1639-1add-4611-b9e8-06f5d7897484");
//    }
//}
