package com.github.admin.api.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MercahntAgentTest {

    @Test
    public void saveMerchantAgent(){

    }


}
