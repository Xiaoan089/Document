package com.github.admin.client;

import com.github.admin.common.entity.GenBaseClass;
import com.github.admin.common.request.BaseClassRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface BaseClassServiceClient {

    @PostMapping("/baseClass/page")
    Result<DataPage<GenBaseClass>> page(@RequestBody BaseClassRequest request);

    @PostMapping("/baseClass/list")
    Result<List<GenBaseClass>> list();

    @GetMapping("/baseClass/save/{id}")
    Result<GenBaseClass> getById(@PathVariable("id") Long id);

    @PostMapping("/baseClass/save")
    Result save(@RequestBody BaseClassRequest entity);

    @PostMapping("/baseClass/update")
    Result update(@RequestBody BaseClassRequest entity);

    @PostMapping("/baseClass/delete")
    Result delete(@RequestBody List<Long> list);

}
