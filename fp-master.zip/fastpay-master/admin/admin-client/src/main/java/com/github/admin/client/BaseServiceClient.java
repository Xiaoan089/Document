package com.github.admin.client;

import com.github.framework.core.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface BaseServiceClient<E> {

    @GetMapping("/base/currentModelClass")
    Result<Class<E>> currentModelClass();

    @PostMapping("/base/insertBatch")
    Result insertBatch(List<E> list);
}
