package com.github.admin.client;

import com.github.admin.common.entity.GenDataSource;
import com.github.admin.common.request.GenDataSourceRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface DataSourceServiceClient {

    @PostMapping("/dataSource/page")
    Result<DataPage<GenDataSource>> page(@RequestBody GenDataSourceRequest request);

    @PostMapping("/dataSource/list")
    Result<List<GenDataSource>> list();

    @GetMapping("/dataSource/get/{id}")
    Result<GenDataSource> get(@PathVariable("id") Long id);

    @GetMapping("/dataSource/test/{id}")
    Result<String> test(@PathVariable("id") Long id);

    @PostMapping("/dataSource/save")
    Result save(@RequestBody GenDataSourceRequest entity);

    @PostMapping("/dataSource/update")
    Result update(@RequestBody GenDataSourceRequest entity);

    @PostMapping("/dataSource/delete")
    Result delete(@RequestBody List<Long> list);

}
