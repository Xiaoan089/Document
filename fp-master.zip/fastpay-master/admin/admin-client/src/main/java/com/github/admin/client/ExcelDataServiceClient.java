package com.github.admin.client;

import com.github.admin.common.entity.TbExcelData;
import com.github.admin.common.request.ExcelDataRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(value = "admin-server")
@RestController
public interface ExcelDataServiceClient extends BaseServiceClient<TbExcelData> {

    @PostMapping("/demo/page")
    Result<DataPage<TbExcelData>> page(@RequestBody ExcelDataRequest request);

    @GetMapping("/demo/findById/{id}")
    Result<TbExcelData> findById(@PathVariable("id") Long id);

    @PostMapping("/demo/save")
    Result save(@RequestBody ExcelDataRequest dto);

    @PostMapping("/demo/update")
    Result update(@RequestBody ExcelDataRequest dto);

    @PostMapping("/demo/delete")
    Result delete(@RequestBody Long[] ids);

    @GetMapping("/demo/export")
    void export(@RequestParam Map<String, Object> params);

    @PostMapping("/demo/list")
    Result<List<TbExcelData>> list(@RequestBody ExcelDataRequest request);

    @GetMapping("/demo/currentModelClass")
    Result<Class<TbExcelData>> currentModelClass();

    @PostMapping("/demo/insertBatch")
    Result insertBatch(List<TbExcelData> list);
}
