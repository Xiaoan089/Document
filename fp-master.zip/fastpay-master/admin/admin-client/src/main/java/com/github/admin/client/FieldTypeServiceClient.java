package com.github.admin.client;

import com.github.admin.common.entity.GenFieldType;
import com.github.admin.common.request.GenFieldTypeRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@FeignClient(value = "admin-server")
@RestController
public interface FieldTypeServiceClient {

    @PostMapping("/fieldType/page")
    Result<DataPage<GenFieldType>> page(@RequestBody GenFieldTypeRequest request);

    @GetMapping("/fieldType/getById/{id}")
    Result<GenFieldType> getById(@PathVariable("id") Long id);

    @PostMapping("/fieldType/findAllAttrType")
    Result<Set<String>> findAllAttrType();

    @PostMapping("/fieldType/save")
    Result save(@RequestBody GenFieldTypeRequest entity);

    @PostMapping("/fieldType/update")
    Result update(@RequestBody GenFieldTypeRequest entity);

    @PostMapping("/fieldType/deleteByIds")
    Result deleteBatchIds(@RequestBody List<Long> list);

}
