package com.github.admin.client;

import com.github.admin.common.entity.GenTableInfo;
import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.request.GenTableFieldRequest;
import com.github.admin.common.request.SysMenuRequest;
import com.github.admin.common.request.TableInfoRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface GeneratorServiceClient {

    @PostMapping("/generator/pageTable")
    Result<DataPage<GenTableInfo>> pageTable(@RequestBody TableInfoRequest request);

    @GetMapping("/generator/getTable/{id}")
    Result<GenTableInfo> getTable(@PathVariable("id") Long id);

    @PostMapping("/generator/updateTable")
    Result updateTable(@RequestBody TableInfoRequest request);

    @PostMapping("/generator/deleteTable")
    Result deleteTable(@RequestBody List<Long> ids);

    @GetMapping("/generator/getDataSourceTableList/{id}")
    Result<List<GenTableInfo>> getDataSourceTableList(@PathVariable("id")Long id);

    @PostMapping("/generator/datasourceTable")
    Result datasourceTable(@RequestBody TableInfoRequest request);

    @PostMapping("/generator/updateTableField/{tableId}")
    Result updateTableField(@PathVariable("tableId") Long tableId,@RequestBody List<GenTableFieldRequest> tableFieldList);

    @PostMapping("/generator/dict")
    Result<List<SysDictType>> dict();

    @PostMapping("/generator/generator")
    Result generator(@RequestBody TableInfoRequest request);

    @PostMapping("/generator/menu")
    Result menu(@RequestBody SysMenuRequest request);

}
