package com.github.admin.client;


import com.github.admin.common.entity.TbNews;
import com.github.admin.common.request.NewsRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface NewsServiceClient {

    @PostMapping("/news/page")
    Result<DataPage<TbNews>> page(@RequestBody NewsRequest request);

    @GetMapping("/news/info/{id}")
    Result<TbNews> info(@PathVariable("id") Long id);

    @PostMapping("/news/save")
    Result save(@RequestBody NewsRequest request);

    @PostMapping("/news/update")
    Result update(@RequestBody NewsRequest request);

    @PostMapping("/news/delete")
    Result delete(@RequestBody List<Long> list);

}
