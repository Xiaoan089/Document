package com.github.admin.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RestController;

@FeignClient(value = "admin-server")
@RestController
public interface OnlineUserServiceClient {


}
