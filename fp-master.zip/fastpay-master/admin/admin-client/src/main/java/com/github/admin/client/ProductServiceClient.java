package com.github.admin.client;

import com.github.admin.common.entity.TbProduct;
import com.github.admin.common.request.ProductRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface ProductServiceClient {

    @PostMapping("/product/page")
    Result<DataPage<TbProduct>> page(@RequestBody ProductRequest request);

    @GetMapping("/product/get/{id}")
    Result<TbProduct> findById(@PathVariable("id") Long id);

    @PostMapping("/product/save")
    Result save(@RequestBody ProductRequest request);

    @PostMapping("/product/update")
    Result update(@RequestBody ProductRequest request);

    @PostMapping("/product/delete")
    Result delete(@RequestBody List<Long> ids);

}
