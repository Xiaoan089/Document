package com.github.admin.client;


import com.github.admin.common.entity.ScheduleJobLog;
import com.github.admin.common.request.ScheduleJobLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;



@FeignClient(value = "admin-server")
@RestController
public interface ScheduleJobLogServiceClient {
    @PostMapping("/scheduleLog/page")
    Result<DataPage<ScheduleJobLog>> page(@RequestBody ScheduleJobLogRequest request);

    @GetMapping("/scheduleLog/findById/{id}")
    Result<ScheduleJobLog> findById(@PathVariable("id") Long id);
}
