package com.github.admin.client;


import com.github.admin.common.entity.ScheduleJob;
import com.github.admin.common.request.ScheduleJobRequest;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@FeignClient(value = "admin-server")
@RestController
public interface ScheduleJobServiceClient {
    @PostMapping("/schedule/page")
    Result<DataPage<ScheduleJob>> page(@RequestBody ScheduleJobRequest request);

    @GetMapping("/schedule/findById/{id}")
    Result<ScheduleJob> findById(@PathVariable("id") Long id);

    @PostMapping("/schedule/save")
    Result save(@RequestBody ScheduleJobRequest request);

    @PostMapping("/schedule/update")
    Result update(@RequestBody ScheduleJobRequest request);

    @PostMapping("/schedule/delete")
    Result deleteBatch(@RequestBody List<Long> ids);

    @PostMapping("/schedule/run")
    Result run(@RequestBody List<Long> ids);

    @PostMapping("/schedule/pause")
    Result pause(@RequestBody List<Long> ids);

    @PostMapping("/schedule/resume")
    Result resume(@RequestBody List<Long> ids);
}
