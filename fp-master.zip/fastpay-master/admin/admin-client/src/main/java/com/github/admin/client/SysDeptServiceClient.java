package com.github.admin.client;

import com.github.admin.common.entity.SysDept;
import com.github.admin.common.request.SysDeptRequest;
import com.github.framework.core.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysDeptServiceClient {

    @PostMapping("/dept/list")
    Result<List<SysDept>> list(@RequestBody SysDeptRequest request);

    @PostMapping("/dept/findById")
    Result<SysDept> findById(@RequestBody SysDeptRequest request);

    @PostMapping("/dept/save")
    Result save(@RequestBody SysDeptRequest request);

    @PostMapping("/dept/update")
    Result update(@RequestBody SysDeptRequest request);

    @PostMapping("/dept/delete")
    Result delete(@RequestBody SysDeptRequest sysDeptRequest);

}
