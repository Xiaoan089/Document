package com.github.admin.client;


import com.github.admin.common.entity.SysDictData;
import com.github.admin.common.request.SysDictDataRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysDictDataServiceClient {


    @PostMapping("/dict/page")
    Result<DataPage<SysDictData>> page(@RequestBody SysDictDataRequest request);

    @GetMapping("/dict/findById/{id}")
    Result<SysDictData> findById(@PathVariable("id") Long id);

    @PostMapping("/dict/save")
    Result save(@RequestBody SysDictDataRequest request);

    @PostMapping("/dict/update")
    Result update(@RequestBody SysDictDataRequest request);

    @PostMapping("/dict/delete")
    Result delete(@RequestBody List<Long> ids);

}
