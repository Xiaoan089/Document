package com.github.admin.client;

import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.request.SysDictTypeRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysDictTypeServiceClient {

    @PostMapping("/dict/type/page")
    Result<DataPage<SysDictType>> page(@RequestBody SysDictTypeRequest request);

    @GetMapping("/dict/type/get/{id}")
    Result<SysDictType> get(@PathVariable("id") Long id);

    @PostMapping("/dict/type/save")
    Result save(@RequestBody SysDictTypeRequest request);

    @PostMapping("/dict/type/update")
    Result update(@RequestBody SysDictTypeRequest dto);

    @PostMapping("/dict/type/delete")
    Result delete(@RequestBody List<Long> ids);

    @GetMapping("/dict/type/all")
    Result<List<SysDictType>> all();
}
