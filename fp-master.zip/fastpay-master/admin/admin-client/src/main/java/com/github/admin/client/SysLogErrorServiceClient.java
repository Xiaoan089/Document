package com.github.admin.client;

import com.github.admin.common.entity.SysLogError;
import com.github.admin.common.request.SysLogErrorRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysLogErrorServiceClient {

    @PostMapping("/log/error/selectListSelective")
    Result<List<SysLogError>> selectListSelective(@RequestBody SysLogErrorRequest request);

    @PostMapping("/log/error/page")
    Result<DataPage<SysLogError>> page(@RequestBody SysLogErrorRequest request);

    @PostMapping("/log/error/save")
    Result save(@RequestBody SysLogErrorRequest logRequest);
}
