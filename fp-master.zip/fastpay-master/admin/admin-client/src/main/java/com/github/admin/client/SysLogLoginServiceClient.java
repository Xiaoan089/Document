package com.github.admin.client;

import com.github.admin.common.entity.SysLogLogin;
import com.github.admin.common.request.SysLogLoginRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysLogLoginServiceClient {

    @PostMapping("/log/login/sysLogLogiPage")
    Result<DataPage<SysLogLogin>> page(@RequestBody SysLogLoginRequest request);

    @PostMapping("/log/login/list")
    Result<List<SysLogLogin>> list(@RequestBody SysLogLoginRequest request);

    @PostMapping("/log/save")
    Result save(@RequestBody SysLogLoginRequest request);
}
