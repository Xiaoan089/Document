package com.github.admin.client;

import com.github.admin.common.entity.SysLogOperation;
import com.github.admin.common.request.SysLogOperationRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysLogOperationServiceClient {

    @PostMapping("/log/operation/page")
    Result<DataPage<SysLogOperation>> page(@RequestBody SysLogOperationRequest request);

    @PostMapping("/log/operation/selectListBySelective")
    Result<List<SysLogOperation>> selectListBySelective(@RequestBody SysLogOperationRequest request);

    @PostMapping("/log/operation/save")
    Result save(@RequestBody SysLogOperationRequest log);
}
