package com.github.admin.client;


import com.github.admin.common.entity.SysMailLog;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@FeignClient(value = "admin-server")
@RestController
public interface SysMailLogServiceClient {

    @PostMapping("/sysMailLog/page")
    Result<DataPage<SysMailLog>> page(@RequestBody SysMailLogRequest mailLogRequest);

    @PostMapping("/sysMailLog/delete")
    Result delete(@RequestBody Long[] ids);

}
