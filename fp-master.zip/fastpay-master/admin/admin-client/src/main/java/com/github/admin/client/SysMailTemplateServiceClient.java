package com.github.admin.client;

import com.github.admin.common.entity.SysMailTemplate;
import com.github.admin.common.request.EmailConfigRequest;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.admin.common.request.SysMailTemplateRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.dto.EmailSetting;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysMailTemplateServiceClient {

    @PostMapping("/sysMailTemplate/page")
    Result<DataPage<SysMailTemplate>> page(@RequestBody SysMailTemplateRequest templateRequest);

    @GetMapping("/sysMailTemplate/config")
    Result<EmailSetting> config();

    @PostMapping("/sysMailTemplate/saveConfig")
    Result saveConfig(@RequestBody EmailConfigRequest config);

    @GetMapping("/sysMailTemplate/info/{id}")
    Result<SysMailTemplate> info(@PathVariable("id") Long id);

    @PostMapping("/sysMailTemplate/save")
    Result save(@RequestBody SysMailTemplateRequest request);

    @PostMapping("/sysMailTemplate/update")
    Result update(@RequestBody SysMailTemplateRequest request);

    @PostMapping("/sysMailTemplate/delete")
    Result delete(@RequestBody List<Long> ids);

    @PostMapping("/sysMailTemplate/send")
    Result send(@RequestBody SysMailLogRequest mailLogRequest);


}
