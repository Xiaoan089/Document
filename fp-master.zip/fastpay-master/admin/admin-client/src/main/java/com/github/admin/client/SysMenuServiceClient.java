package com.github.admin.client;

import com.github.admin.common.entity.SysMenu;
import com.github.admin.common.request.SysMenuRequest;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysMenuServiceClient {

    @PostMapping("/menu/nav")
    Result<List<SysMenu>> nav(@RequestBody SysMenuRequest sysMenuRequest);

    @PostMapping("/menu/list")
    Result<SysMenu> list(@RequestBody SysMenuRequest type);

    @PostMapping("/menu/findById")
    Result<SysMenu> findById(@RequestBody SysMenuRequest id);

    @PostMapping("/menu/save")
    Result save(@RequestBody SysMenuRequest request);

    @PostMapping("/menu/update")
    Result update(@RequestBody SysMenuRequest dto);

    @PostMapping("/menu/delete")
    Result delete(@RequestBody SysMenuRequest sysMenuRequest);

    @PostMapping("/menu/select")
    Result<List<SysMenu>> select(@RequestBody SysMenuRequest sysMenuRequest);

    @PostMapping("/menu/getPermissionsList")
    Result<List<String>> getPermissionsList(@RequestBody UserDetail user);

    @PostMapping("/menu/getUserPermissionsList")
    Result<List<String>> getUserPermissionsList(@RequestBody UserDetail user);
}
