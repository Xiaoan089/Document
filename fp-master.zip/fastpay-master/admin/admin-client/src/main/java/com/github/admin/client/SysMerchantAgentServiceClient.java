package com.github.admin.client;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.common.entity.MerchantAgent;
import com.github.trans.front.common.request.MerchantAgentRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;


@FeignClient(value = "admin-server")
@RestController
public interface SysMerchantAgentServiceClient {

    @PostMapping("/admin/merchantAgent/save")
    Result save(@RequestBody MerchantAgentRequest request);

    @PostMapping("/admin/merchantAgent/update")
    Result update(@RequestBody MerchantAgentRequest request);

    @PostMapping("/admin/merchantAgent/delete")
    Result delete(@RequestBody MerchantAgentRequest request);

    @PostMapping("/admin/merchantAgent/updateAgentPassword")
    Result updateAgentPassword(@RequestBody MerchantAgentRequest request);

    @PostMapping("/admin/merchantAgent/updateAgentFundPassword")
    Result updateAgentFundPassword(@RequestBody MerchantAgentRequest request);

    @GetMapping("/admin/merchantAgent/findById/{id}")
    Result<MerchantAgent> findById(@PathVariable("id") Long id);

    @PostMapping("/admin/merchantAgent/page")
    Result<DataPage<MerchantAgent>> page(@RequestBody MerchantAgentRequest request);


}
