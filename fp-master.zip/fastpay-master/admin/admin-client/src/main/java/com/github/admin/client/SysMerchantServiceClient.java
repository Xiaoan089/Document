package com.github.admin.client;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.common.entity.Merchant;
import com.github.trans.front.common.request.MerchantRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "admin-server")
@RestController
public interface SysMerchantServiceClient {

    @PostMapping("/admin/merchant/save")
    Result save(@RequestBody MerchantRequest request);

    @PostMapping("/admin/merchant/update")
    Result update(@RequestBody MerchantRequest request);

    @PostMapping("/admin/merchant/delete")
    Result delete(@RequestBody MerchantRequest request);

    @PostMapping("/admin/merchant/page")
    Result<DataPage<Merchant>> page(@RequestBody MerchantRequest request);

    @PostMapping("/admin/merchant/updatePassword")
    Result updatePassword(@RequestBody MerchantRequest request);

    @PostMapping("/admin/merchant/updateFundPassword")
    Result updateFundPassword(@RequestBody MerchantRequest request);

    @GetMapping("/admin/merchant/findById/{id}")
    Result<Merchant> findById(@PathVariable("id") Long id);

}
