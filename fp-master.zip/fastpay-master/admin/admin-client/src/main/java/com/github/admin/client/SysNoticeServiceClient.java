package com.github.admin.client;

import com.github.admin.common.entity.SysNotice;
import com.github.admin.common.request.SysNoticeRequest;
import com.github.admin.common.websocketdata.MessageDataUserList;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysNoticeServiceClient {
    @PostMapping("/notice/page")
    Result<DataPage<SysNotice>> page(@RequestBody SysNoticeRequest sysNoticeRequest);

    @PostMapping("/notice/user/page")
    Result<DataPage<SysNotice>> getNoticeUserPage(@RequestBody SysNoticeRequest sysNoticeRequest);

    @PostMapping("/notice/mynotice/page")
    Result<DataPage<SysNotice>> getMyNoticePage(@RequestBody SysNoticeRequest sysNoticeRequest);

    @GetMapping("/notice/get/{id}")
    Result<SysNotice> get(@PathVariable("id") Long id);

    @PostMapping("/notice/save")
    Result<MessageDataUserList> save(@RequestBody SysNoticeRequest request);

    @PostMapping("/notice/update")
    Result update(@RequestBody SysNoticeRequest request);

    @PostMapping("/notice/delete")
    Result delete(@RequestBody List<Long> ids);
}
