package com.github.admin.client;

import com.github.admin.common.request.SysNoticeRequest;
import com.github.framework.core.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "admin-server")
@RestController
public interface SysNoticeUserServiceClient {

    @PostMapping("/notice/user/update")
    Result update(@RequestBody SysNoticeRequest sysNoticeRequest);

    @GetMapping("/notice/user/getUnReadNoticeCount/{id}")
    Result<Integer> get(@PathVariable("id") Long userId);
}
