package com.github.admin.client;

import com.github.admin.common.entity.SysOnlineEntity;
import com.github.admin.common.request.SysOnlineRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "admin-server")
@RestController
public interface SysOnlineServiceClient {

    @PostMapping("/online/page")
    Result<DataPage<SysOnlineEntity>> page(@RequestBody SysOnlineRequest request);

    @GetMapping("/online/logout")
    Result logout(@RequestParam("id") Long id);


}
