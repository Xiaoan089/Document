package com.github.admin.client;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.entity.SysParams;
import com.github.trans.front.common.request.SysParamsRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysParamsServiceClient {
    @PostMapping("/params/page")
    Result<DataPage<SysParams>> page(@RequestBody SysParamsRequest sysParamsRequest);

    @GetMapping("/params/findById/{id}")
    Result<SysParams> findById(@PathVariable("id") Long id);

    @PostMapping("/params/save")
    Result save(@RequestBody SysParamsRequest request);

    @PostMapping("/params/update")
    Result update(@RequestBody SysParamsRequest request);

    @PostMapping("/params/delete")
    Result delete(@RequestBody List<Long> ids);

    @PostMapping("/params/list")
    Result<List<SysParams>> list(@RequestBody SysParamsRequest request);

    @PostMapping("/params/getValueObject")
    Result getValueObject(@RequestBody SysParamsRequest request);

    @PostMapping("/params/getValueByCode")
    Result<String> getValueByCode(@RequestBody String paramCode);

    @PostMapping("/params/updateValueByCode")
    Result updateValueByCode(@RequestBody SysParamsRequest request);
}
