package com.github.admin.client;

import com.github.admin.common.entity.SysPost;
import com.github.admin.common.request.SysPostRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysPostServiceClient {

    @PostMapping("/post/page")
    Result<DataPage<SysPost>> page(@RequestBody SysPostRequest sysPostRequest);

    @GetMapping("/post/list/{sysType}")
    Result<List<SysPost>> list(@PathVariable("sysType") Integer sysType);

    @PostMapping("/post/findById")
    Result<SysPost> findById(@RequestBody SysPostRequest sysPostRequest);

    @PostMapping("/post")
    Result save(@RequestBody SysPostRequest sysPostRequest);

    @PostMapping("/post/update")
    Result update(@RequestBody SysPostRequest sysPostRequest);

    @PostMapping("/post/delete")
    Result delete(@RequestBody SysPostRequest sysPostRequest);
}
