package com.github.admin.client;

import com.github.admin.common.dto.RegionProvince;
import com.github.admin.common.request.SysRegionRequest;
import com.github.admin.common.response.SysRegionResponse;
import com.github.framework.core.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(value = "admin-server")
@RestController
public interface SysRegionServiceClient {

    @PostMapping("/region/list")
    Result<List<SysRegionResponse>> list(@RequestBody SysRegionRequest request);

    @GetMapping("/region/tree")
    Result<List<Map<String, Object>>> getTreeList();

    @GetMapping("/region/findById/{id}")
    Result<SysRegionResponse> findById(@PathVariable("id") Long id);

    @PostMapping("/region/save")
    Result save(@RequestBody SysRegionRequest request);

    @PostMapping("/region/update")
    Result update(@RequestBody SysRegionRequest request);

    @GetMapping("/region/delete/{id}")
    Result delete(@PathVariable("id") Long id);

    @GetMapping("/region/getRegion")
    Result<List<RegionProvince>> getRegion(@RequestParam(value = "threeLevel", defaultValue = "true")boolean threeLevel);
}
