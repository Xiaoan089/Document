package com.github.admin.client;

import com.github.framework.core.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysRoleDataScopeServiceClient {

    @GetMapping("/role/data/scope/getDataScopeList")
    Result<List<Long>> getDataScopeList(@RequestParam("userId") Long userId);
}
