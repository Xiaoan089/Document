package com.github.admin.client;

import com.github.admin.common.entity.SysRole;
import com.github.admin.common.request.SysRoleRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysRoleServiceClient {
    @PostMapping("/role/page")
    Result<DataPage<SysRole>> page(@RequestBody SysRoleRequest sysRoleRequest);

    @PostMapping("/role/list")
    Result<List<SysRole>> list(@RequestBody SysRoleRequest sysRoleRequest);

    @PostMapping("/role/findByIdOnType/")
    Result<SysRole> findByIdOnType(@RequestBody SysRoleRequest sysRoleRequest);

    @PostMapping("/role/save")
    Result save(@RequestBody SysRoleRequest request);

    @PostMapping("/role/update")
    Result update(@RequestBody SysRoleRequest request);

    @PostMapping("/role/delete")
    Result delete(@RequestBody SysRoleRequest sysRoleRequest);
}
