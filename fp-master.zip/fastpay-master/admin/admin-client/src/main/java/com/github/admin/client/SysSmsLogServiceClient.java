package com.github.admin.client;


import com.github.admin.common.entity.SysSmsLog;
import com.github.admin.common.request.SysSmsLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysSmsLogServiceClient {

    @PostMapping("/smsLog/page")
    Result<DataPage<SysSmsLog>> page(@RequestBody SysSmsLogRequest request);

    @PostMapping("/smsLog/delete")
    Result delete(@RequestBody List<Long> ids);

}
