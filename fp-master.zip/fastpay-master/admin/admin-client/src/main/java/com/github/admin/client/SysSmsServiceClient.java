package com.github.admin.client;

import com.github.admin.common.entity.SysSms;
import com.github.admin.common.request.SysSmsRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysSmsServiceClient {

    @PostMapping("/sms/page")
    Result<DataPage<SysSms>> page(@RequestBody SysSmsRequest sysSmsRequest);

    @PostMapping("/sms/save")
    Result save(@RequestBody SysSmsRequest request);

    @PostMapping("/sms/update")
    Result update(@RequestBody SysSmsRequest request);

    @GetMapping("/sms/findById/{id}")
    Result<SysSms> findById(@PathVariable("id") Long id);

    @PostMapping("/sms/send")
    Result send(@RequestBody SysSmsRequest smsRequest);

    @PostMapping("/sms/delete")
    Result delete(@RequestBody List<Long> ids);


}
