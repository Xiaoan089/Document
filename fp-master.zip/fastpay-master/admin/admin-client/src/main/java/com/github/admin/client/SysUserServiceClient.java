package com.github.admin.client;


import com.github.admin.common.entity.SysUser;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.response.SysUserResponse;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface SysUserServiceClient {

    @PostMapping("/user/page")
    Result<DataPage<SysUser>> page(@RequestBody SysUserRequest sysUserRequest);

    @PostMapping("/user/findById")
    Result<SysUser> findById(@RequestBody SysUserRequest sysUserRequest);

    @PostMapping("/user/password")
    Result password(@RequestBody SysUserRequest dto);

    @PostMapping("/user/save")
    Result save(@RequestBody SysUserRequest request);

    @PostMapping("/user/update")
    Result update(@RequestBody SysUserRequest request);

    @PostMapping("/user/delete")
    Result delete(@RequestBody SysUserRequest sysUserRequest);

    @PostMapping("/user/export")
    void export(@RequestBody SysUserRequest request);

    @PostMapping("/user/getByUserName")
    Result<SysUser> getByUsername(@RequestBody SysUserRequest request);

    @PostMapping("/user/list")
    Result<List<SysUserResponse>> list(@RequestBody SysUserRequest request);
}
