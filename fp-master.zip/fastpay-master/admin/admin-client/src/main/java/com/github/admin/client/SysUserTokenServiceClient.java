package com.github.admin.client;

import com.github.admin.common.entity.SysUserToken;
import com.github.framework.core.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@FeignClient(value = "admin-server")
@RestController
public interface SysUserTokenServiceClient {

    @GetMapping("/token/getByToken")
    Result<SysUserToken> getByToken(@RequestParam("token") String token);

    @GetMapping("/token/createToken/{id}")
    Result createToken(@PathVariable("id") Long id);

    @GetMapping("/token/logout/{id}")
    void logout(@PathVariable("id") Long id);
}
