package com.github.admin.client;

import com.github.admin.common.entity.GenTemplate;
import com.github.admin.common.request.GenTemplateRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "admin-server")
@RestController
public interface TemplateServiceClient {


    @PostMapping("/template/page")
    Result<DataPage<GenTemplate>> page(@RequestBody GenTemplateRequest request);

    @GetMapping("/template/getById/{id}")
    Result<GenTemplate> getById(@PathVariable("id") Long id);

    @PostMapping("/template/save")
    Result save(@RequestBody GenTemplateRequest request);

    @PostMapping("/template/update")
    Result update(@RequestBody GenTemplateRequest request);

    @PostMapping("/template/delete")
    Result deleteBatchIds(@RequestBody List<Long> list);

    @PostMapping("/template/updateStatusBatchEnabled")
    Result updateStatusBatchEnabled(@RequestBody List<Long> ids);

    @PostMapping("/template/updateStatusBatchDisabled")
    Result updateStatusBatchDisabled(@RequestBody List<Long> ids);

}
