package com.github.admin.common.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 邮件配置信息
 *
 * @author Mark sunlightcs@gmail.com
 */
@Data
public class EmailSetting implements Serializable {
    /**
     * SMTP
     */
    @NotBlank(message = "{email.smtp.require}")
    private String smtp;

    /**
     * 端口号
     */
    @NotNull(message = "{email.port.require}")
    private Integer port;

    /**
     * 邮箱账号
     */
    @NotBlank(message = "{email.username.require}")
    private String username;

    /**
     * 邮箱密码
     */
    @NotBlank(message = "{email.password.require}")
    private String password;
}
