package com.github.admin.common.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class ParamSetting implements Serializable {
    private String packageName;
    private String version;
    private String author;
    private String email;
    private String backendPath;
    private String frontendPath;
}
