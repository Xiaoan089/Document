package com.github.admin.common.dto;

import lombok.Data;

import java.io.Serializable;

@Data

public class PaymentSetting implements Serializable {

    //系统派单开关：1开启，2关闭
    private Integer openStatus = 1;

    //商户订单匹配时间（秒）
    private Integer merchantMatchTime = 60;

    //商户支付时间（秒 ）
    private Integer merchantPayTime = 300;

    //入款订单，超时x时间置为待确认,秒
    private Integer setPlatformHandleTime = 5;

    //卖出订单，系统置位失败时间,在超时时间的基础上加x分钟
    private Integer sysSetFailedTime = 30;

    //线下回调单，自动成功时间
    private Integer offlineAutoSuccessMinute = 20;

    //轮巡户快到限额是，匹配时间最低时间间隔（秒）
    private Integer pollAccountLimitMatchTime = 10;
}
