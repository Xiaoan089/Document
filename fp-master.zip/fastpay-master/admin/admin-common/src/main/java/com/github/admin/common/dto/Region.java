package com.github.admin.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;


@Data
@Schema(description = "地区管理")
public class Region implements Serializable {


    @Schema(description = "地区ID")
    private Long id;

    @JsonIgnore
    private Long pid;

    @Schema(description = "名称")
    private String name;
}
