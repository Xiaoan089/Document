package com.github.admin.common.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;


@Schema(description = "市")
@Data
public class RegionCity extends Region {
    @Schema(description = "区、县列表")
    private List<Region> counties = new ArrayList<>();
}
