package com.github.admin.common.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;


@Schema(description = "省")
@Data
public class RegionProvince extends Region {
    @Schema(description = "市列表")
    private List<Region> cities = new ArrayList<>();
}
