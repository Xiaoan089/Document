package com.github.admin.common.entity;

/**
 * 数据库类型
 */
public enum DbTypeEntity {
	/**
	 * 支持MySQL、Oracle、SQLServer、PostgreSQL
	 */
	MySQL("com.mysql.cj.jdbc.Driver"),
	Oracle("oracle.jdbc.driver.OracleDriver"),
	SQLServer("com.microsoft.sqlserver.jdbc.SQLServerDriver"),
	PostgreSQL("org.postgresql.Driver"),
	DM("dm.jdbc.driver.DmDriver");

	private final String driverClass;

	DbTypeEntity(String driverClass) {
		this.driverClass = driverClass;
	}

	public String getDriverClass() {
		return driverClass;
	}
}
