package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;


@Data
public class GenBaseClass extends BaseEntity {
	/**
	 * 基类包名
	 */
	private String packageName;
    /**
     * 基类编码
     */
	private String code;
    /**
     * 公共字段，多个用英文逗号分隔
     */
	private String fields;
    /**
     * 备注
     */
	private String remark;

}
