package com.github.admin.common.entity;


import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.List;

@Data
public class GenTemplate extends BaseEntity {

    /**
     * 名称
     */
	private String name;
    /**
     * 内容
     */
	private String content;
    /**
     * 文件名
     */
	private String fileName;
	/**
	 * 生成路径
	 */
	private String path;

	private List<Long> ids;
}
