package com.github.admin.common.entity;

import com.github.admin.common.request.BaseAdminRequest;
import lombok.Data;

@Data
public class ParamEntity extends BaseAdminRequest {
    private String packageName;
    private String version;
    private String author;
    private String email;
    private String backendPath;
    private String frontendPath;
}
