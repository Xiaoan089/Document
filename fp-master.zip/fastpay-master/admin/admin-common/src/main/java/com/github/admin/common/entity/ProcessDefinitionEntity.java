package com.github.admin.common.entity;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ProcessDefinitionEntity {
    @Schema(description = "id")
    private String id;
    @Schema(description = "是否挂起")
    private boolean isSuspended;
}
