package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class ScheduleJobLog extends BaseEntity {

    /**
     * 任务id
     */
    private Long jobId;
    /**
     * spring bean名称
     */
    private String beanName;
    /**
     * 参数
     */
    private String params;
    /**
     * 失败信息
     */
    private String error;
    /**
     * 耗时(单位：毫秒)
     */
    private Integer times;
}
