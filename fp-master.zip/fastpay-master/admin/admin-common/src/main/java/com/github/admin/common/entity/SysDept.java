package com.github.admin.common.entity;

import com.github.admin.common.utils.TreeNode;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;


@Data
public class SysDept extends TreeNode<SysDept> {
    /**
     * 所有上级ID，用逗号分开
     */
    private String pids;
    /**
     * 部门名称
     */
    private String name;
    /**
     * 负责人ID
     */
    private Long leaderId;
    /**
     * 排序
     */
    private Integer sort;

    /**
     * 系统类型
     */
    private Integer sysType;

    /**
     * 上级部门名称
     */
    private String parentName;

    @Schema(description = "负责人名称")
    private String leaderName;

    private List<Long> deptIdList;
}
