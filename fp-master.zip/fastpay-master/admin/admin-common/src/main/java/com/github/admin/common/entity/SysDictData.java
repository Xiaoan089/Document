package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;


@Data
public class SysDictData extends BaseEntity {
    /**
     * 字典类型ID
     */
    private Long dictTypeId;
    /**
     * 字典标签
     */
    private String dictLabel;
    /**
     * 字典key
     */
    private String dictKey;
    /**
     * 字典值
     */
    private String dictValue;
    /**
     * 排序
     */
    private Integer sort;
}
