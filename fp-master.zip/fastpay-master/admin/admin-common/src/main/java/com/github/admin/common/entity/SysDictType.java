package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class SysDictType extends BaseEntity {
    /**
     * 字典类型
     */
    private String dictType;
    /**
     * 字典名称
     */
    private String dictName;
    /**
     * 排序
     */
    private Integer sort;

    private List<SysDictData> dataList = new ArrayList<>();

}
