package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.Date;

/**
 * 通知管理
 */
@Data
public class SysNotice extends BaseEntity {
    /**
     * 通知类型
     */
    private Integer noticeType;
    /**
     * 标题
     */
    private String title;
    /**
     * 内容
     */
    private String content;
    /**
     * 接收者  0：全部  1：部门
     */
    private Integer receiverType;
    /**
     * 接收者ID，用逗号分开
     */
    private String receiverTypeIds;
    /**
     * 发送状态  0：草稿  1：已发布
     */
    private Integer status;
    /**
     * 发送者
     */
    private String senderName;
    /**
     * 发送时间
     */
    private Date senderDate;
    /**
     * 接收者
     */
    private String receiverName;
    /**
     * 阅读状态  0：未读  1：已读
     */
    private Integer readStatus;
    /**
     * 阅读时间
     */
    private Date readDate;

    private Long receiverId;

    private String username;
}
