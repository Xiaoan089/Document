package com.github.admin.common.entity;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 我的通知
 */
@Data
public class SysNoticeUser implements Serializable {
    /**
     * 通知ID
     */
    private Long noticeId;
    /**
     * 接收者ID
     */
    private Long receiverId;
    /**
     * 阅读状态  0：未读  1：已读
     */
    private Integer readStatus;
    /**
     * 阅读时间
     */
    private Date readDate;
}
