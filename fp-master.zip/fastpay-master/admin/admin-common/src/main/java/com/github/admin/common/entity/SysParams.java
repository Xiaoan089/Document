package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SysParams extends BaseEntity {

    private String paramCode;
    private String paramValue;
    private Integer paramType;

}
