package com.github.admin.common.entity;

import com.github.admin.common.utils.TreeNode;
import lombok.Data;

import java.util.Date;

/**
 * 行政区域
 */
@Data
public class SysRegion extends TreeNode<SysRegion> {
    /**
     * 上级ID，一级为0
     */
    private Long pid;
    /**
     * 名称
     */
    private String name;
    /**
     * 层级
     */
    private Integer treeLevel;
    /**
     * 排序
     */
    private Long sort;
    /**
     * 是否叶子节点  0：否   1：是
     */
    private Integer leaf;
    /**
     * 上级名称
     */
    private String parentName;
}
