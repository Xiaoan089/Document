package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.List;

@Data
public class SysRole extends BaseEntity {
    /**
     * 角色名称
     */
    private String name;
    /**
     * 部门ID
     */
    private Long deptId;

    private Integer sysType;


    private List<Long> menuIdList;


    private List<Long> deptIdList;

    private List<Long> ids;
}
