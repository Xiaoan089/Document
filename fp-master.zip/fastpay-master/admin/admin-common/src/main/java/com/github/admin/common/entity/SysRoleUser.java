package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

/**
 * 角色用户关系
 *
 */
@Data
public class SysRoleUser extends BaseEntity {
    /**
     * 角色ID
     */
    private Long roleId;
    /**
     * 用户ID
     */
    private Long userId;

}
