package com.github.admin.common.entity;

import com.github.admin.common.config.SmsConfig;
import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

/**
 * 短信
 */
@Data
public class SysSms extends BaseEntity {

    /**
     * 短信编码
     */
    private String smsCode;
    /**
     * 平台类型
     */
    private Integer platform;
    /**
     * 短信配置
     */
    private String smsConfig;
    /**
     * 备注
     */
    private String remark;


    private SmsConfig config;
}
