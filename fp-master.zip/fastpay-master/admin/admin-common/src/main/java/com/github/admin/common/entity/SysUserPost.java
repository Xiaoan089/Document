package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

@Data
public class SysUserPost extends BaseEntity {
    /**
     * 岗位ID
     */
    private Long postId;
    /**
     * 用户ID
     */
    private Long userId;
}
