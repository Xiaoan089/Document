package com.github.admin.common.entity;
import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.Date;

@Data
public class SysUserToken extends BaseEntity {

    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 用户token
     */
    private String token;
    /**
     * 过期时间
     */
    private Date expireDate;

    private Integer sysType;
}
