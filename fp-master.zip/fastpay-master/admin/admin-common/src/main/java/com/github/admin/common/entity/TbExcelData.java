package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.Date;

/**
 * Excel导入演示
 */
@Data
public class TbExcelData extends BaseEntity {
    /**
     * 学生姓名
     */
    private String realName;
    /**
     * 身份证
     */
    private String userIdentity;
    /**
     * 家庭地址
     */
    private String address;
    /**
     * 入学日期
     */
    private Date joinDate;
    /**
     * 班级名称
     */
    private String className;
}
