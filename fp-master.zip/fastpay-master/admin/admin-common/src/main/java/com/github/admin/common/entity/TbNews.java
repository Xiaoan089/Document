package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.Date;

/**
 * 新闻
 */
@Data
public class TbNews extends BaseEntity {

    /**
     * 标题
     */
    private String title;
    /**
     * 内容
     */
    private String content;
    /**
     * 发布时间
     */
    private Date pubDate;
    /**
     * 创建者dept_id
     */
    private Long deptId;

}
