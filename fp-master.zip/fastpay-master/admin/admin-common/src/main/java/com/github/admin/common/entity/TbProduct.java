package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * 产品管理
 */
@Data
public class TbProduct extends BaseEntity {
    /**
     * 产品名称
     */
    private String name;
    /**
     * 产品介绍
     */
    private String content;

    @Schema(description = "产品参数列表")
    private List<TbProductParams> subList;
}
