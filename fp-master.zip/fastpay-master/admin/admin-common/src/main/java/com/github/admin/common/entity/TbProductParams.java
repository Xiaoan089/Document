package com.github.admin.common.entity;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;



@Data
public class TbProductParams extends BaseEntity {
    /**
     * 参数名
     */
    private String paramName;
    /**
     * 参数值
     */
    private String paramValue;
    /**
     * 产品ID
     */
    private Long productId;
}
