package com.github.admin.common.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 登录用户信息
 *
 * @author Mark sunlightcs@gmail.com
 */
@Data
public class UserDetail implements Serializable {

    @ApiModelProperty(hidden = true)
    private Long id;

    @ApiModelProperty(hidden = true)
    private String username;

    @ApiModelProperty(hidden = true)
    private String realName;

    @ApiModelProperty(hidden = true)
    private String headUrl;

    @ApiModelProperty(hidden = true)
    private String email;

    @ApiModelProperty(hidden = true)
    private String mobile;

    @ApiModelProperty(hidden = true)
    private Long deptId;

    @ApiModelProperty(hidden = true)
    private String password;

    @ApiModelProperty(hidden = true)
    private Integer status;

    @ApiModelProperty(hidden = true)
    private Integer superAdmin;

    @ApiModelProperty(hidden = true)
    private Integer sysType;

    /**
     * 部门数据权限
     */
    @ApiModelProperty(hidden = true)
    private List<Long> deptIdList;
    //菜单国际化语言
    @ApiModelProperty(hidden = true)
    private String language;

    @ApiModelProperty(value = "代理ID",hidden = true)
    private Long agentId;

    @ApiModelProperty(value = "商户ID",hidden = true)
    private Long merchantId;


    public static Boolean isVerifySuperAdmin(UserDetail userDetail){
        if (userDetail == null || userDetail.getSuperAdmin() == null || userDetail.getSysType() == null){
            return Boolean.FALSE;
        }

        if (!userDetail.getSuperAdmin().equals(1)){
            return Boolean.FALSE;
        }

        if (!userDetail.getSysType().equals(1)) {
            return Boolean.FALSE;
        }

        return Boolean.TRUE;
    }
}
