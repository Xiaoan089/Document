package com.github.admin.common.enums;

import com.github.framework.core.IErrorMessage;
import org.apache.commons.lang3.StringUtils;


public enum AdminErrorMsgEnum implements IErrorMessage {

    VERIFICATION_CODE_HAS_EXPIRED("3001", "验证码不存在或已过期", null),

    VERIFICATION_CODE_ERROR("3002", "验证码错误", null),

    SYSTEM_PROPERTIES_PROHIBIT_THIS_OPERATION("1003", "系统属性禁止修改", null),

    REQUEST_PARAMS_EMPTY("3004", "请求参数为空", null),

    USER_INFORMATION_EXCEPTION("3005", "登录用户信息异常", null),
    USER_DEPT_INFORMATION_EXCEPTION("3006", "登录用户部门信息异常", null),
    USER_NAME_ALREADY_EXISTS("3007", "用户名已存在", null),
    USER_NOT_EXISTS("3008", "用户不存在", null),
    PLEASE_DELETE_THE_SUBMENU_FIRST("3009", "请先删除子级", null),
    SUPERIORS_CANNOT_BE_FOR_THEMSELVES("3010", "上级不能为自身", null),
    DATA_ALREADY_EXISTS("3011", "数据已存在", null),

    USER_NAME_NOT_EXISTS("3012", "用户名不存在", null),

    THE_PROCESS_FORM_DOES_NOT_EXIST("3013", "流程表单不存在", null),

    THE_PROCESS_DOES_NOT_EXIST("3014", "流程不存在", null),

    CUSTOM_MENU_NOT_EXIST("3015", "自定义菜单不存在", null),
    SUPERIOR_CANNOT_BE_SUBORDINATE("3016", "上级不能为下级", null),
    DELETE_SUBUSERS_FIRST("3017", "请先删除子级用户", null),

    REQUEST_PARAMS_ERROR("3018", "当前请求参数异常", null),
    DO_NOT_HAVE_PERMISSION("3019", "没有权限操作该数据", null),
    WRONG_PASSWORD("3020", "密码错误", null),
    ACCOUNT_DEACTIVATED("3021", "账号停用", null),
    THE_PARENT_DOES_NOT_EXIST("3022", "父级不存在", null),
    THE_SYSTEM_TYPE_IS_INCONSISTENT("3023", "系统类型不一致", null),
    TEMPLATE_DOES_NOT_EXIST("3024", "模板数据不存在", null),
    SYS_SMS_DOES_NOT_EXIST("3025", "短信配置数据不存在", null),

    REQUEST_PARAMS_VALUE_ERROR("3026", "参数:%s为空", null),
    INVALID_TOKEN("3027", "令牌无效", null),
    SMS_SEND_ERROR("3028", "短信发送失败", null),
    TEMPLATE_RENDERING_FAILURE("3029", "模板渲染失败", null),
    PASSWORD_CONTAINS_SPACE("3030", "密码不能有空格", null),

    METHOD_NOT_ALLOWED("3031", "请求方式错误", null),

    HTTP_MESSAGE_NOT_READABLE("3032", "请求数据格式错误", null),

    PHONE_IS_NOT_MEET_SPECIFICATIONS("3033", "手机号不符合规格", null),

    EMAIL_IS_NOT_MEET_SPECIFICATIONS("3034", "邮箱不符合规格", null),
    AGENT_ACCOUNT_IS_EMPTY("3035", "代理账号为空", null),

    AGENT_NAME_IS_EMPTY("3036", "代理名称为空", null),

    AGENT_ID_IS_EMPTY("3037", "代理ID为空", null),

    PASSWORD_IS_EMPTY("3038", "密码为空", null),

    FUND_PASSWORD_IS_EMPTY("3039", "资金密码为空", null),

    STATUS_IS_EMPTY("3040", "状态为空", null),

    EMAIL_IS_EMPTY("3041", "邮箱为空", null),

    SYSTEM_USERID_IS_EMPTY("3042", "获取系统用户ID为空", null),

    MERCHANT_ACCOUNT_IS_EMPTY("3043", "商户账号为空", null),
    MERCHANT_NAME_IS_EMPTY("3044", "商户账名称为空", null),

    PHONE_IS_EMPTY("3045", "手机号为空", null),
    MERCHANT_ID_IS_EMPTY("3046", "商户ID为空", null),

    UPDATE_MERCHANT_ERROR("3047", "修改商户对应的系统用户失败", null),








    INVOKE_REMOTE_SERVICE_EXCEPTION("3996", "调用远程服务异常", null),

    SYSTEM_ERROR("3997", "系统异常,请稍后再试", null),

    OPERATION_FAIL("3998", "操作失败", null),

    SYSTEM_EXCEPTION("3999", "未知错误,请稍后再试", null),


    ;

    AdminErrorMsgEnum(String code, String message, Object[] params) {
        this.code = code;
        this.message = message;
        this.params = params;
    }

    private String code;

    private String message;

    private Object[] params;


    @Override
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public Object[] getParams() {
        return params;
    }

    public void setParams(Object[] params) {
        this.params = params;
    }

    public static AdminErrorMsgEnum of(String code) {
        for (AdminErrorMsgEnum errorMsgEnums : AdminErrorMsgEnum.values()) {
            if (StringUtils.equals(code, errorMsgEnums.getCode())) {
                return errorMsgEnums;
            }
        }
        return null;
    }
}
