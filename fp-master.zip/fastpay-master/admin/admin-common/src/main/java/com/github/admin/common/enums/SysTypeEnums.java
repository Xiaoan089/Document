package com.github.admin.common.enums;

import com.github.framework.core.IEnum;

public enum SysTypeEnums implements IEnum<Integer> {

    admin(1,"后管"),

    merchant(2,"商户"),

    agent(3,"代理"),
    ;
    private Integer value;
    private String named;

    SysTypeEnums(Integer value, String named){
        this.value = value;
        this.named = named;
    }

    public static SysTypeEnums of(Integer status) {
        for(SysTypeEnums enums: SysTypeEnums.values()){
            if(enums.value == status){
                return enums;
            }
        }
        return null;
    }

    @Override
    public Integer value() {
        return this.value;
    }

    @Override
    public String named() {
        return this.named;
    }
}
