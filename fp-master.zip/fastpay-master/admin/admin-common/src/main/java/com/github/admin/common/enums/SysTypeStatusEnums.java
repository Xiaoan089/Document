package com.github.admin.common.enums;

import com.github.framework.core.IEnum;

public enum SysTypeStatusEnums implements IEnum<Integer> {

    START(1,"启用"),

    STOP(0,"停用"),

    ;
    private Integer value;
    private String named;

    SysTypeStatusEnums(Integer value, String named){
        this.value = value;
        this.named = named;
    }

    public static SysTypeStatusEnums of(Integer status) {
        for(SysTypeStatusEnums enums: SysTypeStatusEnums.values()){
            if(enums.value == status){
                return enums;
            }
        }
        return null;
    }

    @Override
    public Integer value() {
        return this.value;
    }

    @Override
    public String named() {
        return this.named;
    }
}
