/**
 * Copyright (c) 2018 人人开源 All rights reserved.
 *
 * https://www.renren.io
 *
 * 版权所有，侵权必究！
 */

package com.github.admin.common.exception;

/**
 * 错误编码，由5位数字组成，前2位为模块编码，后3位为业务编码
 * <p>
 * 如：10001（10代表系统模块，001代表业务代码）
 * </p>
 *
 * @author Mark sunlightcs@gmail.com
 * @since 1.0.0
 */
public interface ErrorCode {
    int INTERNAL_SERVER_ERROR = 500;
    int UNAUTHORIZED = 401;

    int NOT_NULL = 10001;
    int PARAMS_GET_ERROR = 10003;
    int IDENTIFIER_NOT_NULL = 10006;
    int PASSWORD_ERROR = 10009;
    int SUPERIOR_MENU_ERROR = 10012;
    int DATA_SCOPE_PARAMS_ERROR = 10013;
    int TOKEN_INVALID = 10021;
    int ACCOUNT_LOCK = 10022;
    int SEND_SMS_ERROR = 10025;
    int MAIL_TEMPLATE_NOT_EXISTS = 10026;
    int JOB_ERROR = 10028;
    int JSON_FORMAT_ERROR = 10030;
    int SMS_CONFIG = 10031;
}
