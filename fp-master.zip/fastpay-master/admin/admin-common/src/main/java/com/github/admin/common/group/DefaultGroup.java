/**
 * Copyright (c) 2018 人人开源 All rights reserved.
 *
 * https://www.renren.io
 *
 * 版权所有，侵权必究！
 */

package com.github.admin.common.group;

/**
 * 默认 Group
 *
 * @author Mark sunlightcs@gmail.com
 * @since 1.0.0
 */
public interface DefaultGroup {

}
