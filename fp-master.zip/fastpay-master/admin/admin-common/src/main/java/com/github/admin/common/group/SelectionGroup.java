package com.github.admin.common.group;

public interface SelectionGroup {
}
