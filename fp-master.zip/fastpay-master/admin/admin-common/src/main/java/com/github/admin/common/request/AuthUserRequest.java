package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@ApiModel(value = "用户登录请求" )
public class AuthUserRequest extends BaseAdminRequest {

    @NotBlank
    @ApiModelProperty(value = "用户名" )
    private String username;

    @NotBlank
    @ApiModelProperty(value = "密码" )
    private String password;

    @ApiModelProperty(value = "验证码" )
    private String code;

    @ApiModelProperty(value = "uuid" )
    private String uuid = "";
}
