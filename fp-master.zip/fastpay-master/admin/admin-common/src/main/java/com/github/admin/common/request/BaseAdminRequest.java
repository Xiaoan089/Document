package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.entity.UserDetail;
import com.github.admin.common.user.SecurityUser;
import com.github.admin.common.utils.DateUtils;
import com.github.framework.core.common.base.BaseRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public abstract class BaseAdminRequest extends BaseRequest {


    @ApiModelProperty(hidden = true)
    private Boolean isSuperAdmin = Boolean.FALSE;

    @ApiModelProperty(hidden = true)
    private UserDetail userDetail = SecurityUser.getUser();

    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    protected Date createDate;

    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    protected Date updateDate;

    public static Boolean isSuperAdmin(BaseAdminRequest baseAdminRequest, UserDetail userDetail) {
        if (userDetail == null || !userDetail.getSuperAdmin().equals(1)) {
            return Boolean.FALSE;
        }
        if (baseAdminRequest != null) {
            baseAdminRequest.setIsSuperAdmin(Boolean.TRUE);
        }
        return Boolean.TRUE;
    }
}
