/**
 * Copyright (c) 2020 人人开源 All rights reserved.
 * <p>
 * https://www.renren.io
 * <p>
 * 版权所有，侵权必究！
 */

package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "代码生成基础类配置" )
public class BaseClassRequest extends BaseAdminRequest {

	@ApiModelProperty(value = "基类包名" )
	private String packageName;

	@ApiModelProperty(value = "基类编码" )
	private String code;

	@ApiModelProperty(value = "公共字段，多个用英文逗号分隔" )
	private String fields;

	@ApiModelProperty(value = "基类编码" )
	private String remark;

}
