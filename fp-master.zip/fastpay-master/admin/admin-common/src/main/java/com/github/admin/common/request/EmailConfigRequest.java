package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@ApiModel(value = "邮箱配置" )
public class EmailConfigRequest extends BaseAdminRequest{

    @Schema(description = "SMTP")
    @NotBlank(message = "{email.smtp.require}")
    private String smtp;

    @Schema(description = "端口号")
    @NotNull(message = "{email.port.require}")
    private Integer port;

    @Schema(description = "邮箱账号")
    @NotBlank(message = "{email.username.require}")
    private String username;

    @Schema(description = "邮箱密码")
    @NotBlank(message = "{email.password.require}")
    private String password;
}
