package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
@ApiModel(value = "Excel数据" )
public class ExcelDataRequest extends BaseAdminRequest{

    @Schema(description = "id")
    private Long id;
    @Schema(description = "学生姓名")
    private String realName;
    @Schema(description = "身份证")
    private String userIdentity;
    @Schema(description = "家庭地址")
    private String address;
    @Schema(description = "入学日期")
    @JsonFormat(timezone = "GMT+8",pattern = "yyyy-MM-dd")
    private Date joinDate;
    @Schema(description = "班级名称")
    private String className;
    @Schema(description = "创建者")
    private Long creator;
    @Schema(description = "创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

    @Schema(description = "产品参数列表")
    private List<TbProductParamsRequest> subList;
}
