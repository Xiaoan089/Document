package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;



@Data
@ApiModel(value = "代码生成数据源配置" )
public class GenDataSourceRequest extends BaseAdminRequest{

    @ApiModelProperty(value = "数据库类型 MySQL、Oracle、SQLServer、PostgreSQL" )
	private String dbType;

    @ApiModelProperty(value = "连接名" )
	private String connName;

    @ApiModelProperty(value = "URL" )
	private String connUrl;

    @ApiModelProperty(value = "用户名" )
	private String username;

    @ApiModelProperty(value = "密码" )
	private String password;

}
