package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class GenFieldTypeRequest extends BaseAdminRequest{

	@ApiModelProperty(value = "字段类型")
	private String columnType;

	@ApiModelProperty(value = "属性类型")
	private String attrType;

	@ApiModelProperty(value = "属性包名")
	private String packageName;
}
