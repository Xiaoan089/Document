
package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel(value = "代码生成参数配置" )
public class GenParamRequest extends BaseAdminRequest {

    @ApiModelProperty(value = "包名")
    private String packageName;

    @ApiModelProperty(value = "版本")
    private String version;

    @ApiModelProperty(value = "创建人")
    private String author;

    @ApiModelProperty(value = "邮箱")
    private String email;

    @ApiModelProperty(value = "后端代码路径" )
    private String backendPath;

    @ApiModelProperty(value = "前端代码路径" )
    private String frontendPath;
}
