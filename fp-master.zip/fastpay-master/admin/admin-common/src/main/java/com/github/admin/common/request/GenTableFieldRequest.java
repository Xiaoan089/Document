package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel(value = "代码生成表配置" )
public class GenTableFieldRequest extends BaseAdminRequest {

    @ApiModelProperty(value = "表ID")
    private Long tableId;

    @ApiModelProperty(value = "表名")
    private String tableName;

    @ApiModelProperty(value = "列名")
    private String columnName;

    @ApiModelProperty(value = "类型")
    private String columnType;

    @ApiModelProperty(value = "列说明")
    private String columnComment;

    @ApiModelProperty(value = "列说明")
    private String comment;

    @ApiModelProperty(value = "属性名")
    private String attrName;

    @ApiModelProperty(value = "属性类型")
    private String attrType;

    @ApiModelProperty(value = "属性包名")
    private String packageName;

    @ApiModelProperty(value = "是否主键 0：否  1：是")
    private boolean isPk;

    @ApiModelProperty(value = "是否必填 0：否  1：是")
    private boolean isRequired;

    @ApiModelProperty(value = "是否表单字段 0：否  1：是")
    private boolean isForm;

    @ApiModelProperty(value = "是否列表字段 0：否  1：是")
    private boolean isList;

    @ApiModelProperty(value = "是否查询字段 0：否  1：是")
    private boolean isQuery;

    @ApiModelProperty(value = "查询方式")
    private String queryType;

    @ApiModelProperty(value = "表单类型")
    private String formType;

    @ApiModelProperty(value = "字典名称")
    private String dictName;

    @ApiModelProperty(value = "效验方式")
    private String validatorType;

    @ApiModelProperty(value = "排序")
    private Integer sort;
}
