package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;


@Data
@ApiModel(value = "代码生成模板配置" )
public class GenTemplateRequest extends BaseAdminRequest {

	@ApiModelProperty(value = "名称")
	private String name;

	@ApiModelProperty(value = "内容")
	private String content;

	@ApiModelProperty(value = "文件名")
	private String fileName;

	@ApiModelProperty(value = "生成路径")
	private String path;

	@ApiModelProperty(value = "状态")
	private Integer status;

	@ApiModelProperty(value = "ids")
	private List<Long> ids;

}
