package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;


@Data
@ApiModel("登录表单")
public class LoginRequest implements Serializable {

    @ApiModelProperty("用户名")
    @NotBlank(message = "{sysuser.username.require}")
    private String username;

    @ApiModelProperty("密码")
    @NotBlank(message = "{sysuser.password.require}")
    private String password;

    @ApiModelProperty("验证码")
    @NotBlank(message = "{sysuser.captcha.require}")
    private String captcha;

    @ApiModelProperty("唯一标识")
    @NotBlank(message = "{sysuser.uuid.require}")
    private String uuid;

    @ApiModelProperty("系统类型")
    private Integer sysType;
}
