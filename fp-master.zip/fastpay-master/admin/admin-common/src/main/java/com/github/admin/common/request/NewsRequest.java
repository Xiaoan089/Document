package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import java.util.Date;


@Data
@ApiModel("新闻管理")
public class NewsRequest extends BaseAdminRequest {

    @ApiModelProperty("父级id")
    @Null(message = "{id.null}", groups = AddGroup.class)
    @NotNull(message = "{id.require}", groups = UpdateGroup.class)
    private Long id;

    @ApiModelProperty("标题")
    @NotBlank(message = "{news.title.require}", groups = DefaultGroup.class)
    private String title;

    @ApiModelProperty("创建者部门id")
    private Long deptId;

    @ApiModelProperty("内容")
    @NotBlank(message = "{news.content.require}", groups = DefaultGroup.class)
    private String content;

    @ApiModelProperty("发布时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date pubDate;

    @ApiModelProperty("创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

}
