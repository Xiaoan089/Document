package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;
import java.util.List;



@Data
@ApiModel("产品管理")
public class ProductRequest extends BaseAdminRequest {

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("产品名称")
    private String name;

    @ApiModelProperty("产品介绍")
    private String content;

    @ApiModelProperty("创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

    @ApiModelProperty("产品参数列表")
    private List<TbProductParamsRequest> subList;

}
