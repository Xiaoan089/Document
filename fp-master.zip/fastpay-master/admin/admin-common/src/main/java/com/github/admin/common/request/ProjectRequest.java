package com.github.admin.common.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@ApiModel("项目名修改")
public class ProjectRequest extends BaseAdminRequest {

    @ApiModelProperty("原项目路径")
    private String projectPath;

    @ApiModelProperty("原项目名称")
    private String projectName;

    @ApiModelProperty("新项目名称")
    private String newProjectName;

    @ApiModelProperty("新项目包名")
    private String newProjectPackage;

    @ApiModelProperty("新项目标识")
    private String newProjectCode;

}
