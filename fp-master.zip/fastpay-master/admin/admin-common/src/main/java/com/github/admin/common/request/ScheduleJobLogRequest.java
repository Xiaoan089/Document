package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel("定时任务日志")
public class ScheduleJobLogRequest extends BaseAdminRequest{

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("任务id")
    private Long jobId;

    @ApiModelProperty("spring bean名称")
    private String beanName;

    @ApiModelProperty("参数")
    private String params;

    @ApiModelProperty("任务状态    0：失败    1：成功")
    private Integer status;

    @ApiModelProperty("失败信息")
    private String error;

    @ApiModelProperty("耗时(单位：毫秒)")
    private Integer times;

    @ApiModelProperty("创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;
}
