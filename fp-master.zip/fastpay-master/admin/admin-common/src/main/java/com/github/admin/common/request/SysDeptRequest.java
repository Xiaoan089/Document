package com.github.admin.common.request;

import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import java.util.List;


@Data
@ApiModel("部门管理")
public class SysDeptRequest extends BaseAdminRequest {


    @ApiModelProperty("id")
    @Null(message = "{id.null}", groups = AddGroup.class)
    @NotNull(message = "{id.require}", groups = UpdateGroup.class)
    private Long id;

    @ApiModelProperty("上级ID")
    private Long pid;

    @ApiModelProperty("所有上级ID，用逗号分开")
    private String pids;

    @ApiModelProperty("部门名称")
    @NotBlank(message = "{sysdept.name.require}", groups = DefaultGroup.class)
    private String name;

    @ApiModelProperty("负责人ID")
    private Long leaderId;

    @ApiModelProperty("负责人名称")
    private String leaderName;

    @ApiModelProperty("排序")
    @Min(value = 0, message = "{sort.number}", groups = DefaultGroup.class)
    private Integer sort;

    @ApiModelProperty("系统类型")
    private Integer sysType;

    @ApiModelProperty("上级部门名称")
    private String parentName;

    @ApiModelProperty("ids")
    private List<Long> ids;
}
