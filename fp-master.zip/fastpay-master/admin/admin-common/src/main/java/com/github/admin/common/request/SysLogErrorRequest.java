package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;


@Data
@ApiModel("异常日志")
public class SysLogErrorRequest extends BaseAdminRequest implements Serializable {

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("请求URI")
    private String requestUri;

    @ApiModelProperty("请求方式")
    private String requestMethod;

    @ApiModelProperty("请求参数")
    private String requestParams;

    @ApiModelProperty("用户代理")
    private String userAgent;

    @ApiModelProperty("操作IP")
    private String ip;

    @ApiModelProperty("异常信息")
    private String errorInfo;

    @ApiModelProperty("创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

}
