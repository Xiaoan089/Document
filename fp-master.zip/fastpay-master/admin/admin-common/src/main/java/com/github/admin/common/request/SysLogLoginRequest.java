package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;


@Data
@ApiModel("登录日志")
public class SysLogLoginRequest extends BaseAdminRequest {

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("用户操作  0：用户登录   1：用户退出")
    private Integer operation;

    @ApiModelProperty("状态  0：失败    1：成功    2：账号已锁定")
    private Integer status;

    @ApiModelProperty("用户代理")
    private String userAgent;

    @ApiModelProperty("操作IP")
    private String ip;

    @ApiModelProperty("用户名")
    private String creatorName;

    @ApiModelProperty("创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

    private Long userId;

    private Integer sysType;

}
