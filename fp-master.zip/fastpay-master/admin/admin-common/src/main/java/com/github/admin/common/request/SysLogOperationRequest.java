
package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;


@Data
public class SysLogOperationRequest extends BaseAdminRequest{

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("用户操作")
    private String operation;

    @ApiModelProperty("请求URI")
    private String requestUri;

    @ApiModelProperty("请求方式")
    private String requestMethod;

    @ApiModelProperty("请求参数")
    private String requestParams;

    @ApiModelProperty("请求时长(毫秒)")
    private Integer requestTime;

    @ApiModelProperty("用户代理")
    private String userAgent;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("系统类型1后管；2商户；3代理")
    private Integer sysType;

    @ApiModelProperty("操作IP")
    private String ip;

    @ApiModelProperty("状态  0：失败   1：成功")
    private Integer status;

    @ApiModelProperty("用户名")
    private String creatorName;

    @ApiModelProperty("创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

}
