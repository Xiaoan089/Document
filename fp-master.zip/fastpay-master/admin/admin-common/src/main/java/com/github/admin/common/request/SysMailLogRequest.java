package com.github.admin.common.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.github.admin.common.utils.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel("邮件发送记录")
public class SysMailLogRequest extends BaseAdminRequest{

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("邮件模板ID")
    private Long templateId;

    @ApiModelProperty("发送者")
    private String mailFrom;

    @ApiModelProperty("收件人")
    private String mailTo;

    @ApiModelProperty("抄送者")
    private String mailCc;

    @ApiModelProperty("邮件主题")
    private String subject;

    @ApiModelProperty("邮件正文")
    private String content;

    @ApiModelProperty("发送状态  0：失败  1：成功")
    private Integer status;

    @ApiModelProperty("参数")
    private String params;

    @ApiModelProperty("创建时间")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

}
