package com.github.admin.common.request;

import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.GeneratorGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.framework.core.group.SwaggerAddGroup;
import com.github.framework.core.group.SwaggerUpdateGroup;
import com.github.framework.swagger.annotition.ApiGroup;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

@Data
public class SysMenuRequest extends BaseAdminRequest{
    @ApiGroup(value = {SwaggerAddGroup.class, SwaggerUpdateGroup.class})
    @ApiModelProperty(value = "id")
    @Null(message = "{id.null}", groups = AddGroup.class)
    @NotNull(message = "{id.require}", groups = UpdateGroup.class)
    private Long id;

    @ApiGroup
    @ApiModelProperty(value = "上级ID")
    @NotNull(message = "{sysmenu.pid.require}", groups = {DefaultGroup.class, GeneratorGroup.class})
    private Long pid;

    @ApiGroup
    @ApiModelProperty(value = "菜单名称")
    @NotBlank(message = "{sysmenu.name.require}", groups = {DefaultGroup.class,GeneratorGroup.class})
    private String name;

    @Schema(description = "菜单URL")
    private String url;

    @Schema(description = "类型  0：菜单   1：按钮")
    @Range(min = 0, max = 1, message = "{sysmenu.type.range}", groups = DefaultGroup.class)
    private Integer menuType;

    @Schema(description = "打开方式   0：内部   1：外部")
    @Range(min = 0, max = 1, message = "{sysmenu.openstyle.range}", groups = DefaultGroup.class)
    private Integer openStyle;

    @Schema(description = "菜单图标")
    private String icon;

    @Schema(description = "授权(多个用逗号分隔，如：sys:user:list,sys:user:save)")
    private String permissions;

    @Schema(description = "排序")
    @Min(value = 0, message = "{sort.number}", groups = DefaultGroup.class)
    private Integer sort;

    @Schema(description = "系统类型")
    @NotBlank(message = "{sysType.require}",groups = {AddGroup.class,UpdateGroup.class})
    private Integer sysType;


    @Schema(description = "上级菜单名称")
    private String parentName;

    private String language;

    private Long userId;

    @NotBlank(message = "{sysmenu.moduleName.require}", groups = GeneratorGroup.class)
    private String moduleName;

    @NotBlank(message = "{sysmenu.className.require}", groups = GeneratorGroup.class)
    private String className;
}
