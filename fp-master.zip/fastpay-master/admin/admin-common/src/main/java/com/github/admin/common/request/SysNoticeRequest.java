package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.utils.DateUtils;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.SelectionGroup;
import com.github.admin.common.group.UpdateGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "通知管理")
public class SysNoticeRequest extends BaseAdminRequest {
    @Schema(description = "id")
    @Null(message = "{id.null}",groups = {AddGroup.class})
    @NotNull(message = "{id.require}", groups = {UpdateGroup.class, SelectionGroup.class})
    private Long id;

    @Schema(description = "通知类型")
    @NotNull(message="{sys.notice.type.require}",groups = {AddGroup.class})
    private Integer noticeType;

    @Schema(description = "标题")
    @NotNull(message="{sys.notice.title.require}",groups = {AddGroup.class})
    private String title;

    @Schema(description = "内容")
    private String content;

    @Schema(description = "接收者类型  0：全部  1：部门")
    @NotNull(message="{sys.notice.receiver.type.require}",groups = {AddGroup.class})
    private Integer receiverType;

    @Schema(description = "接收者ID，用逗号分开")
    private String receiverTypeIds;
    @Schema(description = "接收者ID列表")
    private List<Long> receiverTypeList;
    @Schema(description = "发送状态  0：草稿  1：已发布")
    private Integer status;
    @Schema(description = "发送者")
    private String senderName;
    @Schema(description = "发送时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date senderDate;
    @Schema(description = "创建者")
    private Long creator;
    @Schema(description = "创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;
    @Schema(description = "接收者")
    private String receiverName;
    @Schema(description = "阅读时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date readDate;
    @Schema(description = "阅读状态  0：未读  1：已读")
    private Integer readStatus;

    private Long noticeId;
    private Long receiverId;
}
