package com.github.admin.common.request;

import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import java.util.List;

@Data
public class SysPostRequest extends BaseAdminRequest{

    @Schema(description = "id")
    @Null(message = "{id.null}",groups = AddGroup.class)
    @NotNull(message = "{id.require}",groups = UpdateGroup.class)
    private Long id;
    @Schema(description = "岗位编码")
    @NotNull(message = "{id.require}",groups = {AddGroup.class,UpdateGroup.class})
    private String postCode;
    @Schema(description = "岗位名称")
    @NotNull(message = "{id.require}",groups = {AddGroup.class,UpdateGroup.class})
    private String postName;
    @Schema(description = "排序")
    @NotNull(message = "{id.require}",groups = {AddGroup.class,UpdateGroup.class})
    private Integer sort;
    /**
     * 系统类型
     */
    private Integer sysType;
    @Schema(description = "状态")
    @NotNull(message = "{id.require}",groups = {AddGroup.class,UpdateGroup.class})
    private Integer status;
    @Schema(description = "租户编码")
    private Long tenantCode;
    private List<Long> ids;
}
