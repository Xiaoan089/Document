package com.github.admin.common.request;

import com.github.admin.common.group.DefaultGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class SysRegionRequest extends BaseAdminRequest{
    @Schema(description = "区域标识")
    @NotNull(message = "{id.require}", groups = DefaultGroup.class)
    private Long id;

    @Schema(description = "上级区域ID")
    @NotNull(message = "{region.pid.require}", groups = DefaultGroup.class)
    private Long pid;

    @Schema(description = "区域名称")
    @NotBlank(message = "{region.name.require}", groups = DefaultGroup.class)
    private String name;

    @Schema(description = "排序")
    @Min(value = 0, message = "{sort.number}", groups = DefaultGroup.class)
    private Long sort;

    @Schema(description = "上级区域名称")
    private String parentName;

    @Schema(description = "是否有子节点")
    private Boolean hasChildren;

    @Schema(description = "层级")
    private Integer treeLevel;

    /**
     * 是否叶子节点  0：否   1：是
     */
    private Integer leaf;
}
