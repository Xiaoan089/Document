package com.github.admin.common.request;

import lombok.Data;

@Data
public class SysRoleDataScopeRequest extends BaseAdminRequest {
    /**
     * 角色ID
     */
    private Long roleId;
    /**
     * 部门ID
     */
    private Long deptId;

}
