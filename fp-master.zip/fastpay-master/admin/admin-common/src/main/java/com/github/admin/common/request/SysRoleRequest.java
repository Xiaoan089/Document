package com.github.admin.common.request;

import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import java.util.List;

@Data
public class SysRoleRequest extends BaseAdminRequest{
    @Schema(description = "id")
    @Null(message = "{id.null}", groups = AddGroup.class)
    @NotNull(message = "{id.require}", groups = UpdateGroup.class)
    private Long id;

    @Schema(description = "角色名称")
    @NotBlank(message = "{sysrole.name.require}", groups = DefaultGroup.class)
    private String name;

    private Integer sysType;

    @Schema(description = "菜单ID列表")
    private List<Long> menuIdList;

    @Schema(description = "部门ID列表")
    private List<Long> deptIdList;

    private List<Long> ids;
}
