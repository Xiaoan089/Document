package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.github.admin.common.config.SmsConfig;
import com.github.admin.common.utils.DateUtils;
import com.github.framework.core.entity.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Data
public class SysSmsRequest extends BaseAdminRequest{

    @Schema(description = "id")
    private Long id;

    @Schema(description = "短信编码")
    private String smsCode;

    @Schema(description = "平台类型")
    private Integer platform;

    @Schema(description = "备注")
    private String remark;

    @Schema(description = "短信配置")
    private SmsConfig config;

    private String smsConfig;

    @Schema(description = "创建时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date createDate;

    private String mobile;

    private String params;


}
