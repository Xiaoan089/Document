package com.github.admin.common.request;


import lombok.Data;

import java.util.List;

@Data
public class SysUserPostRequest extends BaseAdminRequest {
    /**
     * 岗位ID
     */
    private Long postId;
    /**
     * 用户ID
     */
    private Long userId;

    private List<Long> postIds;

}
