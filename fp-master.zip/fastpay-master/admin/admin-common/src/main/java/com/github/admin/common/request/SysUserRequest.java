package com.github.admin.common.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.LoginGroup;
import com.github.admin.common.group.UpdateGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import java.nio.channels.Selector;
import java.util.List;

@Data
public class SysUserRequest extends BaseAdminRequest {
    @Schema(description = "id")
    @Null(message = "{id.null}", groups = AddGroup.class)
    @NotNull(message = "{id.require}", groups = {UpdateGroup.class, Selector.class})
    private Long id;

    @Schema(description = "用户名", required = true)
    @NotBlank(message = "{sysuser.username.require}", groups = {DefaultGroup.class, LoginGroup.class})
    private String username;

    @Schema(description = "密码")
    @NotBlank(message = "{sysuser.password.require}", groups = {AddGroup.class,UpdateGroup.class})
    private String password;

    @Schema(description = "新密码")
    @NotBlank(message = "{sysuser.password.require}", groups = UpdateGroup.class)
    private String newPassword;

    @Schema(description = "姓名", required = true)
    @NotBlank(message = "{sysuser.realname.require}", groups = DefaultGroup.class)
    private String realName;

    @Schema(description = "头像")
    private String headUrl;

    @Schema(description = "性别   0：男   1：女    2：保密", required = true)
    @Range(min = 0, max = 2, message = "{sysuser.gender.range}", groups = DefaultGroup.class)
    private Integer gender;

    @Schema(description = "邮箱")
    @Email(message = "{sysuser.email.error}", groups = DefaultGroup.class)
    private String email;

    @Schema(description = "手机号")
    private String mobile;

    @Schema(description = "部门ID", required = true)
    @NotNull(message = "{sysuser.deptId.require}", groups = DefaultGroup.class)
    private Long deptId;

    @Schema(description = "系统类型", required = true)
    @NotNull(message = "{sysType.require}", groups = {DefaultGroup.class, LoginGroup.class, AddGroup.class, Selector.class})
    private Integer sysType;

    @Schema(description = "状态  0：停用    1：正常", required = true)
    @Range(min = 0, max = 1, message = "sysuser.status.range", groups = DefaultGroup.class)
    private Integer status;

    @Schema(description = "超级管理员   0：否   1：是")
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Integer superAdmin;

    @Schema(description = "角色ID列表")
    private List<Long> roleIdList;

    @Schema(description = "岗位ID列表")
    private List<Long> postIdList;

    @Schema(description = "部门名称")
    private String deptName;

    private Boolean isSupperAdmin = Boolean.FALSE;

    private List<Long> ids;

}
