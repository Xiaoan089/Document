package com.github.admin.common.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


@Data
@Schema(description = "产品参数管理")
public class TbProductParamsRequest extends BaseAdminRequest {

    private Long productId;

    @Schema(description = "参数名")
    private String paramName;

    @Schema(description = "参数值")
    private String paramValue;
}
