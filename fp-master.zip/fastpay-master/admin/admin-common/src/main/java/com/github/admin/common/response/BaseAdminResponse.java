package com.github.admin.common.response;

import com.github.admin.common.entity.UserDetail;
import com.github.framework.core.common.base.BaseResponse;

import lombok.Data;

@Data
public class BaseAdminResponse extends BaseResponse {
    private Long id;
    private Boolean isSuperAdmin;
    private String language;
    private UserDetail userDetail;
    private Integer pageNo;
    private Integer pageSize;
}
