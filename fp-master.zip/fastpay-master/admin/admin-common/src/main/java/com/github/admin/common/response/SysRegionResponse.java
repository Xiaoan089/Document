package com.github.admin.common.response;

import com.fasterxml.jackson.annotation.JsonFormat;

import com.github.admin.common.utils.DateUtils;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Data
public class SysRegionResponse extends BaseAdminResponse{
    @Schema(description = "区域标识")
    private Long id;

    @Schema(description = "上级区域ID")
    private Long pid;

    @Schema(description = "区域名称")
    private String name;

    @Schema(description = "排序")
    private Long sort;

    @Schema(description = "上级区域名称")
    private String parentName;

    @Schema(description = "是否有子节点")
    private Boolean hasChildren;

    @Schema(description = "层级")
    private Integer treeLevel;

    @Schema(description = "更新时间")
    @JsonFormat(timezone = "GMT+8",pattern = DateUtils.DATE_TIME_PATTERN)
    private Date updateDate;
}
