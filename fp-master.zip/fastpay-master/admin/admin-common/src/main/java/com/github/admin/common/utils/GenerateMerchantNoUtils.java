package com.github.admin.common.utils;

import cn.hutool.core.util.RandomUtil;

import java.security.SecureRandom;

public class GenerateMerchantNoUtils {


    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    private static final int STRING_LENGTH = 30;

    private static final String MERCHANT_NO_PREFIX = "86";

    private static final String ACCOUNT_NO_PREFIX = "98";

    private GenerateMerchantNoUtils() {
    }

    public static String generateMerchantNo() {
        String merchantNo = RandomUtil.randomNumbers(14);
        return MERCHANT_NO_PREFIX + merchantNo;
    }

    public static String generateMerchantSecretkey() {
        String secretKey = RandomUtil.randomString(32);
        return secretKey;
    }

    public static String generateAccountNo() {
        String accountNo = RandomUtil.randomNumbers(14);
        return ACCOUNT_NO_PREFIX + accountNo;
    }

    public static String generateGoogleKey() {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(25);
        for (int i = 0; i < 25; i++) {
            int index = random.nextInt(CHARACTERS.length());
            sb.append(CHARACTERS.charAt(index));
        }
        return sb.toString();
    }


    public static String generateThirdChannelAccountNo() {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(6);
        for (int i = 0; i < 6; i++) {
            int index = random.nextInt(CHARACTERS.length());
            sb.append(CHARACTERS.charAt(index));
        }
        return "third_" + sb.toString();
    }


    public static void main(String[] args) {
        for(int i = 0;i < 100;i++){
            String accountNo = generateAccountNo();
            String merchantNo = generateMerchantNo();
            String secretkey = generateMerchantSecretkey();
            System.out.println(accountNo);
            System.out.println(merchantNo);
            System.out.println(secretkey);
            System.out.println("------------");
        }

    }

}
