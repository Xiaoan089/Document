package com.github.admin.common.utils;

import com.github.framework.core.entity.BaseEntity;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;


@Data
public class TreeNode<T> extends BaseEntity {
    /**
     * 上级ID
     */
    private Long pid;
    /**
     * 子节点列表
     */
    private List<T> children = new ArrayList<>();
}
