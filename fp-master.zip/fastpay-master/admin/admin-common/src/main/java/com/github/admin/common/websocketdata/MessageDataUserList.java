package com.github.admin.common.websocketdata;

import lombok.Data;

import java.util.List;

@Data
public class MessageDataUserList {
    private MessageData data;
    private List<Long> userIdList;
}
