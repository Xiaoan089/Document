package com.github.admin.server.advice;


import com.github.admin.common.utils.HttpContextUtils;
import com.github.framework.core.Result;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import javax.annotation.Resource;
import java.util.Locale;


/**
 * 统一返回response
 *
 **/
@ControllerAdvice
@Slf4j
public class GlobalResponseBodyAdvice implements ResponseBodyAdvice {

    @Resource
    private MessageSource messageSource;


    @Override
    public boolean supports(MethodParameter returnType, Class converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
                                  Class selectedConverterType, ServerHttpRequest serverHttpRequest, ServerHttpResponse response) {
        String language = HttpContextUtils.getLanguage();
        if (StringUtils.isEmpty(language)) {
            language = LocaleContextHolder.getLocale().toLanguageTag();
        }
        try {
            if (body != null && body instanceof Result) {
                Result result = (Result)body;
                String code = result.getCode();
                String message = result.getMessage();
                Object[] param = result.getParams();
                String resolveMessage = messageSource.getMessage(code,param,message,Locale.forLanguageTag(language));
                result.setMessage(resolveMessage);
                result.setParams(null);
            }
            return body;
        } catch (Exception e) {
            log.error("globalResponseBodyAdvice exception:{}", e);
            //防止程序异常
            return body;
        }

    }

}
