package com.github.admin.server.config;
import com.github.admin.common.entity.GenDataSource;
import com.github.admin.common.entity.DbTypeEntity;
import com.github.admin.server.service.AbstractQueryService;
import com.github.admin.server.utils.DbUtils;
import lombok.Data;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * 数据源信息
 */
@Data
public class DataSourceInfo {
    /**
     * 数据源ID
     */
    private Long id;
    /**
     * 数据库类型
     */
    private DbTypeEntity dbType;
    /**
     * 数据库URL
     */
    private String connUrl;
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;

    private AbstractQueryService dbQuery;

    private Connection connection;

    public DataSourceInfo(GenDataSource entity) {
        this.id = entity.getId();
        this.dbType = DbTypeEntity.valueOf(entity.getDbType());
        this.connUrl = entity.getConnUrl();
        this.username = entity.getUsername();
        this.password = entity.getPassword();

        if(dbType == DbTypeEntity.MySQL) {
            this.dbQuery = new MySqlQuery();
        }

        try {
            this.connection = DbUtils.getConnection(this);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public DataSourceInfo(Connection connection) throws SQLException {
        this.id = 0L;
        this.dbType = DbTypeEntity.valueOf(connection.getMetaData().getDatabaseProductName());

        if(dbType == DbTypeEntity.MySQL) {
            this.dbQuery = new MySqlQuery();
        }

        this.connection = connection;
    }
}
