package com.github.admin.server.config;

import com.github.admin.server.interceptor.MyInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class MvcConfig {

    @Bean
    public MyInterceptor idInjectInterceptor() {
        return new MyInterceptor();
    }
}
