package com.github.admin.server.controller;

import com.github.admin.common.entity.TbExcelData;
import com.github.admin.common.request.ExcelDataRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.ExcelDataService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * Excel导入演示
 */

@RestController
@RequestMapping("/demo")
public class ExcelDataController {

    @Resource
    private ExcelDataService excelDataService;

    @PostMapping("/page")
    public Result<DataPage<TbExcelData>> page(@RequestBody ExcelDataRequest request) {
        return excelDataService.excelDatapage(request);
    }

    @GetMapping("/findById/{id}")
    public Result<TbExcelData> findById(@PathVariable("id") Long id) {
        return excelDataService.findById(id);
    }

    @PostMapping("/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody ExcelDataRequest request) {
        return excelDataService.save(request);
    }

    @PostMapping("/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody ExcelDataRequest request) {
        return excelDataService.update(request);
    }

    @PostMapping("/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return excelDataService.delete(ids);
    }

    @PostMapping("/list")
    public Result<List<TbExcelData>> list(@RequestBody ExcelDataRequest request) throws Exception {
        return excelDataService.list(request);
    }

    @GetMapping("/currentModelClass")
    public Result<Class<TbExcelData>> currentModelClass() {
        return excelDataService.currentModelClass();
    }

    @PostMapping("/insertBatch")
    public Result insertBatch(@RequestBody List<TbExcelData> list) {
        return excelDataService.insertBatch(list);
    }
}
