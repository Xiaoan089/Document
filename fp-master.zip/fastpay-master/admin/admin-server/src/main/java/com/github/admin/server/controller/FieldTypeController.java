package com.github.admin.server.controller;

import com.github.admin.common.entity.GenFieldType;
import com.github.admin.common.request.GenFieldTypeRequest;
import com.github.admin.server.service.GenFieldTypeService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@RestController
public class FieldTypeController {

    @Resource
    private GenFieldTypeService genFieldTypeService;

    @PostMapping("/fieldType/page")
    public Result<DataPage<GenFieldType>> page(@RequestBody GenFieldTypeRequest request) {
        return genFieldTypeService.fieldTypePage(request);
    }

    @GetMapping("/fieldType/getById/{id}")
    public Result<GenFieldType> findById(@PathVariable("id") Long id) {
        return genFieldTypeService.findById(id);
    }

    @PostMapping("/fieldType/findAllAttrType")
    public Result<Set<String>> list() {
        return genFieldTypeService.findAllAttrType();
    }

    @PostMapping("/fieldType/save")
    public Result save(@RequestBody GenFieldTypeRequest request) {
        return genFieldTypeService.save(request);
    }

    @PostMapping("/fieldType/update")
    public Result update(@RequestBody GenFieldTypeRequest request) {
        return genFieldTypeService.update(request);
    }

    @PostMapping("/fieldType/deleteByIds")
    public Result delete(@RequestBody List<Long> ids) {
        return genFieldTypeService.deleteByIds(ids);
    }
}
