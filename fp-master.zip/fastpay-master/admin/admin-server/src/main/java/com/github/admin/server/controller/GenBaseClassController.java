package com.github.admin.server.controller;

import com.github.admin.common.entity.GenBaseClass;
import com.github.admin.common.request.BaseClassRequest;
import com.github.admin.server.service.GenBaseClassService;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 基类管理
 *
 * @author Mark sunlightcs@gmail.com
 */

@RestController
@RequestMapping("/baseClass")
public class GenBaseClassController {

    @Resource
    private GenBaseClassService genBaseClassService;

    @PostMapping("/page")
    public Result<DataPage<GenBaseClass>> page(@RequestBody BaseClassRequest request) {
        return genBaseClassService.page(request);
    }

    @PostMapping("/list")
    public Result<List<GenBaseClass>> list() {
        return genBaseClassService.list();
    }

    @GetMapping("/save/{id}")
    public Result<GenBaseClass> get(@PathVariable("id") Long id) {
        return genBaseClassService.findById(id);
    }

    @PostMapping("/save")
    public Result save(@RequestBody BaseClassRequest entity) {
        return genBaseClassService.save(entity);
    }

    @PostMapping("/update")
    public Result update(@RequestBody BaseClassRequest entity) {
        return genBaseClassService.update(entity);
    }

    @PostMapping("/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return genBaseClassService.deleteByIds(ids);
    }
}
