package com.github.admin.server.controller;

import com.github.admin.common.entity.GenDataSource;
import com.github.admin.common.request.GenDataSourceRequest;
import com.github.admin.server.service.GenDataSourceService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
public class GenDataSourceController {

    @Resource
    private GenDataSourceService datasourceServiceGen;

    @PostMapping("/dataSource/page")
    public Result<DataPage<GenDataSource>> page(@RequestBody GenDataSourceRequest request) {
        return datasourceServiceGen.dataSourcePage(request);
    }

    @PostMapping("/dataSource/list")
    public Result<List<GenDataSource>> list() {
        return datasourceServiceGen.selectBySelective(new GenDataSourceRequest());
    }

    @GetMapping("/dataSource/get/{id}")
    public Result<GenDataSource> get(@PathVariable("id") Long id) {
        return datasourceServiceGen.findById(id);
    }

    @GetMapping("/dataSource/test/{id}")
    public Result<String> datasourceTest(@PathVariable("id") Long id) {
        return datasourceServiceGen.datasourceTest(id);
    }

    @PostMapping("/dataSource/save")
    public Result save(@RequestBody GenDataSourceRequest entity) {
        return datasourceServiceGen.save(entity);
    }

    @PostMapping("/dataSource/update")
    public Result update(@RequestBody GenDataSourceRequest entity) {
        return datasourceServiceGen.update(entity);
    }

    @PostMapping("/dataSource/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return datasourceServiceGen.deleteByIds(ids);
    }
}
