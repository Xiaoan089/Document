package com.github.admin.server.controller;

import com.github.admin.common.entity.GenTableInfo;
import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.request.GenTableFieldRequest;
import com.github.admin.common.request.SysMenuRequest;
import com.github.admin.common.request.TableInfoRequest;
import com.github.admin.common.group.GeneratorGroup;
import com.github.admin.server.service.GeneratorService;
import com.github.admin.server.service.SysDictTypeService;
import com.github.admin.server.service.GenTableInfoService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 代码生成
 */
@RestController
@RequestMapping("/generator")
public class GeneratorController {

    @Resource
    private GeneratorService generatorService;
    @Resource
    private GenTableInfoService genTableInfoService;
    @Resource
    private SysDictTypeService sysDictTypeService;

    @PostMapping("/pageTable")
    public Result<DataPage<GenTableInfo>> pageTable(@RequestBody TableInfoRequest request) {
        return genTableInfoService.page(request);
    }

    @GetMapping("/getTable/{id}")
    public Result<GenTableInfo> getTable(@PathVariable("id") Long id) {
        return genTableInfoService.findById(id);
    }

    @PostMapping("/updateTable")
    public Result updateTable(@RequestBody TableInfoRequest request) {
        return genTableInfoService.update(request);
    }

    @PostMapping("/deleteTable")
    public Result deleteTable(@RequestBody List<Long> ids) {
        return genTableInfoService.deleteByIds(ids);
    }

    /**
     * 获取数据源中所有表
     */
    @GetMapping("/getDataSourceTableList/{id}")
    public Result<List<GenTableInfo>> generatorService(@PathVariable("id") Long id) {
        return generatorService.generatorService(id);
    }

    /**
     * 导入数据源中的表
     */
    @PostMapping("/datasourceTable")
    public Result datasourceTable(@RequestBody TableInfoRequest request) {
        generatorService.datasourceTable(request);
        return Result.ok();
    }

    /**
     * 更新列数据
     */
    @PostMapping("/updateTableField/{tableId}")
    public Result updateTableField(@PathVariable("tableId") Long tableId, @RequestBody List<GenTableFieldRequest> tableFieldList) {
        generatorService.updateTableField(tableId, tableFieldList);
        return Result.ok();
    }

    @PostMapping("/dict")
    public Result<List<SysDictType>> dict() {
        List<SysDictType> list = sysDictTypeService.getDictTypeList();
        return new Result<List<SysDictType>>().ok(list);
    }

    /**
     * 生成代码
     */
    @PostMapping("/generator")
    public Result generator(@RequestBody TableInfoRequest request) {
        //生成代码
        return generatorService.generatorCode(request);
    }

    /**
     * 创建菜单
     */
    @PostMapping("/menu")
    public Result menu(@Validated(GeneratorGroup.class) @RequestBody SysMenuRequest request) {
        //创建菜单
        return generatorService.generatorMenu(request);
    }
}
