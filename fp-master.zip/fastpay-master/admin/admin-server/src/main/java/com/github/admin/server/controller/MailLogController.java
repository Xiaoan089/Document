package com.github.admin.server.controller;

import com.github.admin.common.entity.SysMailLog;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.admin.server.service.SysMailLogService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;


/**
 * 邮件发送记录
 */

@RestController
@RequestMapping("/sysMailLog")
public class MailLogController {

    @Resource
    private SysMailLogService sysMailLogService;

    @PostMapping("/page")
    public Result<DataPage<SysMailLog>> page(@Parameter(hidden = true) @RequestBody SysMailLogRequest mailLogRequest) {
        return sysMailLogService.sysMailLogPage(mailLogRequest);
    }

    @PostMapping("/delete")
    public Result delete(@RequestBody Long[] ids) {
        return sysMailLogService.deleteByIds(Arrays.asList(ids));
    }

}
