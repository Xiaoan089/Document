package com.github.admin.server.controller;

import com.github.admin.common.entity.SysMailTemplate;
import com.github.admin.common.request.EmailConfigRequest;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.admin.common.request.SysMailTemplateRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysMailTemplateService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;



@RestController
@RequestMapping("/sysMailTemplate")
@Tag(name = "邮件模板")
public class MailTemplateController {

    @Resource
    private SysMailTemplateService sysMailTemplateService;

    @PostMapping("/page")
    public Result<DataPage<SysMailTemplate>> page(@Parameter(hidden = true) @RequestBody SysMailTemplateRequest templateRequest) {
        return sysMailTemplateService.sysMailTemplatePage(templateRequest);
    }

    @PostMapping("/saveConfig")
    public Result saveConfig(@Validated @RequestBody EmailConfigRequest config) {
        return sysMailTemplateService.updateValueByCode(config);
    }

    @GetMapping("/info/{id}")
    public Result<SysMailTemplate> info(@PathVariable("id") Long id) {
        return sysMailTemplateService.findById(id);
    }

    @PostMapping("/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody SysMailTemplateRequest request) {
        return sysMailTemplateService.save(request);
    }

    @PostMapping("/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysMailTemplateRequest request) {
        return sysMailTemplateService.update(request);
    }

    @PostMapping("/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysMailTemplateService.delete(ids);
    }

    @PostMapping("/send")
    public Result send(@RequestBody SysMailLogRequest mailLogRequest) throws Exception {
        return sysMailTemplateService.sendMail(mailLogRequest);
    }

}
