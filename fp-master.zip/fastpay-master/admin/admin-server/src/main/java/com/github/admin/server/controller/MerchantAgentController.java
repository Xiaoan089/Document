package com.github.admin.server.controller;

import com.github.admin.server.service.MerchantAgentService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.common.entity.MerchantAgent;
import com.github.trans.front.common.request.MerchantAgentRequest;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
public class MerchantAgentController {

    @Resource
    private MerchantAgentService merchantAgentServiceImpl;

    @PostMapping("/admin/merchantAgent/save")
    public Result save(@RequestBody MerchantAgentRequest request) {
        return merchantAgentServiceImpl.save(request);
    }

    @PostMapping("/admin/merchantAgent/update")
    Result update(@RequestBody MerchantAgentRequest request){
        return merchantAgentServiceImpl.update(request);
    }

    @PostMapping("/admin/merchantAgent/delete")
    Result delete(@RequestBody MerchantAgentRequest request){
        return merchantAgentServiceImpl.delete(request);
    }

    @PostMapping("/admin/merchantAgent/updateAgentPassword")
    Result updateAgentPassword(@RequestBody MerchantAgentRequest request){
        return merchantAgentServiceImpl.updateAgentPassword(request);
    }

    @PostMapping("/admin/merchantAgent/updateAgentFundPassword")
    Result updateAgentFundPassword(@RequestBody MerchantAgentRequest request){
        return merchantAgentServiceImpl.updateAgentFundPassword(request);
    }

    @GetMapping("/admin/merchantAgent/findById/{id}")
    Result<MerchantAgent> findById(@PathVariable("id") Long id){
        return merchantAgentServiceImpl.findById(id);
    }

    @PostMapping("/admin/merchantAgent/page")
    Result<DataPage<MerchantAgent>> page(@RequestBody MerchantAgentRequest request){
        return merchantAgentServiceImpl.page(request);
    }
}
