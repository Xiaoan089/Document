package com.github.admin.server.controller;

import com.github.admin.common.user.SecurityUser;
import com.github.admin.server.service.MerchantService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.common.entity.Merchant;
import com.github.trans.front.common.request.MerchantRequest;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
public class MerchantController {

    @Resource
    private MerchantService merchantServiceImpl;

    @PostMapping("/admin/merchant/save")
    public Result save(@RequestBody MerchantRequest request){
        return merchantServiceImpl.save(request);
    }


    @PostMapping("/admin/merchant/update")
    public Result update(@RequestBody MerchantRequest request){
        return merchantServiceImpl.update(request);
    }

    @PostMapping("/admin/merchant/delete")
    Result delete(@RequestBody MerchantRequest request){
        return merchantServiceImpl.delete(request);
    }

    @PostMapping("/admin/merchant/updatePassword")
    Result updatePassword(@RequestBody MerchantRequest request){
        return merchantServiceImpl.updatePassword(request);
    }

    @PostMapping("/admin/merchant/updateFundPassword")
    Result updateFundPassword(@RequestBody MerchantRequest request){
        return merchantServiceImpl.updateFundPassword(request);
    }
    @GetMapping("/admin/merchant/findById/{id}")
    Result<Merchant> findById(@PathVariable("id") Long id){
        return merchantServiceImpl.findById(id);
    }

    @PostMapping("/admin/merchant/page")
    Result<DataPage<Merchant>> page(@RequestBody MerchantRequest request){
        return merchantServiceImpl.page(request);
    }


}
