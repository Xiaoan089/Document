package com.github.admin.server.controller;

import com.github.admin.common.entity.TbNews;
import com.github.admin.common.request.NewsRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.NewsService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 新闻
 */
@RestController
public class NewsController {

    @Resource
    private NewsService newsService;

    @PostMapping("/news/page")
    public Result<DataPage<TbNews>> page(@RequestBody NewsRequest request) {
        return newsService.newsPage(request);
    }

    @GetMapping("/news/info/{id}")
    public Result<TbNews> info(@PathVariable("id") Long id) {
        return newsService.findById(id);
    }

    @PostMapping("/news/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody NewsRequest request) {
        return newsService.save(request);
    }

    @PostMapping("/news/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody NewsRequest request) {
        return newsService.update(request);
    }

    @PostMapping("/news/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return newsService.delete(ids);
    }

}
