package com.github.admin.server.controller;

import com.github.admin.common.entity.TbProduct;
import com.github.admin.common.request.ProductRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.ProductService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


/**
 * 产品管理
 */
@RestController
public class ProductController {

    @Resource
    private ProductService productService;

    @PostMapping("/product/page")
    public Result<DataPage<TbProduct>> page(@RequestBody ProductRequest request) {
        return productService.productPage(request);
    }

    @GetMapping("/product/get/{id}")
    public Result<TbProduct> findById(@PathVariable("id") Long id) {
        return productService.findById(id);
    }

    @PostMapping("/product/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody ProductRequest request) {
        return productService.save(request);
    }

    @PostMapping("/product/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class})  @RequestBody ProductRequest request) {
        return productService.update(request);
    }

    @PostMapping("/product/delete")
    public Result delete(@RequestBody Long[] ids) {
        return productService.delete(List.of(ids));
    }

}
