package com.github.admin.server.controller;


import com.github.admin.common.entity.ScheduleJob;
import com.github.admin.common.request.ScheduleJobRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.server.service.ScheduleJobService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import net.dreamlu.mica.core.validation.UpdateGroup;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 定时任务
 */
@RestController
@Tag(name = "定时任务")
public class ScheduleJobController {
    @Resource
    private ScheduleJobService scheduleJobService;

    @PostMapping("/schedule/page")
    public Result<DataPage<ScheduleJob>> page(@RequestBody ScheduleJobRequest request) {
        return scheduleJobService.page(request);
    }

    @GetMapping("/schedule/findById/{id}")
    public Result<ScheduleJob> findById(@PathVariable("id") Long id) {
        return scheduleJobService.findById(id);
    }

    @PostMapping("/schedule/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody ScheduleJobRequest request) {
        return scheduleJobService.save(request);
    }

    @PostMapping("/schedule/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody ScheduleJobRequest request) {
        return scheduleJobService.update(request);
    }

    @PostMapping("/schedule/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return scheduleJobService.deleteByIds(ids);
    }

    @PostMapping("/schedule/run")
    public Result run(@RequestBody List<Long> ids) {
        return scheduleJobService.run(ids);
    }

    @PostMapping("/schedule/pause")
    public Result pause(@RequestBody List<Long> ids) {
        return scheduleJobService.pause(ids);
    }

    @PostMapping("/schedule/resume")
    public Result resume(@RequestBody List<Long> ids) {
        return scheduleJobService.resume(ids);
    }

}
