package com.github.admin.server.controller;


import com.github.admin.common.entity.ScheduleJobLog;
import com.github.admin.common.request.ScheduleJobLogRequest;
import com.github.admin.server.service.ScheduleJobLogService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 定时任务日志
 */
@RestController
@Tag(name = "定时任务日志")
@AllArgsConstructor
public class ScheduleJobLogController {
    @Resource
    private ScheduleJobLogService scheduleJobLogService;

    @PostMapping("/scheduleLog/page")
    public Result<DataPage<ScheduleJobLog>> page(@Parameter(hidden = true) @RequestBody ScheduleJobLogRequest request) {
        return scheduleJobLogService.page(request);
    }

    @GetMapping("/scheduleLog/findById/{id}")
    @Operation(summary = "信息")
    @RequiresPermissions("sys:schedule:log")
    public Result<ScheduleJobLog> findById(@PathVariable("id") Long id) {
        return scheduleJobLogService.findById(id);
    }
}
