package com.github.admin.server.controller;

import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysSms;
import com.github.admin.common.request.SysSmsRequest;
import com.github.admin.common.utils.ValidatorUtils;
import com.github.admin.common.group.AliyunGroup;
import com.github.admin.common.group.QcloudGroup;
import com.github.admin.common.group.QiniuGroup;
import com.github.admin.server.service.SysSmsService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 短信服务
 */
@RestController
public class SmsController {

    @Resource
    private SysSmsService sysSmsService;

    @PostMapping("/sms/page")
    public Result<DataPage<SysSms>> page(@Parameter(hidden = true) @RequestBody SysSmsRequest sysSmsRequest) {
        return sysSmsService.page(sysSmsRequest);
    }

    @PostMapping("/sms/save")
    public Result save(@RequestBody SysSmsRequest request) {
        //校验数据
        if (request.getPlatform() == Constant.SmsService.ALIYUN.getValue()) {
            //校验阿里云数据
            ValidatorUtils.validateEntity(request.getConfig(), AliyunGroup.class);
        } else if (request.getPlatform() == Constant.SmsService.QCLOUD.getValue()) {
            //校验腾讯云数据
            ValidatorUtils.validateEntity(request.getConfig(), QcloudGroup.class);
        } else if (request.getPlatform() == Constant.SmsService.QINIU.getValue()) {
            //校验七牛数据
            ValidatorUtils.validateEntity(request.getConfig(), QiniuGroup.class);
        }
        return sysSmsService.save(request);
    }

    @PostMapping("/sms/update")
    public Result update(@RequestBody SysSmsRequest request) {
        //校验数据
        if (request.getPlatform() == Constant.SmsService.ALIYUN.getValue()) {
            //校验阿里云数据
            ValidatorUtils.validateEntity(request.getConfig(), AliyunGroup.class);
        } else if (request.getPlatform() == Constant.SmsService.QCLOUD.getValue()) {
            //校验腾讯云数据
            ValidatorUtils.validateEntity(request.getConfig(), QcloudGroup.class);
        } else if (request.getPlatform() == Constant.SmsService.QINIU.getValue()) {
            //校验七牛数据
            ValidatorUtils.validateEntity(request.getConfig(), QiniuGroup.class);
        }
        return sysSmsService.update(request);
    }

    @GetMapping("/sms/findById/{id}")
    public Result<SysSms> findById(@PathVariable("id") Long id) {
        return sysSmsService.findById(id);
    }

    @PostMapping("/sms/send")
    public Result send(@RequestBody SysSmsRequest smsRequest) {
        return sysSmsService.send(smsRequest);
    }

    @PostMapping("/sms/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysSmsService.delete(ids);
    }

}
