package com.github.admin.server.controller;

import com.github.admin.common.entity.SysDept;
import com.github.admin.common.request.SysDeptRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.server.service.SysDeptService;
import com.github.framework.core.Result;
import lombok.extern.slf4j.Slf4j;
import net.dreamlu.mica.core.validation.UpdateGroup;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 部门管理
 */
@RestController
@Slf4j
public class SysDeptController {

    @Resource
    private SysDeptService sysDeptService;

    @PostMapping("/dept/list")
    public Result<List<SysDept>> list(@RequestBody SysDeptRequest request) {
        return sysDeptService.list(request);
    }

    @PostMapping("/dept/findById")
    public Result<SysDept> findById(@RequestBody SysDeptRequest request) {
        return sysDeptService.findByIdOnType(request);
    }

    @PostMapping("/dept/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody SysDeptRequest request) {
        return sysDeptService.save(request);
    }

    @PostMapping("/dept/update")
    public Result update(@Validated({UpdateGroup.class,DefaultGroup.class}) @RequestBody SysDeptRequest request) {
        return sysDeptService.update(request);
    }

    @PostMapping("/dept/delete")
    public Result delete(@RequestBody SysDeptRequest sysDeptRequest) {
        return sysDeptService.deleteByIds(sysDeptRequest);
    }

}
