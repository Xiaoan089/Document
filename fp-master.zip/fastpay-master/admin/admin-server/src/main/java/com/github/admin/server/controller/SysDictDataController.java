package com.github.admin.server.controller;
import com.github.admin.common.entity.SysDictData;
import com.github.admin.common.request.SysDictDataRequest;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysDictDataService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 字典数据
 */
@RestController
public class SysDictDataController {

    @Resource
    private SysDictDataService sysDictDataService;

    @PostMapping("/dict/page")
    public Result<DataPage<SysDictData>> page(@RequestBody SysDictDataRequest request) {
        return sysDictDataService.page(request);
    }

    @GetMapping("/dict/findById/{id}")
    public Result<SysDictData> findById(@PathVariable("id") Long id) {
        return sysDictDataService.findById(id);
    }

    @PostMapping("/dict/save")
    public Result save(@Validated(DefaultGroup.class) @RequestBody SysDictDataRequest request) {
        return sysDictDataService.save(request);
    }

    @PostMapping("/dict/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysDictDataRequest request) {
        return sysDictDataService.update(request);
    }

    @PostMapping("/dict/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysDictDataService.delete(ids);
    }

}
