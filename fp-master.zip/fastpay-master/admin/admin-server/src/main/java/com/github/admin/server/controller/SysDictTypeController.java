package com.github.admin.server.controller;

import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.request.SysDictTypeRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysDictTypeService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
public class SysDictTypeController {

    @Resource
    private SysDictTypeService sysDictTypeService;

    @PostMapping("/dict/type/page")
    public Result<DataPage<SysDictType>> page(@RequestBody SysDictTypeRequest request) {
        return sysDictTypeService.page(request);
    }

    @GetMapping("/dict/type/get/{id}")
    public Result<SysDictType> get(@PathVariable("id") Long id) {
        return sysDictTypeService.findById(id);
    }

    @PostMapping("/dict/type/save")
    public Result save(@Validated({AddGroup.class,DefaultGroup.class}) @RequestBody SysDictTypeRequest request) {
        return sysDictTypeService.save(request);
    }

    @PostMapping("/dict/type/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysDictTypeRequest request) {
        return sysDictTypeService.update(request);
    }

    @PostMapping("/dict/type/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysDictTypeService.delete(ids);
    }

    @GetMapping("/dict/type/all")
    public Result<List<SysDictType>> all() {
        return sysDictTypeService.getAllList();
    }

}
