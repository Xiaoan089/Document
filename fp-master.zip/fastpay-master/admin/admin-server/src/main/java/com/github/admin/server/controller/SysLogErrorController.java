package com.github.admin.server.controller;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.common.entity.SysLogError;
import com.github.admin.common.request.SysLogErrorRequest;
import com.github.admin.server.service.SysLogErrorService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


/**
 * 异常日志
 */
@RestController
public class SysLogErrorController {

    @Resource
    private SysLogErrorService sysLogErrorService;

    @PostMapping("/log/error/page")
    public Result<DataPage<SysLogError>> page(@Parameter(hidden = true) @RequestBody SysLogErrorRequest request) {
        return sysLogErrorService.sysLogErrorPage(request);
    }

    @PostMapping("/log/error/selectListSelective")
    public Result<List<SysLogError>> selectListSelective(@Parameter(hidden = true) @RequestBody SysLogErrorRequest sysLogErrorDTO, HttpServletResponse response) throws Exception {
        Map<String, Object> map = BeanUtil.beanToMap(sysLogErrorDTO);
        return sysLogErrorService.selectListSelective(map);
    }

    @PostMapping("/log/error/save")
    Result save(@RequestBody SysLogErrorRequest logRequest) {
        return sysLogErrorService.save(logRequest);
    }
}
