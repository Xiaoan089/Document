package com.github.admin.server.controller;
import com.github.admin.common.entity.SysLogLogin;
import com.github.admin.common.request.SysLogLoginRequest;
import com.github.admin.server.service.SysLogLoginService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;

/**
 * 登录日志
 */
@AllArgsConstructor
@RestController
@Tag(name = "登录日志")
public class SysLogLoginController {

    @Resource
    private SysLogLoginService sysLogLoginService;

    @PostMapping("/log/login/sysLogLogiPage")
    public Result<DataPage<SysLogLogin>> page(@Parameter(hidden = true) @RequestBody SysLogLoginRequest request) {
        return sysLogLoginService.sysLogLoginPage(request);
    }

    @PostMapping("/log/login/list")
    public Result<List<SysLogLogin>> export(@Parameter(hidden = true)@RequestBody SysLogLoginRequest request) throws Exception {
        return sysLogLoginService.list(request);
    }
    @PostMapping("/log/save")
    public Result save(@RequestBody SysLogLoginRequest request){
        return sysLogLoginService.save(request);
    }
}
