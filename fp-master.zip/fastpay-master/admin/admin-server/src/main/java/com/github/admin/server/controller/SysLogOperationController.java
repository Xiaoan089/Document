package com.github.admin.server.controller;

import com.github.admin.common.entity.SysLogOperation;
import com.github.admin.common.request.SysLogOperationRequest;
import com.github.admin.server.service.SysLogOperationService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * 操作日志
 */
@RestController
public class SysLogOperationController {

    @Resource
    private SysLogOperationService sysLogOperationService;

    @PostMapping("/log/operation/page")
    public Result<DataPage<SysLogOperation>> page(@RequestBody SysLogOperationRequest request) {
        return sysLogOperationService.sysLogOperationPage(request);
    }

    @PostMapping("/log/operation/selectListBySelective")
    public Result<List<SysLogOperation>> selectListBySelective(@RequestBody SysLogOperationRequest request){
        return sysLogOperationService.selectListBySelective(request);
    }

    @PostMapping("/log/operation/save")
    public Result save(@RequestBody SysLogOperationRequest log) {
        return sysLogOperationService.save(log);
    }

}
