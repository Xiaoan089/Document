package com.github.admin.server.controller;

import com.github.admin.common.entity.SysMenu;
import com.github.admin.common.request.SysMenuRequest;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.server.service.SysMenuService;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;
import com.github.trans.front.common.group.AddGroup;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 菜单管理
 */
@RestController
public class SysMenuController {


    @Resource
    private SysMenuService sysMenuService;

    @PostMapping("/menu/nav")
    public Result<List<SysMenu>> nav(@RequestBody SysMenuRequest sysMenuRequest) {
        return sysMenuService.getUserMenuList(sysMenuRequest);
    }

    @PostMapping("/menu/list")
    public Result<SysMenu> list(@RequestBody SysMenuRequest request) {
        return sysMenuService.list(request);
    }

    @PostMapping("/menu/findById")
    public Result<SysMenu> findById(@RequestBody SysMenuRequest sysMenuRequest) {
        return sysMenuService.findById(sysMenuRequest);
    }

    @PostMapping("/menu/save")
    public Result save(@Validated({AddGroup.class,DefaultGroup.class}) @RequestBody SysMenuRequest request) {
        return sysMenuService.save(request);
    }

    @PostMapping("/menu/update")
    public Result update(@Validated(DefaultGroup.class) @RequestBody SysMenuRequest request) {
        return sysMenuService.update(request);
    }

    @PostMapping("/menu/delete")
    public Result delete(@RequestBody SysMenuRequest sysMenuRequest) {
        return sysMenuService.deleteById(sysMenuRequest);
    }

    @PostMapping("/menu/select")
    public Result<List<SysMenu>> select(@RequestBody SysMenuRequest sysMenuRequest) {
        return sysMenuService.getUserMenuList(sysMenuRequest);
    }

    @PostMapping("/menu/getPermissionsList")
    public Result<List<String>> getPermissionsList(@RequestBody UserDetail user) {
        return sysMenuService.getPermissionsList(user);
    }

    @PostMapping("/menu/getUserPermissionsList")
    public Result<List<String>> getUserPermissionsList(@RequestBody UserDetail user) {
        return sysMenuService.getUserPermissionsList(user);
    }
}
