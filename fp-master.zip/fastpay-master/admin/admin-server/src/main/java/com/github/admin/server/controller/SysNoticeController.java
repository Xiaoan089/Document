package com.github.admin.server.controller;


import com.github.admin.common.entity.SysNotice;
import com.github.admin.common.request.SysNoticeRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.SelectionGroup;
import com.github.admin.common.websocketdata.MessageDataUserList;
import com.github.admin.server.service.SysNoticeService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import net.dreamlu.mica.core.validation.UpdateGroup;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


/**
 * 通知管理
 */
@RestController
public class SysNoticeController {

    @Resource
    private SysNoticeService sysNoticeService;

    @PostMapping("/notice/page")
    public Result<DataPage<SysNotice>> page(@RequestBody SysNoticeRequest sysNoticeRequest) {
        return sysNoticeService.page(sysNoticeRequest);
    }

    @PostMapping("/notice/user/page")
    public Result<DataPage<SysNotice>> userPage(@Validated(SelectionGroup.class) @RequestBody SysNoticeRequest sysNoticeRequest) {
        return sysNoticeService.getNoticeUserPage(sysNoticeRequest);
    }

    @PostMapping("/notice/mynotice/page")
    public Result<DataPage<SysNotice>> myNoticePage(@RequestBody SysNoticeRequest sysNoticeRequest) {
        return sysNoticeService.getMyNoticePage(sysNoticeRequest);
    }

    @GetMapping("/notice/get/{id}")
    public Result<SysNotice> get(@PathVariable("id") Long id) {
        return sysNoticeService.findById(id);
    }

    @PostMapping("/notice/save")
    public Result<MessageDataUserList> save(@Validated(AddGroup.class) @RequestBody SysNoticeRequest request) {
        return sysNoticeService.saveNotice(request);
    }

    @PostMapping("/notice/update")
    public Result update(@Validated(UpdateGroup.class) @RequestBody SysNoticeRequest request) {
        return sysNoticeService.updateNotice(request);
    }

    @PostMapping("/notice/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysNoticeService.delete(ids);
    }

}
