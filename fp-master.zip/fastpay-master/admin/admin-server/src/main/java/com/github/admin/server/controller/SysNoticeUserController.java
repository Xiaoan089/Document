package com.github.admin.server.controller;

import com.github.admin.common.request.SysNoticeRequest;
import com.github.admin.server.service.SysNoticeUserService;
import com.github.framework.core.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 通知管理
 */
@RestController
public class SysNoticeUserController {

    @Resource
    private SysNoticeUserService sysNoticeUserService;

    @PostMapping("/notice/user/update")
    public Result update(@RequestBody SysNoticeRequest sysNoticeRequest) {
        return sysNoticeUserService.updateReadStatus(sysNoticeRequest);
    }

    @GetMapping("/notice/user/getUnReadNoticeCount/{id}")
    public Result<Integer> get(@PathVariable("id") Long userId) {
        return sysNoticeUserService.getUnReadNoticeCount(userId);
    }
}
