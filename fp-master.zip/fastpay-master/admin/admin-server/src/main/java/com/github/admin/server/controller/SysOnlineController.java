package com.github.admin.server.controller;
import com.github.admin.common.entity.SysOnlineEntity;
import com.github.admin.common.request.SysOnlineRequest;
import com.github.admin.server.service.SysUserTokenService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 在线用户
 */
@RestController
public class SysOnlineController {

    @Resource
    private SysUserTokenService sysUserTokenService;

    @PostMapping("/online/page")
    public Result<DataPage<SysOnlineEntity>> page(@Parameter(hidden = true) @RequestBody SysOnlineRequest request) {
        return sysUserTokenService.onlinePage(request);
    }

    @GetMapping("/online/logout")
    public Result logout(@RequestParam("id") Long id) {
        return sysUserTokenService.logout(id);
    }
}
