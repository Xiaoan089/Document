package com.github.admin.server.controller;

import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysParamsService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.entity.SysParams;
import com.github.trans.front.common.request.SysParamsRequest;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


@RestController
@RequestMapping
public class SysParamsController {

    @Resource
    private SysParamsService sysParamsService;

    @PostMapping("/params/page")
    public Result<DataPage<SysParams>> page(@RequestBody SysParamsRequest request) {
        return sysParamsService.page(request);
    }

    @GetMapping("/params/findById/{id}")
    public Result<SysParams> findById(@PathVariable("id") Long id) {
        return sysParamsService.findById(id);
    }

    @PostMapping("/params/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody SysParamsRequest request) {
        return sysParamsService.save(request);
    }

    @PostMapping("/params/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysParamsRequest request) {
        return sysParamsService.update(request);
    }

    @PostMapping("/params/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysParamsService.delete(ids);
    }

    @GetMapping("/params/list")
    public Result<List<SysParams>> list(@RequestBody SysParamsRequest request) {
        return sysParamsService.list(request);
    }

    @PostMapping("/params/getValueObject")
    public <T> Result<T> getValueObject(@RequestBody SysParamsRequest request) {
        return sysParamsService.getValueObject(request);
    }

    @PostMapping("/params/getValueByCode")
    public Result<String> getValueByCode(@RequestBody String paramCode) {
        return sysParamsService.getValue(paramCode);
    }

    @PostMapping("/params/updateValueByCode")
    public Result updateValueByCode(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysParamsRequest request){
        return sysParamsService.updateValueByCode(request);
    }
}
