package com.github.admin.server.controller;
import com.github.admin.common.entity.SysPost;
import com.github.admin.common.request.SysPostRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysPostService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


/**
 * 岗位管理
 */
@RestController
public class SysPostController {

    @Resource
    private SysPostService sysPostService;

    @PostMapping("/post/page")
    public Result<DataPage<SysPost>> page(@RequestBody SysPostRequest sysPostRequest) {
        return sysPostService.page(sysPostRequest);
    }

    @GetMapping("/post/list/{sysType}")
    public Result<List<SysPost>> list(@PathVariable("sysType") Integer sysType) {
        SysPostRequest sysPostRequest = new SysPostRequest();
        sysPostRequest.setSysType(sysType);
        return sysPostService.selectListSelective(sysPostRequest);
    }

    @PostMapping("/post/findById")
    public Result<SysPost> findById(@RequestBody SysPostRequest sysPostRequest) {
        return sysPostService.findById(sysPostRequest);
    }

    @PostMapping("/post")
    public Result save(@Validated(AddGroup.class) @RequestBody SysPostRequest request) {
        return sysPostService.save(request);
    }

    @PostMapping("/post/update")
    public Result update(@Validated(UpdateGroup.class) @RequestBody SysPostRequest request) {
        return sysPostService.update(request);
    }

    @PostMapping("/post/delete")
    public Result delete(@RequestBody SysPostRequest sysPostRequest) {
        return sysPostService.delete(sysPostRequest);
    }
}
