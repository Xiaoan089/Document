package com.github.admin.server.controller;
import com.github.admin.common.dto.RegionProvince;
import com.github.admin.common.entity.SysRegion;
import com.github.admin.common.request.SysRegionRequest;
import com.github.admin.common.response.SysRegionResponse;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysRegionService;
import com.github.framework.core.Result;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 行政区域
 */
@RestController
public class SysRegionController {

    @Resource
    private SysRegionService sysRegionService;

    @PostMapping("/region/list")
    public Result<List<SysRegionResponse>> list(@RequestBody SysRegionRequest request) {
        return sysRegionService.list(request);
    }

    @GetMapping("/region/tree")
    public Result<List<Map<String, Object>>> tree() {
        return sysRegionService.getTreeList();
    }

    @GetMapping("/region/findById/{id}")
    public Result<SysRegion> findById(@PathVariable("id") Long id) {
        return sysRegionService.findById(id);
    }

    @PostMapping("/region/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody SysRegionRequest request) {
        return sysRegionService.save(request);
    }

    @PostMapping("/region/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysRegionRequest request) {
        return sysRegionService.update(request);
    }

    @GetMapping("/region/delete/{id}")
    public Result delete(@PathVariable("id") Long id) {
        return sysRegionService.delete(id);
    }

    @GetMapping("/region/getRegion")
    public Result<List<RegionProvince>> getRegion(@RequestParam(value = "threeLevel", defaultValue = "true") boolean threeLevel) {
        return sysRegionService.getRegion(threeLevel);
    }

}
