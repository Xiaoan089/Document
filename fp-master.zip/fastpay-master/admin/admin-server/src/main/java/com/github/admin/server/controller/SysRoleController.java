package com.github.admin.server.controller;

import com.github.admin.common.entity.SysRole;
import com.github.admin.common.request.SysRoleRequest;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysRoleService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 角色管理
 */
@RestController
public class SysRoleController {

    @Resource
    private SysRoleService sysRoleService;

    @PostMapping("/role/page")
    public Result<DataPage<SysRole>> page(@RequestBody SysRoleRequest sysRoleRequest) {
        return sysRoleService.page(sysRoleRequest);
    }

    @PostMapping("/role/list")
    public Result<List<SysRole>> list(@RequestBody SysRoleRequest sysRoleRequest) {
        return sysRoleService.list(sysRoleRequest);
    }

    @PostMapping("/role/findByIdOnType")
    public Result<SysRole> findByIdOnType(@RequestBody SysRoleRequest sysRoleRequest) {
        return sysRoleService.findByIdOnType(sysRoleRequest);
    }

    @PostMapping("/role/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody SysRoleRequest request) {
        return sysRoleService.save(request);
    }

    @PostMapping("/role/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysRoleRequest request) {
        return sysRoleService.update(request);
    }

    @PostMapping("/role/delete")
    public Result delete(@RequestBody SysRoleRequest sysRoleRequest) {
        return sysRoleService.delete(sysRoleRequest);
    }
}
