package com.github.admin.server.controller;

import com.github.admin.server.service.SysRoleDataScopeService;
import com.github.framework.core.Result;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@AllArgsConstructor
@RestController
@Tag(name = "系统角色数据范围")
public class SysRoleDataScopeController {

    @Resource
    private SysRoleDataScopeService sysRoleDataScopeService;


    @GetMapping("/role/data/scope/getDataScopeList")
    Result<List<Long>> getDataScopeList(@RequestParam("userId") Long userId) {
        return sysRoleDataScopeService.getDataScopeList(userId);
    }
}
