package com.github.admin.server.controller;

import com.github.admin.common.entity.SysSmsLog;
import com.github.admin.common.request.SysSmsLogRequest;
import com.github.admin.server.service.SysSmsLogService;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import com.github.framework.core.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 短信日志
 */
@RestController
public class SysSmsLogController {

    @Resource
    private SysSmsLogService sysSmsLogService;

    @PostMapping("/smsLog/page")
    public Result<DataPage<SysSmsLog>> page(@Parameter(hidden = true) @RequestBody SysSmsLogRequest request) {
        return sysSmsLogService.smsLogPage(request);
    }

    @PostMapping("/smsLog/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return sysSmsLogService.delete(ids);
    }
}
