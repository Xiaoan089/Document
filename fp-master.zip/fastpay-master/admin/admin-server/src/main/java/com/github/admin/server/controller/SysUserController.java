package com.github.admin.server.controller;

import com.github.admin.common.entity.SysUser;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.response.SysUserResponse;
import com.github.admin.common.user.SecurityUser;
import com.github.admin.common.utils.ConvertUtils;
import com.github.admin.common.group.AddGroup;
import com.github.admin.common.group.DefaultGroup;
import com.github.admin.common.group.UpdateGroup;
import com.github.admin.server.service.SysRoleUserService;
import com.github.admin.server.service.SysUserPostService;
import com.github.admin.server.service.SysUserService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 用户管理
 */
@RestController
public class SysUserController {
    @Resource
    private SysUserService sysUserService;

    @Resource
    private SysUserPostService sysUserPostService;

    @Resource
    private SysRoleUserService sysRoleUserService;

    @PostMapping("/user/page")
    public Result<DataPage<SysUser>> page(@Parameter(hidden = true) @RequestBody SysUserRequest sysUserRequest) {
        return sysUserService.page(sysUserRequest);
    }

    @PostMapping("/user/findById")
    public Result<SysUser> findById(@RequestBody SysUserRequest request) {
        return sysUserService.findByIdOnType(request);
    }

    @GetMapping("/user/info")
    public Result<SysUser> info() {
        SysUser data = ConvertUtils.sourceToTarget(SecurityUser.getUser(), SysUser.class);
        return Result.ok(data);
    }

    @PostMapping("/user/password")
    public Result password(@Validated(UpdateGroup.class) @RequestBody SysUserRequest request) {
        return sysUserService.updatePassword(request);
    }

    @PostMapping("/user/save")
    public Result save(@Validated({AddGroup.class, DefaultGroup.class}) @RequestBody SysUserRequest request) {
        return sysUserService.save(request);
    }

    @PostMapping("/user/update")
    public Result update(@Validated({UpdateGroup.class, DefaultGroup.class}) @RequestBody SysUserRequest request) {
        return sysUserService.update(request);
    }

    @PostMapping("/user/delete")
    public Result delete(@RequestBody SysUserRequest sysUserRequest) {
        return sysUserService.delete(sysUserRequest);
    }

    @PostMapping("/user/getByUserName")
    public Result<SysUser> getByUserName(@RequestBody SysUserRequest request) {
        return sysUserService.getByUsername(request);
    }

    @PostMapping("/user/list")
    public Result<List<SysUserResponse>> list(@RequestBody SysUserRequest request){
        return sysUserService.list(request);
    }
}
