package com.github.admin.server.controller;

import com.github.admin.common.entity.SysUserToken;
import com.github.admin.server.service.SysUserTokenService;
import com.github.framework.core.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 用户管理
 */
@RestController
public class SysUserTokenController {

    @Resource
    private SysUserTokenService sysUserTokenService;

    @GetMapping("/token/getByToken")
    public Result<SysUserToken> getByToken(@RequestParam("token") String token) {
        return sysUserTokenService.getByToken(token);
    }

    @GetMapping("/token/createToken/{id}")
    public Result createToken(@PathVariable("id") Long id) {
        return sysUserTokenService.createToken(id);
    }

    @GetMapping("/token/logout/{id}")
    public void logout(@PathVariable("id") Long id){
        sysUserTokenService.logout(id);
    }
}
