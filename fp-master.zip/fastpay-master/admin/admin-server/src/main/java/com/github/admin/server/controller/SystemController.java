package com.github.admin.server.controller;

import com.github.admin.common.dto.SysSystem;
import com.github.admin.server.service.SystemService;
import com.github.framework.core.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 系统接口
 */
@RestController
public class SystemController {

    @Resource
    private SystemService systemService;

    @GetMapping("/system/info")
    public Result<SysSystem> info() {
        return systemService.getSystem();
    }

}
