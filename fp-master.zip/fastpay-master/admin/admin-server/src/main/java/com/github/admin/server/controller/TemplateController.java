package com.github.admin.server.controller;

import com.github.admin.common.entity.GenTemplate;
import com.github.admin.common.request.GenTemplateRequest;
import com.github.admin.server.service.GenTemplateService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

@RestController
public class TemplateController {

    @Resource
    private GenTemplateService genTemplateService;

    @PostMapping("/template/page")
    public Result<DataPage<GenTemplate>> page(@RequestBody GenTemplateRequest request) {
        return genTemplateService.page(request);
    }

    @GetMapping("/template/getById/{id}")
    public Result<GenTemplate> get(@PathVariable("id") Long id) {
        return genTemplateService.findById(id);
    }

    @PostMapping("/template/save")
    public Result save(@RequestBody GenTemplateRequest entity) {
        return genTemplateService.save(entity);
    }

    @PostMapping("/template/update")
    public Result update(@RequestBody GenTemplateRequest entity) {
        return genTemplateService.update(entity);
    }

    @PostMapping("/template/delete")
    public Result delete(@RequestBody List<Long> ids) {
        return genTemplateService.deleteIds(ids);
    }

    /**
     * 启用
     */
    @PostMapping("/template/updateStatusBatchEnabled")
    public Result enabled(@RequestBody List<Long> ids) {
        GenTemplateRequest genTemplateRequest = new GenTemplateRequest();
        genTemplateRequest.setIds(ids);
        genTemplateRequest.setStatus(0);
        return genTemplateService.updateStatusBatch(genTemplateRequest);
    }

    /**
     * 禁用
     */
    @PostMapping("/template/updateStatusBatchDisabled")
    public Result disabled(@RequestBody List<Long> ids) {
        GenTemplateRequest genTemplateRequest = new GenTemplateRequest();
        genTemplateRequest.setIds(ids);
        genTemplateRequest.setStatus(1);
        return genTemplateService.updateStatusBatch(genTemplateRequest);
    }
}
