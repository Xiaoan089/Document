package com.github.admin.server.dao;

import com.github.admin.common.entity.GenBaseClass;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface GenBaseClassDao {

    int deleteByPrimaryKey(Long id);

    int insertSelective(GenBaseClass row);

    GenBaseClass selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(GenBaseClass row);

    Integer findDictTypeCountByPage(Map<String, Object> map);

    List<GenBaseClass> findDictTypeListByPage(Map<String, Object> map);

    List<GenBaseClass> selectBySelective(GenBaseClass genBaseClass);

    int deleteByIds(@Param("ids") List<Long> ids);
}
