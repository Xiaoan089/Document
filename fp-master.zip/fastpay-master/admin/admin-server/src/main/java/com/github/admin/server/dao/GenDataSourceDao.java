package com.github.admin.server.dao;

import com.github.admin.common.entity.GenDataSource;
import com.github.admin.common.request.GenDataSourceRequest;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface GenDataSourceDao {

    int deleteByPrimaryKey(Long id);

    int insertSelective(GenDataSource row);

    GenDataSource selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(GenDataSource row);

    long findDataSourceCountByPage(Map<String, Object> map);

    List<GenDataSource> findDataSourceListByPage(Map<String, Object> map);


    List<GenDataSource> selectBySelective(GenDataSourceRequest request);

    int deleteByIds(@Param("ids") List<Long> ids);
}
