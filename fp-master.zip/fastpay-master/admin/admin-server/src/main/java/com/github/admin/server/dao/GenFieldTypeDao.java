package com.github.admin.server.dao;

import com.github.admin.common.entity.GenFieldType;
import com.github.admin.common.request.GenFieldTypeRequest;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface GenFieldTypeDao {


    int deleteByPrimaryKey(Long id);

    int insertSelective(GenFieldType row);

    GenFieldType selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(GenFieldType row);

    /**
     * 根据tableId，获取包列表
     */
    Set<String> getPackageListByTableId(Long tableId);

    long findFieldTypeCountByPage(Map<String, Object> map);

    List<GenFieldType> findFieldTypeListByPage(Map<String, Object> map);

    /**
     * 获取全部字段类型
     */
    Set<String> findAllAttrType();

    int deleteByIds(@Param("ids") List<Long> ids);

    List<GenFieldType> selectBySelective(GenFieldTypeRequest request);
}
