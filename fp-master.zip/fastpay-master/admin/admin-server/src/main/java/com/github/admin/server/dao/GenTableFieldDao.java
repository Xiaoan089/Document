package com.github.admin.server.dao;
import com.github.admin.common.entity.GenTableField;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface GenTableFieldDao {

    int deleteByPrimaryKey(Long id);

    int insertSelective(GenTableField row);

    GenTableField selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(GenTableField row);

    List<GenTableField> getByTableName(String tableName);

    int deleteByTableName(String tableName);

    int deleteByTableIds(@Param("tableIds") List<Long> tableIds);

    int saveBatch(@Param("entityList") List<GenTableField> tableFieldList);
}
