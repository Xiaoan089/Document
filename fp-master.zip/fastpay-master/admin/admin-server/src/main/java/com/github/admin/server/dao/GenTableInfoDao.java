package com.github.admin.server.dao;

import com.github.admin.common.entity.GenTableInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


public interface GenTableInfoDao {

    int deleteByPrimaryKey(Long id);

    int insertSelective(GenTableInfo row);

    GenTableInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(GenTableInfo row);

    GenTableInfo getByTableName(String tableName);

    int deleteByTableName(String tableName);

    long findTableInfoCountByPage(Map<String, Object> map);

    List<GenTableInfo> findTableInfoListByPage(Map<String, Object> map);

    int deleteByIds(@Param("ids") List<Long> ids);
}
