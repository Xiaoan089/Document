package com.github.admin.server.dao;

import com.github.admin.common.entity.GenTemplate;
import com.github.admin.common.request.GenTemplateRequest;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface GenTemplateDao {

    GenTemplate selectByPrimaryKey(Long id);

    int deleteByPrimaryKey(Long id);

    int insertSelective(GenTemplate row);

    int updateByPrimaryKeySelective(GenTemplate row);

    int deleteByIds(@Param("ids") List<Long> ids);

    int updateStatusBatch(GenTemplate genTemplate);


    long findTemplateCountByPage(Map<String, Object> map);

    List<GenTemplate> findTemplateListByPage(Map<String, Object> map);

    List<GenTemplate> selectBySelective(GenTemplateRequest request);
}
