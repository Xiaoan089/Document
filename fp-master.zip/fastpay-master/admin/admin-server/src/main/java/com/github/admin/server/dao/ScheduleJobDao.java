package com.github.admin.server.dao;

import com.github.admin.common.entity.ScheduleJob;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


public interface ScheduleJobDao {

	/**
	 * 批量更新状态
	 */
	int updateBatch(Map<String, Object> map);

	long findScheduleJobCountByPage(Map<String, Object> map);

	List<ScheduleJob> findScheduleJobListByPage(Map<String, Object> map);

	int deleteByPrimaryKey(Long id);

	int insertSelective(ScheduleJob row);

	ScheduleJob selectByPrimaryKey(Long id);

	int updateByPrimaryKeySelective(ScheduleJob row);

	int deleteByIds(@Param("ids") List<Long> ids);
}
