package com.github.admin.server.dao;


import com.github.admin.common.entity.ScheduleJobLog;

import java.util.List;
import java.util.Map;


public interface ScheduleJobLogDao {

    long findUserCountByPage(Map<String, Object> map);
    List<ScheduleJobLog> findUserListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(ScheduleJobLog row);

    ScheduleJobLog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ScheduleJobLog row);

}
