package com.github.admin.server.dao;
import com.github.admin.common.entity.SysDept;
import com.github.admin.common.request.SysDeptRequest;

import java.util.List;

public interface SysDeptDao{

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysDept row);

    SysDept selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysDept row);

    List<SysDept> getList(SysDept sysDept);

    SysDept getById(Long id);

    /**
     * 获取所有部门的id、pid列表
     */
    List<SysDept> getIdAndPidList();

    /**
     * 根据部门ID，获取所有子部门ID列表
     * @param id   部门ID
     */
    List<Long> getSubDeptIdList(String id);

    List<SysDept> selectBySelective(SysDeptRequest request);

    int deleteByIdOnType(SysDept sysDept);
}
