package com.github.admin.server.dao;
import com.github.admin.common.entity.SysDictData;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SysDictDataDao {

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysDictData row);

    SysDictData selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysDictData row);

    /**
     * 字典数据列表
     */
    List<SysDictData> getDictDataList();

    long findSysDictCountByPage(Map<String, Object> map);

    List<SysDictData> findSysDictListByPage(Map<String, Object> map);

    int deleteByDictTypeIds(@Param("dictTypeIds") List<Long> dictTypeIds);

    int deleteByIds(@Param("ids") List<Long> ids);
}
