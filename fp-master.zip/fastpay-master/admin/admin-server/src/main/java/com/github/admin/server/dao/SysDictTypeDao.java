package com.github.admin.server.dao;
import com.github.admin.common.entity.SysDictType;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


public interface SysDictTypeDao {

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysDictType row);

    SysDictType selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysDictType row);

    /**
     * 字典类型列表
     */
    List<SysDictType> getDictTypeList();

    long findSysDictTypeCountByPage(Map<String, Object> map);

    List<SysDictType> findSysDictTypeListByPage(Map<String, Object> map);

    int deleteByIds(@Param("ids") List<Long> ids);
}
