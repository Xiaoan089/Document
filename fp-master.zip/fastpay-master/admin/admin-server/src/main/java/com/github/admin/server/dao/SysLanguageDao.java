package com.github.admin.server.dao;
import com.github.admin.common.entity.SysLanguage;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 国际化
 */

public interface SysLanguageDao {

    int insert(SysLanguage row);

    int insertSelective(SysLanguage row);

    int updateByPrimaryKeySelective(SysLanguage row);

    SysLanguage getLanguage(SysLanguage entity);

    void updateLanguage(SysLanguage entity);

    /**
     * 删除国际化
     * @param tableName   表名
     * @param tableId     表主键
     */
    void deleteLanguage(@Param("tableName") String tableName, @Param("tableId") Long tableId);
}
