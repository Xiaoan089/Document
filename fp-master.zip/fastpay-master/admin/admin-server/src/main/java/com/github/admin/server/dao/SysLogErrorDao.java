package com.github.admin.server.dao;
import com.github.admin.common.entity.SysLogError;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 异常日志
 */

public interface SysLogErrorDao {

    Integer findSysLogErrorCountByPage(Map<String, Object> map);

    List<SysLogError> findSysLogErrorListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysLogError row);

    SysLogError selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysLogError row);
    List<SysLogError> selectList();


}
