package com.github.admin.server.dao;
import com.github.admin.common.entity.SysLogLogin;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 登录日志
 */

public interface SysLogLoginDao {

    Integer findSysLogLoginCountByPage(Map<String, Object> map);

    List<SysLogLogin> findSysLogLoginListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysLogLogin entity);

    SysLogLogin selectByPrimaryKey(Long id);
    List<SysLogLogin> selectByMap(Map<String, Object> map);

    int updateByPrimaryKeySelective(SysLogLogin entity);



}
