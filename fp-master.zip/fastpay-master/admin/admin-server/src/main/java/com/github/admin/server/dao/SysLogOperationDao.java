package com.github.admin.server.dao;
import com.github.admin.common.entity.SysLogOperation;
import com.github.admin.common.request.SysLogOperationRequest;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 操作日志
 *
 */

public interface SysLogOperationDao {

    Integer findSysLogOperationCountByPage(Map<String, Object> map);

    List<SysLogOperation> findSysLogOperationListByPage(Map<String, Object> map);
    List<SysLogOperation> selectListBySelective(SysLogOperationRequest request);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysLogOperation row);

    SysLogOperation selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysLogOperation row);

}
