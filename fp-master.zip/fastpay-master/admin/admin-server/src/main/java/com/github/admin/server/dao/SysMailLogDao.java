package com.github.admin.server.dao;
import com.github.admin.common.entity.SysMailLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 邮件发送记录
 */

public interface SysMailLogDao {

    Integer findSysMailLogCountByPage(Map<String, Object> map);

    List<SysMailLog> findSysMailLogListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysMailLog row);

    SysMailLog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysMailLog row);

    int deleteByIds(@Param("ids") List<Long> ids);

}
