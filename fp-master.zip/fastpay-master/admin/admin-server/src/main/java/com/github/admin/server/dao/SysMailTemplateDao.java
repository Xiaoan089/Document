package com.github.admin.server.dao;
import com.github.admin.common.entity.SysMailTemplate;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 邮件模板
 */

public interface SysMailTemplateDao {

    Integer findSysMailTemplateCountByPage(Map<String, Object> map);


    List<SysMailTemplate> findSysMailTemplateListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysMailTemplate row);

    SysMailTemplate selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysMailTemplate row);

    int deleteByIds(@Param("ids") List<Long> ids);

}
