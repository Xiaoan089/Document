package com.github.admin.server.dao;
import com.github.admin.common.entity.SysMenu;
import com.github.admin.common.request.SysMenuRequest;
import com.github.admin.common.entity.UserDetail;

import java.util.List;

public interface SysMenuDao {

	SysMenu getById(SysMenu sysMenu);

	/**
	 * 查询所有菜单列表
	 *
	 * @param menuType 菜单类型
	 * @param language 语言
	 */
	List<SysMenu> getMenuListBySysType(SysMenuRequest menuType);


	List<SysMenu> getMenuList(SysMenu sysMenu);

	/**
	 * 查询用户菜单列表
	 *
	 * @param userId 用户ＩＤ
	 * @param menuType 菜单类型
	 * @param language 语言
	 */
	List<SysMenu> getUserMenuList(SysMenu sysMenu);

	/**
	 * 查询用户权限列表
	 * @param userId  用户ID
	 */
	List<String> getUserPermissionsList(UserDetail user);

	/**
	 * 查询所有权限列表
	 */
	List<String> getPermissionsList(UserDetail user);

	/**
	 * 根据父菜单，查询子菜单
	 * @param pid  父菜单ID
	 */
	List<SysMenu> getListPid(Long pid);

    int deleteBySelective(SysMenuRequest request);

	int deleteByPrimaryKey(Long id);

	int insertSelective(SysMenu row);

	SysMenu selectByPrimaryKey(Long id);

	int updateByPrimaryKeySelective(SysMenu row);

}
