package com.github.admin.server.dao;


import com.github.admin.common.entity.SysNotice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
* 通知管理
*/

public interface SysNoticeDao {
    /**
     * 获取被通知的用户列表
     */
    List<SysNotice> getNoticeUserList(Map<String, Object> params);

    /**
     * 获取我的通知列表
     */
    List<SysNotice> getMyNoticeList(Map<String, Object> params);

    long findMyNoticeCountByPage(Map<String, Object> map);

    List<SysNotice> findMyNoticeListByPage(Map<String, Object> map);

    long findNoticeCountByPage(Map<String, Object> map);

    List<SysNotice> findNoticeListByPage(Map<String, Object> map);

    long findNoticeUserCountByPage(Map<String, Object> map);

    List<SysNotice> findNoticeUserListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysNotice row);

    SysNotice selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysNotice row);

    int deleteByIds(@Param("ids") List<Long> ids);

}
