package com.github.admin.server.dao;

import com.github.admin.common.entity.SysNoticeUser;


/**
* 我的通知
*/
public interface SysNoticeUserDao {
    /**
     * 通知全部用户
     */
	int insertAllUser(SysNoticeUser entity);

    /**
     * 未读的通知数
     * @param receiverId  接收者ID
     */
    int getUnReadNoticeCount(Long receiverId);

    int deleteByPrimaryKey(SysNoticeUser key);

    int insertSelective(SysNoticeUser row);

    SysNoticeUser selectByPrimaryKey(SysNoticeUser key);
    int updateBySelective(SysNoticeUser row);

}
