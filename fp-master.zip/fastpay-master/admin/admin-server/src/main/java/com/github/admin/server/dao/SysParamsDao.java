package com.github.admin.server.dao;

import com.github.admin.common.entity.SysParams;
import com.github.trans.front.common.request.SysParamsRequest;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SysParamsDao {

    SysParams findByParamsCode(String paramCode);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysParams row);

    SysParams selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysParams row);

    long findParamsCountByPage(Map<String, Object> map);

    List<SysParams> findParamsListByPage(Map<String, Object> map);

    /**
     * 获取参数编码列表
     * @param ids  ids
     * @return 返回参数编码列表
     */
    List<SysParams> getParamCodeList(@Param("ids") List<Long> ids);

    int deleteByIds(@Param("ids") List<Long> ids);

    List<SysParams> selectListBySelective(SysParamsRequest sysParamsRequest);

    String getValueByCode(String paramCode);

    int updateValueByCode(SysParams sysParams);
}
