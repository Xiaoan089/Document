package com.github.admin.server.dao;


import com.github.admin.common.entity.SysPost;
import com.github.admin.common.request.SysPostRequest;

import java.util.List;
import java.util.Map;

public interface SysPostDao {
    int deleteByPrimaryKey(Long id);

    int insertSelective(SysPost row);

    SysPost selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysPost row);

    long findPostCountByPage(Map<String, Object> map);

    List<SysPost> findPostListByPage(Map<String, Object> map);

    List<SysPost> selectListSelective(SysPost sysPost);

    int deleteBatchIds(SysPostRequest sysPostRequest);
}
