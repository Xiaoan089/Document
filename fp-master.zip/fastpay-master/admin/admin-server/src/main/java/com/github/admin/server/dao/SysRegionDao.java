package com.github.admin.server.dao;
import com.github.admin.common.entity.SysRegion;
import com.github.admin.common.request.SysRegionRequest;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 行政区域
 *
 */

public interface SysRegionDao {

	List<SysRegion> getList(SysRegionRequest request);

	List<SysRegion> getListByLevel(Integer treeLevel);

	List<Map<String, Object>> getTreeList();

	SysRegion getById(Long id);

	int getCountByPid(Long pid);

	int deleteById(Long id);

	int deleteByPrimaryKey(Long id);

	int insertSelective(SysRegion row);

	SysRegion selectByPrimaryKey(Long id);

	int updateByPrimaryKeySelective(SysRegion row);

}
