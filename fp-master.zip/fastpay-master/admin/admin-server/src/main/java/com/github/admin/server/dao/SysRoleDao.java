package com.github.admin.server.dao;
import com.github.admin.common.entity.SysRole;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 角色管理
 */

public interface SysRoleDao {


    long findRoleCountByPage(Map<String, Object> map);

    List<SysRole> findRoleListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysRole row);

    SysRole selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysRole row);

    List<SysRole> selectBySelective(SysRole sysRole);

    int deleteByIdOnType(SysRole sysRole);
}
