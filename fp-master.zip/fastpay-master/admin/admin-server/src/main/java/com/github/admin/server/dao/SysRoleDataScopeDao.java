package com.github.admin.server.dao;
import com.github.admin.common.entity.SysRoleDataScope;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SysRoleDataScopeDao {

    /**
     * 根据角色ID，获取部门ID列表
     */
    List<Long> getDeptIdList(Long roleId);

    /**
     * 获取用户的部门数据权限列表
     */
    List<Long> getDataScopeList(Long userId);

    /**
     * 根据角色id，删除角色数据权限关系
     * @param roleIds 角色ids
     */
    int deleteByRoleIds(@Param("roleIds")List<Long> roleIds);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysRoleDataScope row);

    SysRoleDataScope selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysRoleDataScope row);

}
