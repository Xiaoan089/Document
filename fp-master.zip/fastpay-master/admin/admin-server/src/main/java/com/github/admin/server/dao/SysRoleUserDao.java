package com.github.admin.server.dao;
import com.github.admin.common.entity.SysRoleUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 角色用户关系
 * @since 1.0.0
 */

public interface SysRoleUserDao {

    /**
     * 根据角色ids，删除角色用户关系
     * @param roleIds 角色ids
     */
    int deleteByRoleIds(@Param("roleIds") List<Long> roleIds);

    /**
     * 根据用户id，删除角色用户关系
     * @param userIds 用户ids
     */
    int deleteByUserIds(@Param("userIds") List<Long> userIds);

    /**
     * 角色ID列表
     * @param userId  用户ID
     *
     * @return
     */
    List<Long> getRoleIdList(Long userId);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysRoleUser row);

    SysRoleUser selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysRoleUser row);

}
