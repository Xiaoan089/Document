package com.github.admin.server.dao;
import com.github.admin.common.entity.SysSms;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


public interface SysSmsDao {

    Integer findSysSmsCountByPage(Map<String, Object> map);


    List<SysSms> findSysSmsListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysSms row);

    SysSms selectByPrimaryKey(Long id);

    SysSms selectBySmsCode(String sysCode);

    int updateByPrimaryKeySelective(SysSms row);

    int deleteByIds(@Param("ids") List<Long> ids);

}
