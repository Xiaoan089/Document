package com.github.admin.server.dao;
import com.github.admin.common.entity.SysSmsLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 短信日志
 */

public interface SysSmsLogDao {

    Integer findSysSmsLogCountByPage(Map<String, Object> map);


    List<SysSmsLog> findSysSmsLogListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysSmsLog row);

    SysSmsLog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysSmsLog row);

    int deleteByIds(@Param("ids") List<Long> ids);


}
