package com.github.admin.server.dao;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.request.SysUserRequest;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SysUserDao {

	int deleteByPrimaryKey(Long id);

	int insertSelective(SysUser row);

	SysUser selectByPrimaryKey(Long id);

	int updateByPrimaryKeySelective(SysUser row);

	List<SysUser> getList(Map<String, Object> params);

	SysUser getById(Long id);

	SysUser getByUsername(SysUserRequest request);

	int updatePassword(@Param("id") Long id, @Param("newPassword") String newPassword);

	/**
	 * 根据部门ID，查询用户数
	 */
	int getCountByDeptId(Long deptId);

	/**
	 * 根据部门ID,查询用户ID列表
	 */
	List<Long> getUserIdListByDeptId(List<Long> deptIdList);

    long findUserCountByPage(Map<String, Object> map);

	List<SysUser> findUserListByPage(Map<String, Object> map);

	SysUser findByIdOnType(SysUserRequest request);

	int deleteByIds(@Param("ids") List<Long> ids);

    int updateBySelective(SysUser user);

    SysUser selectByUsername(SysUser sysUser);

}
