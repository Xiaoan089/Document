package com.github.admin.server.dao;
import com.github.admin.common.entity.SysUserPost;
import com.github.admin.common.request.SysPostRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
* 用户岗位关系
*
* @author Mark sunlightcs@gmail.com
*/

public interface SysUserPostDao {

    /**
     * 根据岗位ids，删除岗位用户关系
     * @param postIds 岗位ids
     */
    int deleteByPostIds(@Param("postIds") List<Long> postIds);

    /**
     * 根据用户id，删除岗位用户关系
     * @param userIds 用户ids
     */
    int deleteByUserIds(@Param("userIds") List<Long> userIds);

    /**
     * 岗位ID列表
     * @param userId  用户ID
     */
    List<Long> getPostIdList(Long userId);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysUserPost row);

    SysUserPost selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysUserPost row);

}
