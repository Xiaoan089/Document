package com.github.admin.server.dao;
import com.github.admin.common.entity.SysOnlineEntity;
import com.github.admin.common.entity.SysUserToken;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;


public interface SysUserTokenDao {

    SysUserToken getByToken(String token);

    SysUserToken getByUserId(Long userId);

    void logout(@Param("userId") Long userId, @Param("expireDate") Date expireDate);

    /**
     * 获取在线用户列表
     */
    List<SysOnlineEntity> getOnlineList(Map<String, Object> params);

    Integer findSysOnlineCountByPage(Map<String, Object> map);

    List<SysOnlineEntity> findSysOnlineListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(SysUserToken row);

    SysUserToken selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SysUserToken row);

    int deleteBySelective(SysUserToken sysUserToken);

}
