package com.github.admin.server.dao;

import com.github.admin.common.entity.TbExcelData;
import com.github.admin.common.request.ExcelDataRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
* Excel导入演示
*/

public interface TbExcelDataDao {

    Integer findTbExcelDataCountByPage(Map<String, Object> map);

    List<TbExcelData> findTbExcelDataListByPage(Map<String, Object> map);

    int delete(@Param("ids") List<Long> ids);
    List<TbExcelData> selectListBySelective(ExcelDataRequest request);

    int deleteByPrimaryKey(Long id);

    int insertSelective(TbExcelData row);

    TbExcelData selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TbExcelData row);

}
