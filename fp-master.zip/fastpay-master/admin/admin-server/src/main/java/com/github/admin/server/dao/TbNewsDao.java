package com.github.admin.server.dao;

import com.github.admin.common.entity.TbNews;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 新闻
 */

public interface TbNewsDao {

    List<TbNews> getList(Map<String, Object> params);

    long findTbNewsCountByPage(Map<String, Object> map);

    List<TbNews> findTbNewsListByPage(Map<String, Object> map);

    int deleteByPrimaryKey(Long id);

    int insertSelective(TbNews row);

    TbNews selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TbNews row);

    int deleteByIds(@Param("ids") List<Long> ids);

}
