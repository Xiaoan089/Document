package com.github.admin.server.dao;

import com.github.admin.common.entity.TbProduct;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 产品管理
 */

public interface TbProductDao {

    Integer findTbProductCountByPage(Map<String, Object> map);


    List<TbProduct> findTbProductListByPage(Map<String, Object> map);

    int delete(@Param("ids") List<Long> ids);

    int deleteByPrimaryKey(Long id);

    int insertSelective(TbProduct row);

    TbProduct selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TbProduct row);


}
