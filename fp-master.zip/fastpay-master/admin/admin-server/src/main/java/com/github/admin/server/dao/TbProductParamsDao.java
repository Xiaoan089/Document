package com.github.admin.server.dao;

import com.github.admin.common.entity.TbProductParams;
import com.github.admin.common.request.TbProductParamsRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface TbProductParamsDao {

    /**
     * 根据产品id，删除产品参数
     */
    int deleteByProductIds(@Param("productIds") List<Long> productIds);

    int deleteByPrimaryKey(Long id);

    int insertSelective(TbProductParams row);

    TbProductParams selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TbProductParams row);


    List<TbProductParams> selectBySelective(TbProductParams tbProductParams);
}
