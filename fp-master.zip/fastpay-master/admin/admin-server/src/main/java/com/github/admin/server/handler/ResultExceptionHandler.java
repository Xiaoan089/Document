package com.github.admin.server.handler;


import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.framework.core.Result;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolationException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

@ControllerAdvice
@Slf4j
public class ResultExceptionHandler {


    /** 拦截表单验证异常 */
    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Result bindException(BindException ex){
        BindingResult bindingResult = ex.getBindingResult();
        String message = Objects.requireNonNull(bindingResult.getFieldError()).getDefaultMessage();
        log.error("bindException表单验证异常信息,message = {}",message);
        return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_ERROR.getCode(),message);
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Result handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        BindingResult result = ex.getBindingResult();
        StringBuilder errorMessage = new StringBuilder();
        result.getFieldErrors().forEach(fieldError -> {
            errorMessage.append(fieldError.getField()).append(": ").append(fieldError.getDefaultMessage()).append("; ");
        });
        String code = Objects.requireNonNull(result.getFieldError()).getDefaultMessage();
        return Result.fail(code);
    }

    @ExceptionHandler({ConstraintViolationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Result handleConstraintViolationException(ConstraintViolationException ex) {
        log.error("handleConstraintViolationException表单验证异常信息:",ex);
        return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_ERROR);
    }


    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Result handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException ex) {
        log.error("HttpRequestMethodNotSupportedException请求方式不支持:",ex);
        return Result.fail(AdminErrorMsgEnum.METHOD_NOT_ALLOWED);
    }


    @ExceptionHandler({HttpMessageNotReadableException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Result handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
        log.error("HttpMessageNotReadableException请求数据格式错误:",ex);
        return Result.fail(AdminErrorMsgEnum.HTTP_MESSAGE_NOT_READABLE);
    }


    @ExceptionHandler({HttpMediaTypeNotSupportedException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public Result handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException ex) {
        log.error("HttpMediaTypeNotSupportedException请求方式不支持:",ex);
        return Result.fail(AdminErrorMsgEnum.METHOD_NOT_ALLOWED);
    }

    @ExceptionHandler(FeignException.class)
    public ResponseEntity handleValidationExceptions(FeignException ex) {
        log.error("调用远程服务异常:",ex);
        if (ex.status() == HttpStatus.BAD_REQUEST.value()) {
            ByteBuffer byteBuffer = ex.responseBody().get();
            byte[] bytes = new byte[byteBuffer.remaining()];
            byteBuffer.get(bytes);
            String responseBody = new String(bytes, StandardCharsets.UTF_8);
            // 解析 responseBody 获取字段和错误消息
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseBody);
        }
        Result result = Result.fail(AdminErrorMsgEnum.INVOKE_REMOTE_SERVICE_EXCEPTION);
        // 处理其他类型的 FeignException 异常
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(result);
    }

    /** 拦截未知的运行时异常 */
    @ExceptionHandler(RuntimeException.class)
    @ResponseBody
    public Result runtimeException(RuntimeException ex) {
        log.error("runtimeException运行异常信息:",ex);
        return Result.fail(AdminErrorMsgEnum.SYSTEM_EXCEPTION);
    }

    /**
     * 默认全局异常处理。
     * @param ex the ex
     * @return ResultData
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public Result exception(Exception ex) {
        log.error("exception全局异常信息:",ex);
        return Result.fail(AdminErrorMsgEnum.SYSTEM_EXCEPTION);
    }


}
