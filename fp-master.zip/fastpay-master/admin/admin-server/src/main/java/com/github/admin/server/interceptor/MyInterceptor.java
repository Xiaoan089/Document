/*
 */
package com.github.admin.server.interceptor;

import com.github.framework.core.entity.BaseEntity;
import com.github.trans.front.common.constants.TransConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.defaults.DefaultSqlSession;

import java.util.*;

/**
 * @ClassName IdInjectInterceptor
 * @Description 基于IDGen注释给新增或者update的对象注入id值
 */
@Slf4j
@Intercepts({@Signature(type = Executor.class, method = "update", args = {MappedStatement.class, Object.class})})
public class MyInterceptor implements Interceptor {

    private Properties properties;


    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object[] args = invocation.getArgs();
        MappedStatement ms = (MappedStatement) args[0];
        Object object = args[1];
        boolean isInsertInjectId = ms.getSqlCommandType() == SqlCommandType.INSERT;
        boolean isUpdateInjectId = ms.getSqlCommandType() == SqlCommandType.UPDATE;
        if(isInsertInjectId){
            insertInject(object);
        }
        if(isUpdateInjectId){
            updateInject(object);
        }

        return invocation.proceed();
    }

    public void insertInject(Object object) {
        if (object instanceof BaseEntity) {
            BaseEntity entity = (BaseEntity) object;
            Date date = new Date();

            if(entity.getCreateDate() == null){
                entity.setCreateDate(date);
            }
            if(entity.getUpdateDate() == null){
                entity.setUpdateDate(date);
            }
            if(StringUtils.isBlank(entity.getRemark())){
                entity.setRemark(TransConstants.BLANK_INIT);
            }
        }
        if (object instanceof Collection) {
            for (Iterator iter = ((Collection) object).iterator(); iter.hasNext(); ) {
                insertInject(iter.next());
            }
        }
        if (object instanceof DefaultSqlSession.StrictMap) {
            DefaultSqlSession.StrictMap map = (DefaultSqlSession.StrictMap) object;
            List list = (List) map.get("list");
            insertInject(list);
        }
    }

    public void updateInject(Object object) {
        if (object instanceof BaseEntity) {
            BaseEntity entity = (BaseEntity) object;
            Date date = new Date();
            if(entity.getUpdateDate() == null){
                entity.setUpdateDate(date);
            }
        }
        if (object instanceof Collection) {
            for (Iterator iter = ((Collection) object).iterator(); iter.hasNext(); ) {
                updateInject(iter.next());
            }
        }
        if (object instanceof DefaultSqlSession.StrictMap) {
            DefaultSqlSession.StrictMap map = (DefaultSqlSession.StrictMap) object;
            List list = (List) map.get("list");
            updateInject(list);
        }
    }


    @Override
    public Object plugin(Object o) {
        return Plugin.wrap(o, this);
    }

    @Override
    public void setProperties(Properties properties) {
        this.properties = properties;
    }

}
