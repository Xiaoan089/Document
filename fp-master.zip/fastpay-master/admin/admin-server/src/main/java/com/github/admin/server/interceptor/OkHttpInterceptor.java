package com.github.admin.server.interceptor;


import com.github.admin.common.utils.HttpContextUtils;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.io.IOException;


@Component
@Slf4j
public class OkHttpInterceptor implements Interceptor{
    @Override
    public Response intercept(Chain chain) throws IOException {
        String language = HttpContextUtils.getLanguage();
        if (StringUtils.isEmpty(language)) {
            language = LocaleContextHolder.getLocale().toLanguageTag();
        }
        Request newRequest = chain.request()
                .newBuilder()
                .header(HttpHeaders.ACCEPT_LANGUAGE,language)
                .build();

        Response response = chain.proceed(newRequest);

        return response;
    }
}
