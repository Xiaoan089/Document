package com.github.admin.server.mq.base;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.github.admin.server.mq.producer.impl.MqProducerFailProducer;
import com.github.admin.server.utils.MqDelayTimeUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.trans.front.common.assembly.MqSendFailAssembly;
import com.github.trans.front.common.assembly.MqSendFailMessageAssembly;
import com.github.trans.front.common.constants.RocketMqConstants;
import com.github.trans.front.common.constants.TransConstants;
import com.github.trans.front.common.entity.MqSendFail;
import com.github.trans.front.common.enums.PaymentErrorMsgEnums;
import com.github.trans.front.common.message.BasePaymentMessage;
import com.github.trans.front.common.message.MqSendFailMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.client.producer.SendStatus;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.spring.core.RocketMQTemplate;

import javax.annotation.Resource;

@Slf4j
public abstract class BasePaymentProducer<T extends BasePaymentMessage> {

    @Resource
    protected RocketMQTemplate rocketMQTemplate;

    @Resource
    protected MqProducerFailProducer mqProducerFailProducer;


    protected Result process(T message) {
        String groupName = getGroupName();
        String topicName = getTopicName();
        message.setGroupName(getGroupName());
        message.setTopName(getTopicName());
        String bizType = TransConstants.BLANK_INIT;
        MqSendFail mqSendFail = MqSendFailAssembly.buildInit(JSON.toJSONString(message));
        try {
            Result result = checkParams(message);
            if (!result.isSuccess()) {
                log.error("发送MQ消息请求参数校验失败:message = {},result = {}", message, result);
                throw Ex.business(result.getCode(), result.getMessage(), result.getErrorDetail());
            }
            bizType = message.getBizType();
            mqSendFail.setGroupName(groupName);
            mqSendFail.setTopicName(topicName);
            mqSendFail.setBizType(bizType);
            return invoke(message);
        } catch (Exception e) {
            String msg = String.format("生产者发送异常,分组:group = %s,主题:topic = %s,消息内容:message = %s,异常信息:exception =",groupName,topicName,message,e.getMessage());
            log.error(msg,e);
            MqSendFailMessage mqSendFailMessage = MqSendFailMessageAssembly.buildInit(mqSendFail,JSONObject.toJSONString(e),bizType);
            Result result = mqProducerFailProducer.sendMessage(mqSendFailMessage);
            if (!result.isSuccess()) {
                log.error("消息发送失败,插入数据库失败,mqSendFail = {},result = {}", mqSendFail, result);
            }
            return Result.fail(PaymentErrorMsgEnums.MQ_MESSAGE_SEND_ERROR);
        }
    }


    protected Result sendMessage(Message message) throws Exception {

        DefaultMQProducer defaultMQProducer = rocketMQTemplate.getProducer();
        defaultMQProducer.setMqClientApiTimeout(RocketMqConstants.ROCKET_PRODUCE_TIME_OUT);
        SendResult sendResult = defaultMQProducer.send(message);

        String groupName = message.getKeys();
        String topName = message.getTopic();
        int delayTimeLevel = message.getDelayTimeLevel();
        String messageBody = new String(message.getBody());
        log.info("MQ发送数据:groupName = {},topName = {},消息内容:messageBody = {},delayTimeLevel = {}", groupName, topName, messageBody, delayTimeLevel);
        if (sendResult.getSendStatus() == SendStatus.SEND_OK) {
            log.info("MQ发送数据成功:groupName = {},topName = {},消息内容:messageBody = {},delayTimeLevel = {}", groupName, topName, messageBody, delayTimeLevel);
            return Result.ok();
        }
        log.info("MQ发送数据失败:groupName = {},topName = {},消息内容:messageBody = {},delayTimeLevel = {}", groupName, topName, messageBody, delayTimeLevel);
        throw Ex.business(PaymentErrorMsgEnums.MQ_MESSAGE_SEND_ERROR);
    }

    protected Result sendLevelOneDelayMessage(Message message) throws Exception {
        Long delaySecondTime = MqDelayTimeUtils.getDelayLevelOneSecondTime();
        message.setDelayTimeSec(delaySecondTime);
        DefaultMQProducer defaultMQProducer = rocketMQTemplate.getProducer();
        defaultMQProducer.setMqClientApiTimeout(RocketMqConstants.ROCKET_PRODUCE_TIME_OUT);
        SendResult sendResult = defaultMQProducer.send(message);
        String groupName = message.getKeys();
        String topName = message.getTopic();
        String messageBody = new String(message.getBody());
        log.info("MQ发送一级消息数据:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
        if (sendResult.getSendStatus() == SendStatus.SEND_OK) {
            log.info("MQ发送一级延迟消息成功:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
            return Result.ok();
        }
        log.info("MQ发送一级延迟消息据失败:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
        throw Ex.business(PaymentErrorMsgEnums.MQ_MESSAGE_SEND_ERROR);
    }

    protected Result sendLevelThreeDelayMessage(Message message) throws Exception {
        Long delaySecondTime = MqDelayTimeUtils.getDelayLevelThreeSecondTime();
        message.setDelayTimeSec(delaySecondTime);
        DefaultMQProducer defaultMQProducer = rocketMQTemplate.getProducer();
        defaultMQProducer.setMqClientApiTimeout(RocketMqConstants.ROCKET_PRODUCE_TIME_OUT);
        SendResult sendResult = defaultMQProducer.send(message);

        String groupName = message.getKeys();
        String topName = message.getTopic();
        String messageBody = new String(message.getBody());
        log.info("MQ发送二级延迟消息数据:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
        if (sendResult.getSendStatus() == SendStatus.SEND_OK) {
            log.info("MQ发送二级延迟消息成功:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
            return Result.ok();
        }
        log.info("MQ发送二级延迟消息据失败:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
        throw Ex.business(PaymentErrorMsgEnums.MQ_MESSAGE_SEND_ERROR);
    }

    protected Result sendLevelTwoDelayMessage(Message message) throws Exception {
        Long delaySecondTime = MqDelayTimeUtils.getDelayLevelTwoSecondTime();
        message.setDelayTimeSec(delaySecondTime);
        DefaultMQProducer defaultMQProducer = rocketMQTemplate.getProducer();
        defaultMQProducer.setMqClientApiTimeout(RocketMqConstants.ROCKET_PRODUCE_TIME_OUT);
        SendResult sendResult = defaultMQProducer.send(message);

        String groupName = message.getKeys();
        String topName = message.getTopic();
        String messageBody = new String(message.getBody());
        log.info("MQ发送渠道回调延迟消息数据:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
        if (sendResult.getSendStatus() == SendStatus.SEND_OK) {
            log.info("MQ发送渠道回调延迟消息成功:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
            return Result.ok();
        }
        log.info("MQ发送渠道回调延迟消息据失败:groupName = {},topName = {},消息内容:messageBody = {},delaySecondTime = {}", groupName, topName, messageBody, delaySecondTime);
        throw Ex.business(PaymentErrorMsgEnums.MQ_MESSAGE_SEND_ERROR);
    }

    protected abstract Result invoke(T request) throws Exception;

    protected abstract String getGroupName();

    protected abstract String getTopicName();

    protected Result checkParams(T request) {

        log.info("生成者发送消息请求参数:request = {}", JSON.toJSONString(request));
        if (request == null) {
            log.error("发送MQ消息请求对象为空");
            throw Ex.business(PaymentErrorMsgEnums.REQUEST_PARAMS_EMPTY);
        }
        String bizType = request.getBizType();
        String groupName = request.getGroupName();
        String topiName = request.getTopName();

        PaymentErrorMsgEnums errorMsgEnums = PaymentErrorMsgEnums.REQUEST_PARAMS_VALUE_ERROR;
        String errMsg = errorMsgEnums.getMessage();

        if (StringUtils.isBlank(bizType)) {
            log.error("生成者发送消息请求参数: bizType 为空");
            String msg = String.format(errMsg, "bizType");
            Object[] params = new Object[]{"bizType"};
            errorMsgEnums.setMessage(msg);
            errorMsgEnums.setParams(params);
            return Result.fail(errorMsgEnums);
        }

        if (StringUtils.isBlank(groupName)) {
            log.error("生成者发送消息请求参数: groupName 为空");
            String msg = String.format(errMsg, "groupName");
            Object[] params = new Object[]{"groupName"};
            errorMsgEnums.setMessage(msg);
            errorMsgEnums.setParams(params);
            return Result.fail(errorMsgEnums);
        }

        if (StringUtils.isBlank(topiName)) {
            log.error("生成者发送消息请求参数: topiName 为空");
            String msg = String.format(errMsg, "topiName");
            Object[] params = new Object[]{"topiName"};
            errorMsgEnums.setMessage(msg);
            errorMsgEnums.setParams(params);
            return Result.fail(errorMsgEnums);
        }
        return Result.ok();
    }




}
