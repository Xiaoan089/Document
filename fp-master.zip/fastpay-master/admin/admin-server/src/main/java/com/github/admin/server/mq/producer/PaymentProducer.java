package com.github.admin.server.mq.producer;

import com.github.framework.core.Result;

public interface PaymentProducer<T> {


    Result sendMessage(T request);


}
