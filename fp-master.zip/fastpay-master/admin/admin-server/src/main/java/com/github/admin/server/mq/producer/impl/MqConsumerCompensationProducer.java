package com.github.admin.server.mq.producer.impl;

import com.github.admin.server.mq.base.BasePaymentProducer;
import com.github.admin.server.mq.producer.PaymentProducer;
import com.github.framework.core.Result;
import com.github.framewrok.rocket.mq.base.RMQMessageBuilder;
import com.github.trans.front.common.constants.RocketMqConstants;
import com.github.trans.front.common.message.MqConsumerCompensationMessage;
import com.github.trans.front.common.message.MqProducerCompensationMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.Message;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class MqConsumerCompensationProducer extends BasePaymentProducer<MqConsumerCompensationMessage> implements PaymentProducer<MqConsumerCompensationMessage> {
    @Override
    protected Result invoke(MqConsumerCompensationMessage message) throws Exception {
        String groupName = message.getGroupName();
        String topicName = message.getTopName();
        Message msg = RMQMessageBuilder.of(message).topic(topicName).build();
        msg.setKeys(groupName);
        log.info("MQ消费者定时器补偿数据请求:topic = {},group = {},request = {}", topicName, groupName, message);
        return sendMessage(msg);
    }

    @Override
    protected String getGroupName() {
        return RocketMqConstants.MQ_CONSUMER_COMPENSATION_GROUP;
    }

    @Override
    protected String getTopicName() {
        return RocketMqConstants.MQ_CONSUMER_COMPENSATION_TOPIC;
    }

    @Override
    public Result sendMessage(MqConsumerCompensationMessage message) {
        return process(message);
    }
}
