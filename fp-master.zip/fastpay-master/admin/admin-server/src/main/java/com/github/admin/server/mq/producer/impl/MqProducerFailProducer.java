package com.github.admin.server.mq.producer.impl;

import com.github.admin.server.mq.base.BasePaymentProducer;
import com.github.admin.server.mq.producer.PaymentProducer;
import com.github.framework.core.Result;
import com.github.framewrok.rocket.mq.base.RMQMessageBuilder;
import com.github.trans.front.common.constants.RocketMqConstants;
import com.github.trans.front.common.enums.PaymentErrorMsgEnums;
import com.github.trans.front.common.message.MqSendFailMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.rocketmq.common.message.Message;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class MqProducerFailProducer extends BasePaymentProducer<MqSendFailMessage> implements PaymentProducer<MqSendFailMessage> {
    @Override
    protected Result invoke(MqSendFailMessage message) throws Exception {
        String groupName = message.getGroupName();
        String topicName = message.getTopName();
        Message msg = RMQMessageBuilder.of(message).topic(topicName).build();
        msg.setKeys(groupName);
        log.info("消费者消费失败MQ发送数据请求:topic = {},group = {},request = {}", topicName, groupName, message);
        return sendLevelOneDelayMessage(msg);
    }

    @Override
    protected String getGroupName() {
        return RocketMqConstants.MQ_PRODUCER_FAIL_GROUP;
    }

    @Override
    protected String getTopicName() {
        return RocketMqConstants.MQ_PRODUCER_FAIL_TOPIC;
    }

    @Override
    public Result sendMessage(MqSendFailMessage message) {
        return process(message);
    }

    @Override
    protected Result checkParams(MqSendFailMessage request) {
        Result result = super.checkParams(request);
        if (!result.isSuccess()) {
            return result;
        }

        PaymentErrorMsgEnums errorMsgEnums = PaymentErrorMsgEnums.REQUEST_PARAMS_VALUE_ERROR;
        String errMsg = errorMsgEnums.getMessage();

        String consumerErrMsg = request.getConsumerErrMsg();
        if(StringUtils.isBlank(consumerErrMsg)){
            log.error("消费者消费失败MQ请求参数: consumerErrMsg 为空");
            String msg = String.format(errMsg, "consumerErrMsg");
            Object[] params = new Object[]{"consumerErrMsg"};
            errorMsgEnums.setMessage(msg);
            errorMsgEnums.setParams(params);
            return Result.fail(errorMsgEnums);
        }

        return Result.ok();
    }

}
