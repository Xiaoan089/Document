package com.github.admin.server.service;


import com.github.admin.common.entity.TbExcelData;
import com.github.admin.common.request.ExcelDataRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * Excel导入演示
 */
public interface ExcelDataService {

    Result<DataPage<TbExcelData>> excelDatapage(ExcelDataRequest dto);
    Result<List<TbExcelData>> list(ExcelDataRequest request);
    Result<TbExcelData> findById(Long id);
    Result save(ExcelDataRequest request);
    Result update(ExcelDataRequest request);
    Result delete(List<Long> ids);
    Result currentModelClass();
    Result insertBatch(List<TbExcelData> list);

}
