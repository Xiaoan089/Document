/**
 * Copyright (c) 2020 人人开源 All rights reserved.
 * <p>
 * https://www.renren.io
 * <p>
 * 版权所有，侵权必究！
 */

package com.github.admin.server.service;

import com.github.admin.common.entity.GenBaseClass;
import com.github.admin.common.request.BaseClassRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 基类管理
 *
 * @author Mark sunlightcs@gmail.com
 */
public interface GenBaseClassService {

    Result<List<GenBaseClass>> list();

    Result<DataPage<GenBaseClass>> page(BaseClassRequest request);

    Result<GenBaseClass> findById(Long id);

    Result save(BaseClassRequest entity);
    Result update(BaseClassRequest entity);

    Result deleteByIds(List<Long> list);


}
