/**
 * Copyright (c) 2020 人人开源 All rights reserved.
 * <p>
 * https://www.renren.io
 * <p>
 * 版权所有，侵权必究！
 */

package com.github.admin.server.service;

import com.github.admin.common.entity.GenDataSource;
import com.github.admin.common.request.GenDataSourceRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;


public interface GenDataSourceService {

    Result<List<GenDataSource>> selectBySelective(GenDataSourceRequest request);

    Result<GenDataSource> findById(Long id);

    Result save(GenDataSourceRequest request);

    Result update(GenDataSourceRequest request);

    Result deleteByIds(List<Long> list);

    Result datasourceTest(Long id);

    Result<DataPage<GenDataSource>> dataSourcePage(GenDataSourceRequest request);

}
