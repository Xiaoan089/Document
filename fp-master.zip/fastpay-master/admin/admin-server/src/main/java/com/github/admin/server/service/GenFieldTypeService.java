package com.github.admin.server.service;

import com.github.admin.common.entity.GenFieldType;
import com.github.admin.common.request.GenFieldTypeRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface GenFieldTypeService {
    /**
     * 根据tableId，获取包列表
     */
    Result<Set<String>> getPackageListByTableId(Long tableId);

    Result<Set<String>> findAllAttrType();

    Result<DataPage<GenFieldType>> fieldTypePage(GenFieldTypeRequest request);

    Result<GenFieldType> findById(Long id);

    Result save(GenFieldTypeRequest request);

    Result update(GenFieldTypeRequest request);

    Result deleteByIds(List<Long> list);

    Map<String, GenFieldType> getMap();


    Result<List<GenFieldType>> selectBySelective(GenFieldTypeRequest request);
}
