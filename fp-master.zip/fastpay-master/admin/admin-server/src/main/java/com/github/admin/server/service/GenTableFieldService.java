/**
 * Copyright (c) 2020 人人开源 All rights reserved.
 * <p>
 * https://www.renren.io
 * <p>
 * 版权所有，侵权必究！
 */

package com.github.admin.server.service;


import com.github.admin.common.entity.GenTableField;
import com.github.admin.common.request.GenTableFieldRequest;
import com.github.framework.core.Result;

import java.util.List;

/**
 * 列
 *
 * @author Mark sunlightcs@gmail.com
 */
public interface GenTableFieldService {

    Result<List<GenTableField>> getByTableName(String tableName);

    Result deleteByTableName(String tableName);

    Result deleteBatchTableIds(List<Long> tableIds);

    Result save(GenTableFieldRequest request);

    Result saveBatch(List<GenTableField> tableFieldList);
}
