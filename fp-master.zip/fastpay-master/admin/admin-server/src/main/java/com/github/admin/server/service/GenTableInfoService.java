/**
 * Copyright (c) 2020 人人开源 All rights reserved.
 * <p>
 * https://www.renren.io
 * <p>
 * 版权所有，侵权必究！
 */

package com.github.admin.server.service;

import com.github.admin.common.entity.GenTableInfo;
import com.github.admin.common.request.TableInfoRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 表
 *
 * @author Mark sunlightcs@gmail.com
 */
public interface GenTableInfoService {

    Result<DataPage<GenTableInfo>> page(TableInfoRequest request);

    GenTableInfo getByTableName(String tableName);

    Result<GenTableInfo> findById(Long id);

    Result update(TableInfoRequest request);

    Result save(TableInfoRequest request);

    Result deleteByTableName(String tableName);

    Result deleteByIds(List<Long> ids);
}
