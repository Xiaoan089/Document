package com.github.admin.server.service;

import com.github.admin.common.entity.GenTemplate;
import com.github.admin.common.request.GenTemplateRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;


public interface GenTemplateService {

    Result<List<GenTemplate>> selectBySelective(GenTemplateRequest request);

    Result updateStatusBatch(GenTemplateRequest genTemplateRequest);

    Result<DataPage<GenTemplate>> page(GenTemplateRequest request);

    Result<GenTemplate> findById(Long id);

    Result deleteIds(List<Long> list);

    Result save(GenTemplateRequest request);

    Result update(GenTemplateRequest request);


}
