package com.github.admin.server.service;

import com.github.admin.common.entity.GenTableInfo;
import com.github.admin.common.request.GenTableFieldRequest;
import com.github.admin.common.request.SysMenuRequest;
import com.github.admin.common.request.TableInfoRequest;
import com.github.admin.server.config.DataSourceInfo;
import com.github.framework.core.Result;

import java.util.List;

/**
 * 代码生成
 */
public interface GeneratorService {

    DataSourceInfo getDataSourceInfo(Long datasourceId);

    void datasourceTable(TableInfoRequest request);

    void updateTableField(Long tableId, List<GenTableFieldRequest> tableFieldList);

    Result generatorCode(TableInfoRequest tableInfo);

    Result generatorMenu(SysMenuRequest request);

    Result<List<GenTableInfo>> generatorService(Long id);


}
