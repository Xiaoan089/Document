package com.github.admin.server.service;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.common.entity.MerchantAgent;
import com.github.trans.front.common.request.MerchantAgentRequest;


public interface MerchantAgentService {

    Result save(MerchantAgentRequest request);


    Result update(MerchantAgentRequest request);

    Result delete(MerchantAgentRequest request);

    Result updateAgentPassword(MerchantAgentRequest request);

    Result updateAgentFundPassword(MerchantAgentRequest request);

    Result<MerchantAgent> findById(Long id);

    Result<DataPage<MerchantAgent>> page(MerchantAgentRequest request);

}
