package com.github.admin.server.service;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.common.entity.Merchant;
import com.github.trans.front.common.request.MerchantRequest;

public interface MerchantService {

    Result save(MerchantRequest request);

    Result update(MerchantRequest request);

    Result delete(MerchantRequest request);

    Result updatePassword(MerchantRequest request);

    Result updateFundPassword(MerchantRequest request);

    Result<Merchant> findById(Long id);

    Result<DataPage<Merchant>> page(MerchantRequest request);
}
