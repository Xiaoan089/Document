package com.github.admin.server.service;

import com.github.admin.common.entity.TbNews;
import com.github.admin.common.request.NewsRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 新闻
 */
public interface NewsService {
    Result<DataPage<TbNews>> newsPage(NewsRequest request);

    Result save(NewsRequest request);

    Result<TbNews> findById(Long id);

    Result update(NewsRequest request);

    Result delete(List<Long> ids);


}

