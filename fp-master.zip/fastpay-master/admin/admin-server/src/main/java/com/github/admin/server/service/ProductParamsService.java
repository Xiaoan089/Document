package com.github.admin.server.service;

import com.github.admin.common.entity.TbProductParams;
import com.github.admin.common.request.ProductRequest;
import com.github.admin.common.request.TbProductParamsRequest;
import com.github.framework.core.Result;

import java.util.List;

public interface ProductParamsService {

    Result saveOrUpdate(ProductRequest request);

    Result<List<TbProductParams>> selectBySelective(TbProductParamsRequest request);

    Result deleteByProductIds(List<Long> ids);
}
