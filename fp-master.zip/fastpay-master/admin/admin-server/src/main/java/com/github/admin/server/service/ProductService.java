package com.github.admin.server.service;


import com.github.admin.common.entity.TbProduct;
import com.github.admin.common.request.ProductRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 产品管理
 */
public interface ProductService {

    Result<DataPage<TbProduct>> productPage(ProductRequest request);


    Result<TbProduct> findById(Long id);

    Result save(ProductRequest request);

    Result update(ProductRequest request);

    Result delete(List<Long> ids);

}
