package com.github.admin.server.service;

import com.github.admin.common.entity.ScheduleJobLog;
import com.github.admin.common.request.ScheduleJobLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

/**
 * 定时任务日志
 */
public interface ScheduleJobLogService {

	Result<DataPage<ScheduleJobLog>> page(ScheduleJobLogRequest request);

	Result<ScheduleJobLog> findById(Long id);

	Result insert(ScheduleJobLog log);
}
