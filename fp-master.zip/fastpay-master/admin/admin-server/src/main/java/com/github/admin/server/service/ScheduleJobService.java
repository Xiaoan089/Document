package com.github.admin.server.service;

import com.github.admin.common.entity.ScheduleJob;
import com.github.admin.common.request.ScheduleJobRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;


/**
 * 定时任务
 */
public interface ScheduleJobService {

	Result<DataPage<ScheduleJob>> page(ScheduleJobRequest request);

	/**
     * 保存定时任务
     *
     * @return
     */
	Result save(ScheduleJobRequest dto);

	/**
	 * 更新定时任务
	 *
	 * @return
	 */
	Result update(ScheduleJobRequest dto);

	/**
	 * 批量删除定时任务
	 *
	 * @return
	 */
	Result deleteByIds(List<Long> ids);

	/**
	 * 批量更新定时任务状态
	 */
	int updateBatch(List<Long> ids, int status);

	/**
	 * 立即执行
	 *
	 * @return
	 */
	Result run(List<Long> ids);

	/**
	 * 暂停运行
	 *
	 * @return
	 */
	Result pause(List<Long> ids);

	/**
	 * 恢复运行
	 *
	 * @return
	 */
	Result resume(List<Long> ids);

	Result<ScheduleJob> findById(Long id);
}
