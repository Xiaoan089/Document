package com.github.admin.server.service;

import com.github.admin.common.config.SmsConfig;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysSms;
import com.github.admin.common.utils.JsonUtils;
import com.github.framework.core.Result;
import com.github.framework.core.spring.SpringContextUtils;
import lombok.extern.slf4j.Slf4j;

/**
 * 短信Factory
 */
@Slf4j
public class SmsFactoryService {
    private static SysSmsService sysSmsService;

    static {
        SmsFactoryService.sysSmsService = SpringContextUtils.getBean(SysSmsService.class);
    }

    public static AbstractSmsService build(String smsCode){
        //获取短信配置信息
        Result<SysSms> result = sysSmsService.getBySmsCode(smsCode);
        if (!result.isSuccess()){
            log.error("根据smsCode获取短信配置信息失败， smsCode = {}", smsCode);
            return null;
        }
        SysSms smsEntity = result.getData();
        SmsConfig config = JsonUtils.parseObject(smsEntity.getSmsConfig(), SmsConfig.class);

        if(smsEntity.getPlatform() == Constant.SmsService.ALIYUN.getValue()){
            return new AliyunSmsService(config);
        }
//        else if(smsEntity.getPlatform() == Constant.SmsService.QCLOUD.getValue()){
//            return new QcloudSmsService(config);
//        }else if(smsEntity.getPlatform() == Constant.SmsService.QINIU.getValue()){
//            return new QiniuSmsService(config);
//        }

        return null;
    }
}
