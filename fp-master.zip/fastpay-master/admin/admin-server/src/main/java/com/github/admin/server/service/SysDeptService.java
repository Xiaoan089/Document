package com.github.admin.server.service;
import com.github.admin.common.entity.SysDept;
import com.github.admin.common.request.SysDeptRequest;
import com.github.framework.core.Result;

import java.util.List;

/**
 * 部门管理
 */
public interface SysDeptService {

	Result<List<SysDept>> list(SysDeptRequest request);
	/**
	 * 根据部门ID，获取本部门及子部门ID列表
	 * @param id   部门ID
	 */
	List<Long> getSubDeptIdList(Long id);

	Result<SysDept> findByIdOnType(SysDeptRequest request);

	Result save(SysDeptRequest request);

	Result update(SysDeptRequest request);

	Result deleteByIds(SysDeptRequest sysDeptRequest);
}
