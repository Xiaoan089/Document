package com.github.admin.server.service;
import com.github.admin.common.entity.SysDictData;
import com.github.admin.common.request.SysDictDataRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 数据字典
 */
public interface SysDictDataService {

    Result<DataPage<SysDictData>> page(SysDictDataRequest request);

    List<SysDictData> getDictDataList();

    Result deleteByDictTypeIds(List<Long> ids);

    Result<SysDictData> findById(Long id);

    Result save(SysDictDataRequest request);

    Result update(SysDictDataRequest request);

    Result delete(List<Long> ids);
}
