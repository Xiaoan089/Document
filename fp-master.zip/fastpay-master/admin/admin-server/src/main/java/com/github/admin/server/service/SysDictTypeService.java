package com.github.admin.server.service;
import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.request.SysDictTypeRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 数据字典
 */
public interface SysDictTypeService  {

    Result<DataPage<SysDictType>> page(SysDictTypeRequest params);

    /**
     * 获取所有字典
     */
    Result<List<SysDictType>> getAllList();

    /**
     * 字典类型列表
     */
    List<SysDictType> getDictTypeList();

    Result<SysDictType> findById(Long id);

    Result save(SysDictTypeRequest request);

    Result update(SysDictTypeRequest request);

    Result delete(List<Long> ids);
}
