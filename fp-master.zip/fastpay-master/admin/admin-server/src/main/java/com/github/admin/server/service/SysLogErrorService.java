package com.github.admin.server.service;

import com.github.admin.common.entity.SysLogError;
import com.github.admin.common.request.SysLogErrorRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;
import java.util.Map;

/**
 * 异常日志
 *
 */
public interface SysLogErrorService {

    Result<DataPage<SysLogError>> sysLogErrorPage(SysLogErrorRequest sysLogErrorDTO);

    Result<List<SysLogError>> selectListSelective(Map<String, Object> params);

    Result save(SysLogErrorRequest logRequest);

}
