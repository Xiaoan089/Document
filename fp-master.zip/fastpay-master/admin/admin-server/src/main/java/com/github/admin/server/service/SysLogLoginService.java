package com.github.admin.server.service;

import com.github.admin.common.entity.SysLogLogin;
import com.github.admin.common.request.SysLogLoginRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 登录日志
 */
public interface SysLogLoginService {

    Result<DataPage<SysLogLogin>> sysLogLoginPage(SysLogLoginRequest request);

    Result<List<SysLogLogin>> list(SysLogLoginRequest request);

    Result save(SysLogLoginRequest request);

}
