package com.github.admin.server.service;

import com.github.admin.common.entity.SysLogOperation;

import com.github.admin.common.request.SysLogOperationRequest;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;


/**
 * 操作日志
 */
public interface SysLogOperationService {

    Result<DataPage<SysLogOperation>> sysLogOperationPage(SysLogOperationRequest request);

    Result<List<SysLogOperation>> selectListBySelective(SysLogOperationRequest request);

    Result save(SysLogOperationRequest log);

}
