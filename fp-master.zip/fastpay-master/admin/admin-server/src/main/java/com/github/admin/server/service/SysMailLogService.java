package com.github.admin.server.service;

import com.github.admin.common.entity.SysMailLog;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 邮件发送记录
 */
public interface SysMailLogService {

    Result<DataPage<SysMailLog>> sysMailLogPage(SysMailLogRequest mailLogRequest);

    /**
     * 保存邮件发送记录
     * @param templateId  模板ID
     * @param from        发送者
     * @param to          收件人
     * @param cc          抄送
     * @param subject     主题
     * @param content     邮件正文
     * @param status      状态
     */
    void save(Long templateId, String from, String[] to, String[] cc, String subject, String content, Integer status);

    Result deleteByIds(List<Long> list);

}

