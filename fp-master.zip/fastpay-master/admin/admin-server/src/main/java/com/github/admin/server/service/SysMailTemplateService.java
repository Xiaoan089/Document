package com.github.admin.server.service;

import com.github.admin.common.entity.SysMailTemplate;
import com.github.admin.common.request.EmailConfigRequest;
import com.github.admin.common.request.SysMailLogRequest;
import com.github.admin.common.request.SysMailTemplateRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 邮件模板
 */
public interface SysMailTemplateService {

    /**
     * 发送邮件
     */
    Result sendMail(SysMailLogRequest mailLogRequest) throws Exception;


    Result<DataPage<SysMailTemplate>> sysMailTemplatePage(SysMailTemplateRequest templateRequest);

    Result updateValueByCode(EmailConfigRequest config);

    Result<SysMailTemplate> findById(Long id);

    Result save(SysMailTemplateRequest request);

    Result update(SysMailTemplateRequest request);

    Result delete(List<Long> ids);

}
