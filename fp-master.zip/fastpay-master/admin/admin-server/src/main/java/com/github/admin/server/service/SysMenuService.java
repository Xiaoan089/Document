package com.github.admin.server.service;
import com.github.admin.common.entity.SysMenu;
import com.github.admin.common.request.SysMenuRequest;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;

import java.util.List;


/**
 * 菜单管理
 */
public interface SysMenuService {

	Result<SysMenu> findById(SysMenuRequest request);

	Result deleteById(SysMenuRequest request);

	Result save(SysMenuRequest request);

	Result update(SysMenuRequest request);

	/**
	 * 菜单列表
	 *
	 * @param type 菜单类型
	 */
	Result<List<SysMenu>> getAllMenuList(SysMenuRequest type);

	/**
	 * 用户菜单列表
	 *
	 * @param sysMenuRequest
	 */
	Result<List<SysMenu>> getUserMenuList(SysMenuRequest sysMenuRequest);

	/**
	 * 根据父菜单，查询子菜单
	 * @param pid  父菜单ID
	 */
	Result<List<SysMenu>> getListPid(Long pid);

	/**
	 * 查询所有权限列表
	 */
	Result<List<String>> getPermissionsList(UserDetail user);

	/**
	 * 查询用户权限列表
	 * @param userId  用户ID
	 */
	Result<List<String>> getUserPermissionsList(UserDetail user);

	Result<SysMenu> list(SysMenuRequest request);
}
