package com.github.admin.server.service;

import com.github.admin.common.entity.SysNotice;
import com.github.admin.common.request.SysNoticeRequest;
import com.github.admin.common.websocketdata.MessageDataUserList;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

public interface SysNoticeService {
    Result<DataPage<SysNotice>> page(SysNoticeRequest sysNoticeRequest);
    /**
     * 获取被通知的用户
     */
    Result<DataPage<SysNotice>> getNoticeUserPage(SysNoticeRequest sysNoticeRequest);

    /**
     * 获取我的通知列表
     */
    Result<DataPage<SysNotice>> getMyNoticePage(SysNoticeRequest sysNoticeRequest);

    Result<MessageDataUserList> saveNotice(SysNoticeRequest sysNoticeRequest);

    Result<MessageDataUserList> updateNotice(SysNoticeRequest sysNoticeRequest);

    Result<SysNotice> findById(Long id);

    Result delete(List<Long> ids);

}
