package com.github.admin.server.service;

import com.github.admin.common.entity.SysNoticeUser;
import com.github.admin.common.request.SysNoticeRequest;
import com.github.framework.core.Result;

public interface SysNoticeUserService {
    Result updateReadStatus(SysNoticeRequest sysNoticeRequest);

    Result<Integer> getUnReadNoticeCount(Long userId);

    Result insertAllUser(SysNoticeUser noticeUser);
}
