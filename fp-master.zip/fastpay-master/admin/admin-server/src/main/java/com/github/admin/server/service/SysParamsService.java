package com.github.admin.server.service;

import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import com.github.admin.common.entity.SysParams;
import com.github.trans.front.common.request.SysParamsRequest;

import java.util.List;

public interface SysParamsService {

    Result<DataPage<SysParams>> page(SysParamsRequest request);

    Result<SysParams> findById(Long id);

    Result save(SysParamsRequest request);

    Result update(SysParamsRequest request);

    Result delete(List<Long> ids);

    Result<List<SysParams>> list(SysParamsRequest sysParamsRequest);

    Result<String> getValue(String paramCode);

    <T> Result<T> getValueObject(SysParamsRequest request);

    Result updateValueByCode(SysParamsRequest request);
}
