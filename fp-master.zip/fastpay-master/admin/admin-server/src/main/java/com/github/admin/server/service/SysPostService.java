package com.github.admin.server.service;

import com.github.admin.common.entity.SysPost;
import com.github.admin.common.request.SysPostRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;


/**
 * 岗位管理
 */
public interface SysPostService {
    Result<DataPage<SysPost>> page(SysPostRequest sysPostRequest);

    Result<List<SysPost>> selectListSelective(SysPostRequest sysPostRequest);

    Result delete(SysPostRequest sysPostRequest);

    Result<SysPost> findById(SysPostRequest sysPostRequest);

    Result save(SysPostRequest request);

    Result update(SysPostRequest request);
}
