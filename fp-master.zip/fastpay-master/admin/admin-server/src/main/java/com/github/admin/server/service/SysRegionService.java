package com.github.admin.server.service;
import com.github.admin.common.dto.RegionProvince;
import com.github.admin.common.entity.SysRegion;
import com.github.admin.common.request.SysRegionRequest;
import com.github.admin.common.response.SysRegionResponse;
import com.github.framework.core.Result;

import java.util.List;
import java.util.Map;

/**
 * 行政区域
 */
public interface SysRegionService {

	Result<List<SysRegionResponse>> list(SysRegionRequest request);

	Result<List<Map<String, Object>>> getTreeList();

	Result save(SysRegionRequest request);

	Result update(SysRegionRequest request);

	Result delete(Long id);

	int getCountByPid(Long pid);

	Result<List<RegionProvince>> getRegion(boolean threeLevel);

	Result<SysRegion> findById(Long id);
}
