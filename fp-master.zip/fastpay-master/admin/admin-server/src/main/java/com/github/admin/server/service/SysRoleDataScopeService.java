package com.github.admin.server.service;
import com.github.admin.common.request.SysRoleRequest;
import com.github.framework.core.Result;

import java.util.List;

/**
 * 角色数据权限
 */
public interface SysRoleDataScopeService {

    /**
     * 根据角色ID，获取部门ID列表
     */
    Result<List<Long>> getDeptIdList(Long roleId);

    /**
     * 保存或修改
     *
     * @return
     */
    Result saveOrUpdate(SysRoleRequest dto);

    /**
     * 根据角色id，删除角色数据权限关系
     *
     * @param roleId 角色ids
     * @return
     */
    Result deleteByRoleIds(List<Long> roleId);

    Result<List<Long>> getDataScopeList(Long userId);
}
