package com.github.admin.server.service;
import com.github.admin.common.entity.SysRole;
import com.github.admin.common.request.SysRoleRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;


/**
 * 角色
 */
public interface SysRoleService {

	Result<DataPage<SysRole>> page(SysRoleRequest sysRoleRequest);

	Result<List<SysRole>> list(SysRoleRequest sysRoleRequest);


	Result save(SysRoleRequest dto);

	Result update(SysRoleRequest dto);

	Result delete(SysRoleRequest sysRoleRequest);

	Result<SysRole> findByIdOnType(SysRoleRequest sysRoleRequest);
}
