package com.github.admin.server.service;

import com.github.admin.common.entity.SysSmsLog;
import com.github.admin.common.request.SysSmsLogRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * 短信日志
 */
public interface SysSmsLogService {

    /**
     * 保存短信发送记录
     * @param smsCode   短信编码
     * @param platform  平台
     * @param mobile    手机号
     * @param params    短信参数
     * @param status    发送状态
     */
    void save(String smsCode, Integer platform, String mobile, LinkedHashMap<String, String> params, Integer status);


    Result<DataPage<SysSmsLog>> smsLogPage(SysSmsLogRequest request);

    Result delete(List<Long> ids);

}
