package com.github.admin.server.service;

import com.github.admin.common.entity.SysSms;
import com.github.admin.common.request.SysSmsRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;

/**
 * 短信
 */
public interface SysSmsService {

    /**
     * 发送短信
     */
    Result send(SysSmsRequest smsRequest);

    Result<SysSms> getBySmsCode(String smsCode);

    Result<DataPage<SysSms>> page(SysSmsRequest sysSmsRequest);

    Result save(SysSmsRequest request);

    Result update(SysSmsRequest request);

    Result<SysSms> findById(Long id);

    Result delete(List<Long> ids);

}

