package com.github.admin.server.service;
import com.github.admin.common.request.SysUserRequest;
import com.github.framework.core.Result;

import java.util.List;

/**
 * 用户岗位关系
 */
public interface SysUserPostService {

    /**
     * 保存或修改
     * @param userId      用户ID
     * @param postIdList  岗位ID列表
     */
    Result saveOrUpdate(SysUserRequest request, List<Long> postIdList);

    /**
     * 根据岗位ids，删除岗位用户关系
     * @param postIds 岗位ids
     */
    Result deleteByPostIds(List<Long> postIds);

    /**
     * 根据用户id，删除岗位用户关系
     * @param userIds 用户ids
     */
    Result deleteByUserIds(List<Long> userIds);

    /**
     * 岗位ID列表
     * @param userId  用户ID
     */
    List<Long> getPostIdList(Long userId);
}
