package com.github.admin.server.service;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.response.SysUserResponse;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import java.util.List;


/**
 * 系统用户
 */
public interface SysUserService {

	Result<DataPage<SysUser>> page(SysUserRequest sysUserRequest);

	Result<List<SysUserResponse>> list(SysUserRequest sysUserRequest);

	Result<SysUser> findByIdOnType(SysUserRequest request);

	Result<SysUser> getByUsername(SysUserRequest request);

	Result save(SysUserRequest request);

	Result update(SysUserRequest request);

	Result delete(SysUserRequest request);

	/**
	 * 修改密码
	 * @param id           用户ID
	 * @param newPassword  新密码
	 */
	Result updatePassword(SysUserRequest request);

	/**
	 * 根据部门ID，查询用户数
	 */
	int getCountByDeptId(Long deptId);

	/**
	 * 根据部门ID,查询用户Id列表
	 */
	Result<List<Long>> getUserIdListByDeptId(List<Long> deptIdList);

	Result<SysUser> findById(Long id);
}
