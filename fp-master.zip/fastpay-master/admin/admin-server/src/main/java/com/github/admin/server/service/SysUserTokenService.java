package com.github.admin.server.service;

import com.github.admin.common.entity.SysOnlineEntity;
import com.github.admin.common.entity.SysUserToken;
import com.github.admin.common.request.SysOnlineRequest;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

/**
 * 用户Token
 */
public interface SysUserTokenService {

	/**
	 * 生成token
	 * @param userId  用户ID
	 */
	Result createToken(Long userId);

	/**
	 * 退出
	 * @param userId  用户ID
	 */
	Result logout(Long userId);

	Result<DataPage<SysOnlineEntity>> onlinePage(SysOnlineRequest request);

	/**
	 * 获取系统用户token
	 * @param token token
	 * @return
	 */
	Result<SysUserToken> getByToken(String token);

}
