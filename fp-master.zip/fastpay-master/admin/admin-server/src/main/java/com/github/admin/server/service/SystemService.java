package com.github.admin.server.service;

import com.github.admin.common.dto.SysSystem;
import com.github.framework.core.Result;

public interface SystemService {

    Result<SysSystem> getSystem();
}
