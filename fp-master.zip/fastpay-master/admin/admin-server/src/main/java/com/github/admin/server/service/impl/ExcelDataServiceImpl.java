package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.TbExcelData;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.ExcelDataRequest;
import com.github.admin.server.dao.TbExcelDataDao;
import com.github.admin.server.service.ExcelDataService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Excel导入演示
 */
@Service
@Slf4j
public class ExcelDataServiceImpl implements ExcelDataService {

    @Resource
    private TbExcelDataDao excelDataDao;

    @Override
    public Result<DataPage<TbExcelData>> excelDatapage(ExcelDataRequest request) {
        log.info("Excel导入演示分页请求参数:{}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<TbExcelData> dataPage = new DataPage<TbExcelData>(pageNo,pageSize);
        Map<String,Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex",dataPage.getStartIndex());
        map.put("offset",dataPage.getPageSize());
        Integer userCount = excelDataDao.findTbExcelDataCountByPage(map);
        List<TbExcelData> list = excelDataDao.findTbExcelDataListByPage(map);
        log.info("查询Excel导入演示大小数量totalCount:{}",userCount);
        dataPage.setTotalCount(userCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result<List<TbExcelData>> list(ExcelDataRequest request) {
        List<TbExcelData> list = excelDataDao.selectListBySelective(request);
        return Result.ok(list);
    }

    @Override
    public Result<TbExcelData> findById(Long id) {
        if (id == null){
            log.error("根据id查询 Excel导入演示请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        TbExcelData tbExcelData = excelDataDao.selectByPrimaryKey(id);
        if (tbExcelData == null){
            log.error("根据id查询 Excel导入演示 查询结果为空 id:{}",id);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok(tbExcelData);
    }

    @Override
    public Result save(ExcelDataRequest request) {
        if (request == null){
            log.error("保存 Excel导入演示 请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        BaseRequestUtils.createAssemble(request);
        TbExcelData tbExcelData = new TbExcelData();
        BeanUtil.copyProperties(request,tbExcelData);
        int row = excelDataDao.insertSelective(tbExcelData);
        if (row == 0){
            log.error("保存 Excel导入演示 操作失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result update(ExcelDataRequest request) {
        if (request == null){
            log.error("更新 Excel导入演示 请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        BaseRequestUtils.updateAssemble(request);
        TbExcelData tbExcelData = new TbExcelData();
        BeanUtil.copyProperties(request,tbExcelData);
        int row = excelDataDao.updateByPrimaryKeySelective(tbExcelData);
        if (row == 0){
            log.error("更新 Excel导入演示 操作失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result delete(List<Long> ids) {
        if (CollectionUtil.isEmpty(ids)){
            log.error("删除 Excel导入演示 请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        int row = excelDataDao.delete(ids);
        if (row == 0){
            log.error("excel delete error ids:{}",ids);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result currentModelClass() {
        return Result.ok(new TbExcelData());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result insertBatch(List<TbExcelData> list) {
        if (CollectionUtil.isEmpty(list)){
            log.error("批量插入 Excel导入演示 请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        for (TbExcelData tbExcelData : list) {
            int row = excelDataDao.insertSelective(tbExcelData);
            if (row == 0){
                throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
            }
        }
        return Result.ok();
    }
}
