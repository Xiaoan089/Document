package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.common.entity.GenBaseClass;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.BaseClassRequest;
import com.github.admin.server.dao.GenBaseClassDao;
import com.github.admin.server.service.GenBaseClassService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class GenBaseClassServiceImpl implements GenBaseClassService {

    @Resource
    private GenBaseClassDao genBaseClassDao;

    @Override
    public Result<List<GenBaseClass>> list() {
        log.info("基类管理list运营");
        GenBaseClass genBaseClass = new GenBaseClass();
        List<GenBaseClass> baseClassEntities = genBaseClassDao.selectBySelective(genBaseClass);
        return Result.ok(baseClassEntities);
    }

    @Override
    public Result<DataPage<GenBaseClass>> page(BaseClassRequest request) {
        log.info("基类管理分页:request = {}", request);
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<GenBaseClass> dataPage = new DataPage<GenBaseClass>(pageNo, pageSize);
        Map<String, Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex", dataPage.getStartIndex());
        map.put("offset", dataPage.getPageSize());
        Integer errorCount = genBaseClassDao.findDictTypeCountByPage(map);
        List<GenBaseClass> list = genBaseClassDao.findDictTypeListByPage(map);
        log.info("查询基类管理大小数量totalCount:{}", errorCount);
        dataPage.setTotalCount(errorCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result<GenBaseClass> findById(Long id) {
        log.info("基类管理根据id查询:id = {}",id);
        if (id == null) {
            log.error("基类管理根据id查询请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        GenBaseClass genBaseClass = genBaseClassDao.selectByPrimaryKey(id);
        return Result.ok(genBaseClass);
    }

    @Override
    public Result save(BaseClassRequest request) {
        log.info("基类管理新增:request = {}",request);

        BaseRequestUtils.createAssemble(request);
        GenBaseClass genBaseClass = new GenBaseClass();
        BeanUtil.copyProperties(request, genBaseClass);
        int row = genBaseClassDao.insertSelective(genBaseClass);
        if (row != 1) {
            log.error("基类管理新增失败:操作数据库失败,request = {}", genBaseClass);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result update(BaseClassRequest request) {
        log.info("基类管理更新:request = {}",request);

        BaseRequestUtils.updateAssemble(request);
        GenBaseClass genBaseClass = new GenBaseClass();
        BeanUtil.copyProperties(request, genBaseClass);
        int row = genBaseClassDao.updateByPrimaryKeySelective(genBaseClass);
        if (row != 1) {
            log.error("基类管理更新失败:操作数据库失败,request = {}", genBaseClass);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteByIds(List<Long> ids) {
        log.info("基类管理删除:ids = {}", ids);
        if (CollectionUtils.isEmpty(ids)) {
            log.error("基类管理删除请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = genBaseClassDao.deleteByIds(ids);
        if (row != ids.size()) {
            log.error("基类管理删除:操作数据库异常,ids = {}", ids);
        }
        return Result.ok();
    }

}
