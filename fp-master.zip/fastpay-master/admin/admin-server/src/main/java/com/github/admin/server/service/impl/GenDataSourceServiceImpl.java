/**
 * Copyright (c) 2020 人人开源 All rights reserved.
 * <p>
 * https://www.renren.io
 * <p>
 * 版权所有，侵权必究！
 */

package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.common.entity.GenDataSource;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.GenDataSourceRequest;
import com.github.admin.server.config.DataSourceInfo;
import com.github.admin.server.dao.GenDataSourceDao;
import com.github.admin.server.service.GenDataSourceService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.admin.server.utils.DbUtils;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 数据源管理
 *
 * @author Mark sunlightcs@gmail.com
 */
@Service
@Slf4j
public class GenDataSourceServiceImpl implements GenDataSourceService {

    @Resource
    private GenDataSourceDao genDataSourceDao;


    @Override
    public Result<List<GenDataSource>> selectBySelective(GenDataSourceRequest request) {
        log.info("数据源管理条件查询:request = {}", request);
        List<GenDataSource> list = genDataSourceDao.selectBySelective(request);
        return Result.ok(list);
    }

    @Override
    public Result<GenDataSource> findById(Long id) {
        log.info("数据源管理条件根据id查询:id = {}", id);
        if (id == null) {
            log.error("数据源管理条件根据id查询请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        GenDataSource genDataSource = genDataSourceDao.selectByPrimaryKey(id);
        return Result.ok(genDataSource);
    }

    @Override
    public Result save(GenDataSourceRequest request) {
        log.info("数据源管理条件新增:request = {}", request);

        BaseRequestUtils.createAssemble(request);
        GenDataSource genDataSource = new GenDataSource();
        BeanUtil.copyProperties(request, genDataSource);
        int row = genDataSourceDao.insertSelective(genDataSource);
        if (row != 1) {
            log.error("数据源管理条件新增失败:操作数据库失败,request = {}", genDataSourceDao);
        }
        return Result.ok();
    }

    @Override
    public Result update(GenDataSourceRequest request) {
        log.info("数据源管理条件修改:request = {}", request);

        BaseRequestUtils.updateAssemble(request);
        GenDataSource genDataSource = new GenDataSource();
        BeanUtil.copyProperties(request, genDataSource);
        int row = genDataSourceDao.updateByPrimaryKeySelective(genDataSource);
        if (row != 1) {
            log.error("数据源管理条件修改失败:操作数据库失败,request = {}", genDataSourceDao);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteByIds(List<Long> ids) {
        log.info("数据源管理条件删除:ids = {}", ids);

        if (CollectionUtils.isEmpty(ids)) {
            log.error("数据源管理条件删除请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = genDataSourceDao.deleteByIds(ids);
        if (row != ids.size()) {
            log.error("数据源管理条件删除失败:操作数据库失败,ids = {}", ids);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result datasourceTest(Long id) {
        log.info("数据库连接测试:id = {}", id);
        if (id == null) {
            log.error("数据库连接测试请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        try {
            GenDataSource genDataSource = genDataSourceDao.selectByPrimaryKey(id);
            if (genDataSource == null) {
                log.error("数据库连接测试对象不存在,id = {}", id);
                return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
            }
            DbUtils.getConnection(new DataSourceInfo(genDataSource));
        } catch (Exception e) {
            log.error("数据库连接测试异常,e:", e);
            return Result.fail(AdminErrorMsgEnum.SYSTEM_EXCEPTION);
        }
        return Result.ok();
    }

    @Override
    public Result<DataPage<GenDataSource>> dataSourcePage(GenDataSourceRequest request) {
        log.info("数据库连接分页:request = {}", request);
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<GenDataSource> dataPage = new DataPage<GenDataSource>(pageNo, pageSize);
        Map<String, Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex", dataPage.getStartIndex());
        map.put("offset", dataPage.getPageSize());
        long count = genDataSourceDao.findDataSourceCountByPage(map);
        List<GenDataSource> list = genDataSourceDao.findDataSourceListByPage(map);
        log.info("查询数据库连接大小数量totalCount:{}", count);
        dataPage.setTotalCount(count);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }


}
