package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.common.entity.GenFieldType;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.GenFieldTypeRequest;
import com.github.admin.server.dao.GenFieldTypeDao;
import com.github.admin.server.service.GenFieldTypeService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static cn.hutool.json.XMLTokener.entity;


@Service
@Slf4j
public class GenFieldTypeServiceImpl implements GenFieldTypeService {

    @Resource
    private GenFieldTypeDao genFieldTypeDao;

    @Override
    public Result<Set<String>> getPackageListByTableId(Long tableId) {
        log.info("字段类型管理查询包:tableId={}", tableId);
        if (tableId == null) {
            log.error("字段类型管理查询包失败:请求参数tableId为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        Set<String> packageListByTableId = genFieldTypeDao.getPackageListByTableId(tableId);
        return Result.ok(packageListByTableId);
    }

    @Override
    public Result<Set<String>> findAllAttrType() {
        log.info("字段类型管理查询AttrType");
        Set<String> set = genFieldTypeDao.findAllAttrType();
        return Result.ok(set);
    }

    @Override
    public Result<DataPage<GenFieldType>> fieldTypePage(GenFieldTypeRequest request) {
        log.info("字段类型分页:request={}", request);
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<GenFieldType> dataPage = new DataPage<GenFieldType>(pageNo, pageSize);
        Map<String, Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex", dataPage.getStartIndex());
        map.put("offset", dataPage.getPageSize());
        long userCount = genFieldTypeDao.findFieldTypeCountByPage(map);
        List<GenFieldType> list = genFieldTypeDao.findFieldTypeListByPage(map);
        log.info("查询字段类型大小数量totalCount:{}", userCount);
        dataPage.setTotalCount(userCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result<GenFieldType> findById(Long id) {
        log.info("字段类型管理根据id查询:id={}", id);
        if (id == null) {
            log.error("字段类型管理根据id查询请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        GenFieldType genFieldType = genFieldTypeDao.selectByPrimaryKey(id);
        return Result.ok(genFieldType);
    }

    @Override
    public Result save(GenFieldTypeRequest request) {
        log.info("字段类型管理新增:request={}", request);

        BaseRequestUtils.createAssemble(request);
        GenFieldType genFieldType = new GenFieldType();
        BeanUtil.copyProperties(request, genFieldType);
        int row = genFieldTypeDao.insertSelective(genFieldType);
        if (row != 1) {
            log.error("字段类型管理新增失败:操作数据库失败,request = {}", genFieldType);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result update(GenFieldTypeRequest request) {
        log.info("字段类型管理修改:request={}", request);

        GenFieldType genFieldType = new GenFieldType();
        BeanUtil.copyProperties(request, genFieldType);
        int row = genFieldTypeDao.updateByPrimaryKeySelective(genFieldType);
        if (row != 1) {
            log.error("字段类型管理修改失败:操作数据库失败,request = {}", genFieldType);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteByIds(List<Long> ids) {
        log.info("字段类型管理删除:ids={}", ids);
        if (CollectionUtils.isEmpty(ids)) {
            log.error("字段类型管理删除ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = genFieldTypeDao.deleteByIds(ids);
        if (row != ids.size()) {
            log.error("字段类型管理删除失败:操作数据库失败,ids = {}",ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Map<String, GenFieldType> getMap() {
        Result<List<GenFieldType>> result = selectBySelective(new GenFieldTypeRequest());
        if (!result.isSuccess()) {
            log.error("getMap请求失败:条件查询失败");
            return null;
        }
        List<GenFieldType> list = result.getData();
        Map<String, GenFieldType> map = new LinkedHashMap<>(list.size());
        for (GenFieldType entity : list) {
            map.put(entity.getColumnType().toLowerCase(), entity);
        }
        return map;
    }

    @Override
    public Result<List<GenFieldType>> selectBySelective(GenFieldTypeRequest request) {
        log.info("字段类型管理条件查询:request={}", request);
        List<GenFieldType> list = genFieldTypeDao.selectBySelective(request);
        return Result.ok(list);
    }

}
