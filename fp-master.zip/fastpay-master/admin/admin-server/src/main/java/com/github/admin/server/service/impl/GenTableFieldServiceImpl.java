package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.common.entity.GenTableField;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.GenTableFieldRequest;
import com.github.admin.server.dao.GenTableFieldDao;
import com.github.admin.server.service.GenTableFieldService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;


@Service
@Slf4j
public class GenTableFieldServiceImpl implements GenTableFieldService {

    @Resource
    private GenTableFieldDao genTableFieldDao;

    @Override
    public Result<List<GenTableField>> getByTableName(String tableName) {
        log.info("代码生成列表根据tableName查询:tableName{}", tableName);
        if (StringUtils.isBlank(tableName)) {
            log.error("代码生成列表根据tableName查询请求参数tableName为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        List<GenTableField> list = genTableFieldDao.getByTableName(tableName);
        return Result.ok(list);
    }

    @Override
    public Result deleteByTableName(String tableName) {
        log.info("代码生成列表根据tableName删除:tableName{}", tableName);
        if (StringUtils.isBlank(tableName)) {
            log.error("代码生成列表根据tableName删除请求参数tableName为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = genTableFieldDao.deleteByTableName(tableName);
        if (row == 0) {
            log.error("代码生成列表根据tableName删除失败:操作数据库失败,tableName = {}",tableName);
        }
        return Result.ok();
    }

    @Override
    public Result deleteBatchTableIds(List<Long> tableIds) {
        log.info("代码生成列表根据tableIds删除:tableIds{}", tableIds);
        if (CollectionUtils.isEmpty(tableIds)) {
            log.error("代码生成列表根据tableIds删除请求参数tableIds为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = genTableFieldDao.deleteByTableIds(tableIds);
        if (row == 0) {
            log.error("代码生成列表根据tableIds删除失败:操作数据库失败,tableIds = {}",tableIds);
        }
        return Result.ok();
    }

    @Override
    public Result save(GenTableFieldRequest request) {
        log.info("代码生成列表新增:request={}", request);

        BaseRequestUtils.createAssemble(request);
        GenTableField genTableField = new GenTableField();
        BeanUtil.copyProperties(request, genTableField);
        int row = genTableFieldDao.insertSelective(genTableField);
        if (row != 1){
            log.error("代码生成列表新增:操作数据库失败,request = {}",genTableField);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result saveBatch(List<GenTableField> tableFieldList) {
        log.info("代码生成批量新增:request = {}",tableFieldList);
        if (CollectionUtils.isEmpty(tableFieldList)) {
            log.error("代码生成批量新增请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = genTableFieldDao.saveBatch(tableFieldList);
        if (row != tableFieldList.size()){
            log.error("代码生成批量新增失败:操作数据库失败,tableFieldList = {}",tableFieldList);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

}
