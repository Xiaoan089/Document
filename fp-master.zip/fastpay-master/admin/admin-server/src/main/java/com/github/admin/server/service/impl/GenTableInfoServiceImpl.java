package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.common.entity.GenTableField;
import com.github.admin.common.entity.GenTableInfo;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.TableInfoRequest;
import com.github.admin.server.dao.GenTableInfoDao;
import com.github.admin.server.service.GenTableFieldService;
import com.github.admin.server.service.GenTableInfoService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 表
 */
@Service
@Slf4j
public class GenTableInfoServiceImpl implements GenTableInfoService {

    @Resource
    private GenTableInfoDao genTableInfoDao;

    @Resource
    private GenTableFieldService genTableFieldService;

    @Override
    public Result<DataPage<GenTableInfo>> page(TableInfoRequest request) {
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        log.info("代码生成分页查询:request = {}", request);
        DataPage<GenTableInfo> dataPage = new DataPage<GenTableInfo>(pageNo, pageSize);
        Map<String, Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex", dataPage.getStartIndex());
        map.put("offset", dataPage.getPageSize());
        long errorCount = genTableInfoDao.findTableInfoCountByPage(map);
        List<GenTableInfo> list = genTableInfoDao.findTableInfoListByPage(map);
        log.info("查询代码生成大小数量totalCount:{}", errorCount);
        dataPage.setTotalCount(errorCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public GenTableInfo getByTableName(String tableName) {
        log.info("代码生成根据tableName查询:tableName = {}", tableName);
        if (StringUtils.isBlank(tableName)) {
            log.error("代码生成根据tableName查询请求参数tableName为空");
            return null;
        }
        return genTableInfoDao.getByTableName(tableName);
    }

    @Override
    public Result<GenTableInfo> findById(Long id) {
        log.info("代码生成根据id查询,id = {}", id);
        if (id == null) {
            log.error("代码生成根据id查询请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        GenTableInfo entity = genTableInfoDao.selectByPrimaryKey(id);
        log.info("代码生成根据id查询:查询结果entity = {}", entity);
        if (entity == null) {
            return Result.ok();
        }

        Result<List<GenTableField>> result = genTableFieldService.getByTableName(entity.getTableName());
        if (!result.isSuccess()) {
            log.error("代码生成根据id查询:查询tableField失败,request = {}",entity.getTableName());
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        List<GenTableField> tableFieldEntityList = result.getData();
        entity.setFields(tableFieldEntityList);
        return Result.ok(entity);
    }

    @Override
    public Result update(TableInfoRequest request) {
        log.info("代码生成更新:request = {}", request);

        BaseRequestUtils.updateAssemble(request);
        GenTableInfo genTableInfo = new GenTableInfo();
        BeanUtil.copyProperties(request, genTableInfo);
        int row = genTableInfoDao.updateByPrimaryKeySelective(genTableInfo);
        if (row != 1) {
            log.error("代码生成更新失败:操作数据库失败,request = {}", genTableInfo);
        }
        return Result.ok();
    }

    @Override
    public Result save(TableInfoRequest request) {
        log.info("代码生成新增:request = {}", request);

        BaseRequestUtils.createAssemble(request);
        GenTableInfo genTableInfo = new GenTableInfo();
        BeanUtil.copyProperties(request, genTableInfo);
        int row = genTableInfoDao.insertSelective(genTableInfo);
        request.setId(genTableInfo.getId());
        if (row != 1) {
            log.error("代码生成新增失败:操作数据库失败,request = {}", genTableInfo);
        }
        return Result.ok();
    }


    @Override
    public Result deleteByTableName(String tableName) {
        log.info("代码生成根据tableName删除:tableName = {}", tableName);

        if (StringUtils.isBlank(tableName)) {
            log.error("代码生成根据tableName删除请求参数tableName为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = genTableInfoDao.deleteByTableName(tableName);
        if (row == 0) {
            log.error("代码生成根据tableName删除失败:操作数据库失败,tableName = {}", tableName);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteByIds(List<Long> ids) {
        log.info("代码生成根据ids删除:ids = {}", ids);

        if (CollectionUtils.isEmpty(ids)) {
            log.error("代码生成根据ids删除请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        //删除表
        int row = genTableInfoDao.deleteByIds(ids);
        if (row != ids.size()) {
            log.error("代码生成根据ids删除失败:操作数据库失败,ids = {}", ids);
        }

        //删除列
        Result result = genTableFieldService.deleteBatchTableIds(ids);
        if (!result.isSuccess()) {
            log.error("代码生成根据ids删除失败:删除代码生成列表失败,ids = {}", ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }
}
