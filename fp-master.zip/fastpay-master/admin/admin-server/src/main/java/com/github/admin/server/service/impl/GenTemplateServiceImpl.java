package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.github.admin.common.entity.GenTemplate;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.GenTemplateRequest;
import com.github.admin.server.dao.GenTemplateDao;
import com.github.admin.server.service.GenTemplateService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.admin.server.utils.GenUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


@Service
@Slf4j
public class GenTemplateServiceImpl implements GenTemplateService {

    @Resource
    private GenTemplateDao genTemplateDao;

    @Override
    public Result<List<GenTemplate>> selectBySelective(GenTemplateRequest request) {
        log.info("模板管理条件查询:request={}", request);
        GenTemplate genTemplate = new GenTemplate();
        BeanUtil.copyProperties(request, genTemplate);
        List<GenTemplate> list = genTemplateDao.selectBySelective(request);
        return Result.ok(list);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result updateStatusBatch(GenTemplateRequest request){
        log.info("模板管理修改状态:request={}", request);
        if (request == null) {
            log.error("模板管理修改状态失败请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        List<Long> ids = request.getIds();
        Integer status = request.getStatus();
        if (CollectionUtil.isEmpty(ids) || status == null){
            log.error("模板管理修改状态失败:ids = {},status = {}", ids, status);
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_ERROR);
        }

        GenTemplate genTemplate = new GenTemplate();
        BeanUtil.copyProperties(request, genTemplate);
        int row = genTemplateDao.updateStatusBatch(genTemplate);
        if (row != ids.size()){
            log.error("模板管理修改状态失败:操作数据库失败,ids:{}",ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result<DataPage<GenTemplate>> page(GenTemplateRequest request) {
        log.info("模板管理分页查询:request={}", request);
        if (request == null) {
            log.error("模板分页查询失败,request is empty");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<GenTemplate> dataPage = new DataPage<>(pageNo, pageSize);
        Map<String,Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex",dataPage.getStartIndex());
        map.put("offset",dataPage.getPageSize());
        long count = genTemplateDao.findTemplateCountByPage(map);
        List<GenTemplate> list = genTemplateDao.findTemplateListByPage(map);
        log.info("查询模板日志大小数量totalCount:{}",count);
        dataPage.setTotalCount(count);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result<GenTemplate> findById(Long id) {
        log.info("模板id查询:id={}", id);
        if (id == null){
            log.error("查询模板数据请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        GenTemplate genTemplate = genTemplateDao.selectByPrimaryKey(id);
        return Result.ok(genTemplate);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteIds(List<Long> ids) {
        log.info("模板删除ids = {}",ids);
        if (CollectionUtil.isEmpty(ids)){
            log.error("删除模板数据请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        int row = genTemplateDao.deleteByIds(ids);
        if (row != ids.size()){
            log.error("删除模板数据失败,ids = {}",ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result save(GenTemplateRequest request) {
        log.info("模板添加:request={}", request);
        if (request == null){
            log.error("模板新增请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        try {
            //检查模板语法是否正确
            GenUtils.getTemplateContent(request.getContent(), Maps.newHashMap());
        } catch (Exception e) {
            log.error("添加模板语法异常 e:",e);
            return Result.fail(AdminErrorMsgEnum.SYSTEM_EXCEPTION);
        }

        GenTemplate genTemplate = new GenTemplate();
        BaseRequestUtils.createAssemble(request);
        BeanUtil.copyProperties(request,genTemplate);
        int row = genTemplateDao.insertSelective(genTemplate);
        if (row != 1){
            log.error("模板新增失败:操作数据库失败,request = {}",genTemplate);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result update(GenTemplateRequest request) {
        log.info("更新模板请求参数对象:request={}", request);
        if (request == null){
            log.error("模板修改请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        try {
            //检查模板语法是否正确
            GenUtils.getTemplateContent(request.getContent(), Maps.newHashMap());
        } catch (Exception e) {
            log.error("更新模板语法异常 e:",e);
            return Result.fail(AdminErrorMsgEnum.SYSTEM_EXCEPTION);
        }
        GenTemplate genTemplate = new GenTemplate();
        BeanUtil.copyProperties(request,genTemplate);
        int row = genTemplateDao.updateByPrimaryKeySelective(genTemplate);
        if (row == 0){
            log.error("模板修改失败:操作数据库失败,request = {}",genTemplate);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }
}
