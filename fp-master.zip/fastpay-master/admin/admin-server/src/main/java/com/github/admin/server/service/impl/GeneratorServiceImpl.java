package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.FileUtil;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.*;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.*;
import com.github.admin.common.utils.DateUtils;
import com.github.admin.server.config.DataSourceInfo;
import com.github.admin.server.service.*;
import com.github.admin.server.utils.DbUtils;
import com.github.admin.server.utils.GenUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.admin.common.dto.ParamSetting;
import com.github.trans.front.common.request.SysParamsRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.io.File;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

import static com.github.admin.server.utils.BaseRequestUtils.verifyUserDetail;


@Service
@Slf4j
public class GeneratorServiceImpl implements GeneratorService {

    @Resource
    private GenTableInfoService genTableInfoService;
    @Resource
    private GenTableFieldService genTableFieldService;
    @Resource
    private GenDataSourceService genDatasourceService;
    @Resource
    private GenFieldTypeService genFieldTypeService;
    @Resource
    private GenBaseClassService genBaseClassService;
    @Resource
    private GenTemplateService genTemplateService;
    @Resource
    private SysParamsService sysParamsService;
    @Resource
    private DataSource dataSource;

    @Resource
    private SysMenuService sysMenuService;

    @Resource
    private SysLanguageService sysLanguageService;

    @Override
    public DataSourceInfo getDataSourceInfo(Long datasourceId) {
        log.info("初始化配置信息请求参数:datasourceId = {}", datasourceId);
        //初始化配置信息
        DataSourceInfo info = null;
        if (datasourceId.intValue() == 0) {
            try {
                info = new DataSourceInfo(dataSource.getConnection());
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            Result<GenDataSource> result = genDatasourceService.findById(datasourceId);
            if (!result.isSuccess()) {
                log.error("初始化配置信息失败:查询dataSource失败,datasourceId = {}", datasourceId);
                return info;
            }
            GenDataSource data = result.getData();
            info = new DataSourceInfo(data);
        }
        return info;
    }

    @Override
    public Result<List<GenTableInfo>> generatorService(Long id) {
        try {
            //初始化配置信息
            DataSourceInfo dataSourceInfo = this.getDataSourceInfo(id);
            if(dataSourceInfo == null){
                log.error("自动生成代码获取数据源为空:id = {}",id);
                return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
            }
            List<GenTableInfo> tableInfoList = DbUtils.getTablesInfoList(dataSourceInfo);

            return Result.ok(tableInfoList);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail(AdminErrorMsgEnum.SYSTEM_ERROR);
        }
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void datasourceTable(TableInfoRequest request) {
        //初始化配置信息
        DataSourceInfo info = getDataSourceInfo(request.getDatasourceId());

        GenTableInfo tableInfo = genTableInfoService.getByTableName(request.getTableName());
        //表存在
        if (tableInfo != null) {
            log.error("数据表已存在,tableName = {}", tableInfo.getTableName());
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        tableInfo = DbUtils.getTablesInfo(info, request.getTableName());

        //代码生成器参数
        SysParamsRequest sysParamsRequest = new SysParamsRequest();
        sysParamsRequest.setParamCode(Constant.DEV_TOOLS_PARAM_KEY);
        sysParamsRequest.setClazz(ParamSetting.class);
        Result<ParamSetting> result = sysParamsService.getValueObject(sysParamsRequest);

        if (!result.isSuccess()) {
            log.error("获取系统参数异常:request = {}", Constant.DEV_TOOLS_PARAM_KEY);
            return;
        }
//        ParamSetting param = FeignUtils.formatListClass((LinkedHashMap) result.getData(), ParamSetting.class);
        ParamSetting param = result.getData();
        //保存表信息
        if (param == null) {
            log.error("系统参数为空:request = {}", Constant.DEV_TOOLS_PARAM_KEY);
            return;
        }
        tableInfo.setPackageName(param.getPackageName());
        tableInfo.setVersion(param.getVersion());
        tableInfo.setAuthor(param.getAuthor());
        tableInfo.setEmail(param.getEmail());
        tableInfo.setBackendPath(param.getBackendPath());
        tableInfo.setFrontendPath(param.getFrontendPath());
        TableInfoRequest tableInfoRequest = new TableInfoRequest();
        BeanUtil.copyProperties(tableInfo, tableInfoRequest);
        Result saveResult = genTableInfoService.save(tableInfoRequest);
        if (!saveResult.isSuccess()) {
            log.error("表信息添加异常:request = {}", tableInfoRequest);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        //获取原生列数据
        List<GenTableField> tableFieldList = DbUtils.getTableColumns(info, tableInfoRequest.getId(), tableInfo.getTableName());
        //初始化列数据
        initFieldList(tableFieldList);
        //批量保存列数据
        Result tableFieldSaveResult = genTableFieldService.saveBatch(tableFieldList);
        if (!tableFieldSaveResult.isSuccess()) {
            log.error("保存列数据失败:request = {}", tableFieldList);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        try {
            //释放数据源
            info.getConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateTableField(Long tableId, List<GenTableFieldRequest> tableFieldList) {
        log.info("修改列数据:tableId = {},tableFieldList = {}", tableId, tableFieldList);
        //删除旧列信息
        Result result = genTableFieldService.deleteBatchTableIds(Collections.singletonList(tableId));
        if (!result.isSuccess()) {
            log.error("修改列数据失败:删除列数据失败tableId = {},tableFieldList = {}", tableId, tableFieldList);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        //保存新列数据
        int sort = 0;
        for (GenTableFieldRequest tableField : tableFieldList) {
            tableField.setSort(sort++);
            Result saveResult = genTableFieldService.save(tableField);
            if (!saveResult.isSuccess()) {
                log.error("保存列数据失败:request = {}", tableField);
                throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
            }
        }
    }

    /**
     * 初始化列数据
     */
    private void initFieldList(List<GenTableField> tableFieldList) {
        //字段类型、属性类型映射
        log.info("初始化列数据:request = {}", tableFieldList);
        Map<String, GenFieldType> fieldTypeMap = genFieldTypeService.getMap();
        if (MapUtils.isEmpty(fieldTypeMap)) {
            log.error("初始化列数据异常:返回数据为空");
            return;
        }
        int index = 0;
        for (GenTableField tableField : tableFieldList) {
            tableField.setAttrName(StringUtils.uncapitalize(GenUtils.columnToJava(tableField.getColumnName())));
            //获取字段对应的类型
            GenFieldType fieldTypeMapping = fieldTypeMap.get(tableField.getColumnType().toLowerCase());
            if (fieldTypeMapping == null) {
                //没找到对应的类型，则为Object类型
                tableField.setAttrType("Object");
            } else {
                tableField.setAttrType(fieldTypeMapping.getAttrType());
                tableField.setPackageName(fieldTypeMapping.getPackageName());
            }

            tableField.setList(true);
            tableField.setForm(true);

            tableField.setQueryType("=");
            tableField.setFormType("text");

            tableField.setSort(index++);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result generatorCode(TableInfoRequest request) {
        log.info("代码生成:request = {}", request);
        Result result = genTableInfoService.update(request);
        if (!result.isSuccess()) {
            log.info("修改表信息失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        //删除旧表信息
        Result deleteResult = genTableInfoService.deleteByTableName(request.getTableName());
        if (!deleteResult.isSuccess()) {
            log.error("删除旧表信息失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        //删除旧列信息
        Result tableFieldResult = genTableFieldService.deleteByTableName(request.getTableName());
        if (!tableFieldResult.isSuccess()) {
            log.error("删除旧列信息失败:request = {}", request);
        }

        //保存新表信息
        Result saveResult = genTableInfoService.save(request);
        if (!saveResult.isSuccess()) {
            log.error("保存表信息失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        //保存新列信息
        Result saveBatchResult = genTableFieldService.saveBatch(request.getFields());
        if (!saveBatchResult.isSuccess()) {
            log.error("保存新列信息失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        //数据模型
        Map<String, Object> dataModel = new HashMap<>();
        //项目信息
        dataModel.put("package", request.getPackageName());
        dataModel.put("packagePath", request.getPackageName().replace(".", File.separator));
        dataModel.put("version", request.getVersion());
        dataModel.put("moduleName", request.getModuleName());

        String subModuleName = request.getSubModuleName();
        if (StringUtils.isBlank(subModuleName)) {
            subModuleName = null;
        }
        dataModel.put("subModuleName", subModuleName);
        dataModel.put("backendPath", request.getBackendPath());
        dataModel.put("frontendPath", request.getFrontendPath());
        //开发者信息
        dataModel.put("author", request.getAuthor());
        dataModel.put("email", request.getEmail());
        dataModel.put("datetime", DateUtils.format(new Date(), DateUtils.DATE_TIME_PATTERN));
        dataModel.put("date", DateUtils.format(new Date(), DateUtils.DATE_PATTERN));
        //表信息
        dataModel.put("tableName", request.getTableName());
        dataModel.put("tableComment", request.getTableComment());
        dataModel.put("ClassName", request.getClassName());
        dataModel.put("className", StringUtils.uncapitalize(request.getClassName()));
        dataModel.put("classname", request.getClassName().toLowerCase());
        dataModel.put("columnList", request.getFields());

        //主键
        for (GenTableField tableField : request.getFields()) {
            if (tableField.isPk()) {
                dataModel.put("pk", tableField);
                break;
            }
        }

        //导入的包列表
        Result<Set<String>> packageResult = genFieldTypeService.getPackageListByTableId(request.getId());
        if (!packageResult.isSuccess()) {
            log.error("导入包列表失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        Set<String> imports = packageResult.getData();
        //过滤为空的数据
        imports = imports.stream().filter(i -> StringUtils.isNotBlank(i)).collect(Collectors.toSet());
        dataModel.put("imports", imports);

        //基类
        if (request.getBaseclassId() != null) {
            Result<GenBaseClass> baseClassResult = genBaseClassService.findById(request.getBaseclassId());
            if (!baseClassResult.isSuccess()) {
                log.error("id查询基类失败:id = {}", request.getBaseclassId());
                throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
            }

            GenBaseClass genBaseClass = baseClassResult.getData();
            genBaseClass.setPackageName(GenUtils.getTemplateContent(genBaseClass.getPackageName(), dataModel));
            dataModel.put("baseClassEntity", genBaseClass);
        }

        //获取模板
        Result<List<GenTemplate>> templateResult = genTemplateService.selectBySelective(new GenTemplateRequest());
        if (!templateResult.isSuccess()) {
            log.error("获取模板异常:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        List<GenTemplate> templateList = templateResult.getData();
        //渲染模板并输出
        for (GenTemplate template : templateList) {
            dataModel.put("templateName", template.getName());
            String content = GenUtils.getTemplateContent(template.getContent(), dataModel);
            String path = GenUtils.getTemplateContent(template.getPath(), dataModel) + File.separator +
                    GenUtils.getTemplateContent(template.getFileName(), dataModel);
            FileUtil.writeUtf8String(content, path);
            log.info(path);
        }
        return Result.ok();
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result generatorMenu(SysMenuRequest request) {
        log.info("生成菜单请求参数:request = {}", request);
        Result result = verifyUserDetail(request, "生成菜单");
        if (!result.isSuccess()) {
            return Result.fail(result.getCode(), result.getMessage());
        }

        Integer sort = 0;
        String url = request.getModuleName() + "/" + request.getClassName().toLowerCase();
        String permission = request.getModuleName() + ":" + request.getClassName().toLowerCase();
        request.setMenuType(0);
        request.setSort(sort);
        request.setUrl(url);
        request.setOpenStyle(0);
        String name = request.getName();
        request.setPermissions(permission);

        //菜单id
        Result saveResult = sysMenuService.save(request);
        log.info("菜单生成:添加菜单主菜单结束,返回值:saveResult = {}", saveResult);
        if (!saveResult.isSuccess()) {
            log.info("添加菜单失败:request = {}", request);
            return Result.fail(saveResult.getCode(), saveResult.getMessage());
        }

        Long menuId = request.getId();

        //菜单
        SysLanguage sysLanguage = new SysLanguage();
        sysLanguage.setLanguage("en-US");
        sysLanguage.setTableName("sys_menu");
        sysLanguage.setFieldName("name");
        sysLanguage.setFieldValue(name);
        sysLanguage.setTableId(menuId);
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setLanguage("zh-CN");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setLanguage("zh-TW");
        sysLanguageService.saveOrUpdate(sysLanguage);

        //查看
        request.setId(null);
        request.setPid(menuId);
        request.setPermissions(permission + ":page," + permission + ":info");
        request.setIcon(null);
        request.setMenuType(1);
        Result saveFindResult = sysMenuService.save(request);
        log.info("菜单生成:添加查询菜单结束,返回值:saveResult = {}", saveResult);
        if (!saveFindResult.isSuccess()) {
            log.info("添加查询菜单失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }


        sysLanguage.setFieldValue("View");
        sysLanguage.setLanguage("en-US");
        sysLanguageService.saveOrUpdate(sysLanguage);

        sysLanguage.setFieldValue("查看");
        sysLanguage.setLanguage("zh-CN");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setLanguage("zh-TW");
        sysLanguageService.saveOrUpdate(sysLanguage);

        //新增
        request.setId(null);
        request.setPermissions(permission + ":save");
        request.setSort(++sort);
        Result menuSaveResult = sysMenuService.save(request);
        log.info("菜单生成:添加新增菜单结束,返回值:saveResult = {}", saveResult);
        if (!menuSaveResult.isSuccess()) {
            log.info("添加新增菜单失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        sysLanguage.setFieldValue("Add");
        sysLanguage.setLanguage("en-US");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setFieldValue("新增");
        sysLanguage.setLanguage("zh-CN");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setLanguage("zh-TW");
        sysLanguageService.saveOrUpdate(sysLanguage);

        //修改
        request.setId(null);
        request.setPermissions(permission + ":update");
        request.setSort(++sort);
        Result updateResult = sysMenuService.save(request);
        log.info("菜单生成:添加修改菜单结束,返回值:saveResult = {}", saveResult);
        if (!updateResult.isSuccess()) {
            log.info("添加修改菜单失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        sysLanguage.setFieldValue("Edit");
        sysLanguage.setLanguage("en-US");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setFieldValue("修改");
        sysLanguage.setLanguage("zh-CN");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setLanguage("zh-TW");
        sysLanguageService.saveOrUpdate(sysLanguage);

        //删除
        request.setId(null);
        request.setPermissions(permission + ":delete");
        request.setSort(++sort);
        Result deleteResult = sysMenuService.save(request);
        log.info("菜单生成:添加删除菜单结束,返回值:saveResult = {}", saveResult);
        if (!deleteResult.isSuccess()) {
            log.info("添加删除菜单失败:request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        sysLanguage.setFieldValue("Delete");
        sysLanguage.setLanguage("en-US");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setFieldValue("删除");
        sysLanguage.setLanguage("zh-CN");
        sysLanguageService.saveOrUpdate(sysLanguage);
        sysLanguage.setLanguage("zh-TW");
        sysLanguageService.saveOrUpdate(sysLanguage);

        return Result.ok();
    }

}
