package com.github.admin.server.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.entity.SysUserToken;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.enums.SuperAdminEnum;
import com.github.admin.common.enums.SysTypeEnums;
import com.github.admin.common.enums.SysTypeStatusEnums;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.utils.PasswordUtils;
import com.github.admin.server.dao.SysUserDao;
import com.github.admin.server.dao.SysUserTokenDao;
import com.github.admin.server.service.MerchantAgentService;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantAgentServiceClient;
import com.github.admin.common.entity.UserDetail;
import com.github.trans.front.common.constants.TransConstants;
import com.github.trans.front.common.entity.MerchantAgent;
import com.github.trans.front.common.enums.AgentStatusEnums;
import com.github.trans.front.common.enums.PaymentErrorMsgEnums;
import com.github.trans.front.common.request.MerchantAgentRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MerchantAgentServiceImpl implements MerchantAgentService {

    @Resource
    private SysUserDao sysUserDao;

    @Resource
    private SysUserTokenDao sysUserTokenDao;


    @Resource
    private MerchantAgentServiceClient merchantAgentServiceClient;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result save(MerchantAgentRequest request) {
        Result checked = checkSaveParams(request);
        if (!checked.isSuccess()){
            return checked;
        }
        String password = request.getPassword();
        String agentAccount = request.getAgentAccount();
        UserDetail userDetail = request.getUserDetail();
        String userDetailUsername = userDetail.getUsername();
        Integer status = request.getStatus();

        SysUserRequest sysUserRequest = new SysUserRequest();
        sysUserRequest.setUsername(agentAccount);
        sysUserRequest.setSysType(SysTypeEnums.agent.value());
        SysUser user = sysUserDao.getByUsername(sysUserRequest);
        if (user != null){
            log.error("添加商户代理名称:agentUname已存在");
            return Result.fail(AdminErrorMsgEnum.USER_NAME_ALREADY_EXISTS);
        }
        //密码加密
        String newPassword = PasswordUtils.encode(password);
        request.setPassword(newPassword);
        request.setRevision(TransConstants.REVERSION);

        //保存用户
        SysUser sysUser = new SysUser();
        sysUser.setUsername(agentAccount);
        sysUser.setPassword(newPassword);
        sysUser.setSuperAdmin(SuperAdminEnum.YES.value());
        sysUser.setSysType(SysTypeEnums.agent.value());
        sysUser.setStatus(SysTypeStatusEnums.STOP.value());
        if (status == AgentStatusEnums.START.value()){
            sysUser.setStatus(SysTypeStatusEnums.START.value());
        }
        SysUser selectResult = sysUserDao.selectByUsername(sysUser);
        if (selectResult != null){
            log.error("保存代理,查询用户已存在");
            return Result.fail(AdminErrorMsgEnum.USER_NAME_ALREADY_EXISTS);
        }
        int row = sysUserDao.insertSelective(sysUser);
        if (row != 1) {
            log.error("添加用户失败:request = {}", sysUser);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        request.setSysUserId(sysUser.getId());
        request.setCreateUser(userDetailUsername);
        request.setModifiedUser(userDetailUsername);
        log.info("开始调用添加商户代理请求对象:request = {}", JSON.toJSONString(request));
        Result result = merchantAgentServiceClient.saveMerchantAgent(request);
        if (!result.isSuccess()){
            log.error("添加商户代理失败:result = {}", JSON.toJSONString(result));
            throw Ex.business(result.getCode(),result.getMessage());
        }
        return Result.ok();
    }

    private Result checkSaveParams(MerchantAgentRequest request) {
        log.info("添加商户代理请求对象:request = {}", JSON.toJSONString(request));
        if (request == null){
            log.error("添加商户代理请求对象:request为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        String agentName = request.getAgentName();
        String password = request.getPassword();
        String agentAccount = request.getAgentAccount();
        String email = request.getEmail();
        Integer status = request.getStatus();

        if (StringUtils.isBlank(agentAccount)){
            log.error("添加商户代理名称:agentAccount为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_ACCOUNT_IS_EMPTY);
        }
        if (StringUtils.isBlank(agentName)){
            log.error("添加商户代理名称:agentName为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_NAME_IS_EMPTY);
        }
        if (StringUtils.isBlank(email)){
            log.error("添加商户代理名称:email为空");
            return Result.fail(AdminErrorMsgEnum.EMAIL_IS_EMPTY);
        }
        if (status == null){
            log.error("添加商户代理:status为空");
            return Result.fail(AdminErrorMsgEnum.STATUS_IS_EMPTY);
        }

        if (!password.trim().equals(password)){
            log.error("添加商户代理:password出现空格");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_CONTAINS_SPACE);
        }
        if (!email.matches(TransConstants.EMAIL_REGEXP)){
            log.error("添加商户代理名称:email不合格");
            return Result.fail(AdminErrorMsgEnum.EMAIL_IS_NOT_MEET_SPECIFICATIONS);
        }

        UserDetail userDetail = request.getUserDetail();
        if (userDetail == null){
            log.error("添加商户代理获取当前登录人信息异常:userDetail为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        String userDetailUsername = userDetail.getUsername();
        if (StringUtils.isBlank(userDetailUsername)){
            log.error("添加商户代理获取当前登录人信息:userDetailUsername为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }

        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result update(MerchantAgentRequest request) {
        Result result = checkParams(request);
        if (!result.isSuccess()){
            log.error("修改商户代理参数校验失败:result = {}", JSON.toJSONString(result));
            return result;
        }
        Long id = request.getId();

        String agentAccount = request.getAgentAccount();
        Integer status = request.getStatus();
        UserDetail userDetail = request.getUserDetail();
        String userDetailUsername = userDetail.getUsername();
        if (StringUtils.isBlank(agentAccount)){
            log.error("添加商户代理名称:agentAccount为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_ACCOUNT_IS_EMPTY);
        }
        log.info("修改商户代理查询绑定的系统用户");
        Result<MerchantAgent> agentResult = merchantAgentServiceClient.findById(id);
        if (!agentResult.isSuccess()){
            log.error("修改商户代理查询绑定的系统用户失败:result = {}", JSON.toJSONString(agentResult));
            return agentResult;
        }
        MerchantAgent merchantAgent = agentResult.getData();
        Long sysUserId = merchantAgent.getSysUserId();

        if (sysUserId == null){
            log.error("修改商户代理查询绑定的系统用户失败:sysUserId为空");
            return Result.fail(AdminErrorMsgEnum.SYSTEM_USERID_IS_EMPTY);
        }
        Date date = new Date();
        request.setModifiedUser(userDetailUsername);
        request.setRevision(TransConstants.REVERSION);
        SysUser user = new SysUser();
        user.setId(sysUserId);
        user.setUsername(agentAccount);
        user.setStatus(SysTypeStatusEnums.STOP.value());
        if (status == AgentStatusEnums.START.value()){
            user.setStatus(SysTypeStatusEnums.START.value());
        }
        user.setUpdateDate(date);
        user.setModifiedUser(userDetailUsername);
        user.setSysType(SysTypeEnums.agent.value());
        SysUser selectResult = sysUserDao.selectByUsername(user);
        if (selectResult != null && !StringUtils.equals(selectResult.getId().toString(),sysUserId.toString())){
            log.error("修改代理,查询用户已存在");
            return Result.fail(AdminErrorMsgEnum.USER_NAME_ALREADY_EXISTS);
        }
        log.info("修改商户代理更新商户对应的系统用户信息");
        int updateRow = sysUserDao.updateByPrimaryKeySelective(user);
        if (updateRow == 0){
            log.error("修改商户代理信息更新商户对应的系统用户信息失败:updateRow = {}", updateRow);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        log.info("修改商户代理信息:request = {}",JSON.toJSONString(request));
        Result updateMerchantAgentResult = merchantAgentServiceClient.update(request);
        if (!updateMerchantAgentResult.isSuccess()){
            log.error("修改商户代理失败:updateMerchantAgentResult = {}", JSON.toJSONString(updateMerchantAgentResult));
            throw Ex.business(updateMerchantAgentResult.getCode(),updateMerchantAgentResult.getMessage());
        }
        return Result.ok();
    }

    private Result checkParams(MerchantAgentRequest request) {
        log.info("修改商户代理请求对象:request = {}", JSON.toJSONString(request));
        if (request == null){
            log.error("修改商户代理请求对象:request为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        Long id = request.getId();
        String agentName = request.getAgentName();

        String email = request.getEmail();
        Integer status = request.getStatus();
        if (id == null){
            log.error("修改商户代理:id为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_ID_IS_EMPTY);
        }
        UserDetail userDetail = request.getUserDetail();
        if (userDetail == null){
            log.error("修改商户代理获取当前登录人信息异常:userDetail为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        String userDetailUsername = userDetail.getUsername();
        if (StringUtils.isBlank(userDetailUsername)){
            log.error("修改商户代理获取当前登录人信息:userDetailUsername为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        if (StringUtils.isBlank(agentName)){
            log.error("添加商户代理名称:agentName为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_NAME_IS_EMPTY);
        }
        if (status == null){
            log.error("修改商户代理状态:status为空");
            return Result.fail(AdminErrorMsgEnum.STATUS_IS_EMPTY);
        }
        if (StringUtils.isBlank(email)){
            log.error("修改商户代理名称:email为空");
            return Result.fail(AdminErrorMsgEnum.EMAIL_IS_EMPTY);
        }
        if (!email.matches(TransConstants.EMAIL_REGEXP)){
            log.error("添加商户代理名称:email不合格");
            return Result.fail(AdminErrorMsgEnum.EMAIL_IS_NOT_MEET_SPECIFICATIONS);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result delete(MerchantAgentRequest request) {
        List<Long> ids = request.getIds();
        if (CollectionUtil.isEmpty(ids)){
            log.error("删除商户代理:ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        UserDetail userDetail = request.getUserDetail();
        if (userDetail == null){
            log.error("删除商户代理获取当前登录人信息异常:userDetail为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        String userDetailUsername = userDetail.getUsername();
        if (StringUtils.isBlank(userDetailUsername)){
            log.error("删除商户代理获取当前登录人信息:userDetailUsername为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }

        Date date = new Date();
        request.setModifiedUser(userDetailUsername);

        Result<List<MerchantAgent>> listResult = merchantAgentServiceClient.findByIds(request);
        if (!listResult.isSuccess()){
            log.error("删除商户代理:查询商户代理失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        List<MerchantAgent> merchantAgents = listResult.getData();
        List<Long> sysUserIds = merchantAgents.stream().map(MerchantAgent::getSysUserId).collect(Collectors.toList());
        SysUser user = new SysUser();
        user.setModifiedUser(userDetailUsername);
        user.setUpdateDate(date);
        user.setIds(sysUserIds);
        long row = sysUserDao.updateBySelective(user);
        if (row == 0){
            log.error("删除商户代理,删除商户代理对应的系统用户失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        Result deleteResult = merchantAgentServiceClient.delete(request);
        if (!deleteResult.isSuccess()){
            log.error("删除商户代理:删除商户代理失败");
            String code = deleteResult.getCode();
            throw Ex.business(PaymentErrorMsgEnums.of(code));
        }
        return Result.ok();
    }

    @Override
    public Result updateAgentPassword(MerchantAgentRequest request) {
        Long agentId = request.getId();
        String password = request.getPassword();
        if (StringUtils.isBlank(password)){
            log.error("修改代理商户密码:password为空");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_IS_EMPTY);
        }
        if (agentId == null){
            log.error("修改商户代理资金密码:agentId为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_ID_IS_EMPTY);
        }
        if (!password.trim().equals(password)){
            log.error("修改商户代理:password出现空格");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_CONTAINS_SPACE);
        }
        Result<MerchantAgent> agentResult = merchantAgentServiceClient.findById(agentId);
        if (!agentResult.isSuccess()){
            log.error("修改商户代理密码查询商户代理失败");
            return agentResult;
        }
        MerchantAgent merchantAgent = agentResult.getData();
        SysUser sysUser = sysUserDao.selectByPrimaryKey(merchantAgent.getSysUserId());
        if (sysUser == null){
            log.error("修改商户代理密码查询系统用户数据不存在");
            return Result.fail(PaymentErrorMsgEnums.DATA_IS_NOT_EXIST);
        }
        String newPassword = PasswordUtils.encode(password);
        SysUser user = new SysUser();
        user.setId(merchantAgent.getSysUserId());
        user.setPassword(newPassword);
        int row = sysUserDao.updateByPrimaryKeySelective(user);
        if (row == 0){
            log.error("修改商户代理密码操作失败");
            return Result.fail(PaymentErrorMsgEnums.OPERATION_FAIL);
        }
        SysUserToken sysUserToken = new SysUserToken();
        sysUserToken.setUserId(merchantAgent.getSysUserId());
        sysUserTokenDao.deleteBySelective(sysUserToken);
        return Result.ok();
    }

    @Override
    public Result updateAgentFundPassword(MerchantAgentRequest request) {
        Long agentId = request.getId();
        String fundPassword = request.getFundPassword();

        if (StringUtils.isBlank(fundPassword)){
            log.error("修改商户代理资金密码:fundPassword为空");
            return Result.fail(AdminErrorMsgEnum.FUND_PASSWORD_IS_EMPTY);
        }
        if (agentId == null){
            log.error("修改商户代理资金密码:agentId为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_ID_IS_EMPTY);
        }
        if (!fundPassword.trim().equals(fundPassword)){
            log.error("修改商户代理:fundPassword出现空格");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_CONTAINS_SPACE);
        }
        String newFundPassword = PasswordUtils.encode(fundPassword);
        request.setFundPassword(newFundPassword);
        Result result = merchantAgentServiceClient.update(request);
        if (!result.isSuccess()){
            log.error("修改商户代理资金密码操作失败:request = {}",JSON.toJSONString(request));
            String code = result.getCode();
            throw Ex.business(PaymentErrorMsgEnums.of(code));
        }
        return Result.ok();
    }

    @Override
    public Result<MerchantAgent> findById(Long id) {
        if (id == null){
            log.error("根据id查询商户代理,请求数据id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        Result<MerchantAgent> agentResult = merchantAgentServiceClient.findById(id);
        if (!agentResult.isSuccess()){
            log.error("根据id查询商户代理操作失败,请求参数:id = {}",id);
            return agentResult;
        }
        MerchantAgent merchantAgent = agentResult.getData();
        Long sysUserId = merchantAgent.getSysUserId();
        SysUser sysUser = sysUserDao.selectByPrimaryKey(sysUserId);
        if (sysUser == null){
            log.error("根据id查询商户代理,查询登录用户信息不存在,请求参数:sysUserId = {}",sysUserId);
            return Result.fail(PaymentErrorMsgEnums.DATA_IS_NOT_EXIST);
        }
        merchantAgent.setAgentAccount(sysUser.getUsername());
        return Result.ok(merchantAgent);
    }

    @Override
    public Result<DataPage<MerchantAgent>> page(MerchantAgentRequest request) {
        Result<DataPage<MerchantAgent>> result = merchantAgentServiceClient.page(request);
        if (!result.isSuccess()){
            log.error("分页查询商户代理操作失败,请求数据:request = {}",JSON.toJSONString(request));
            return result;
        }
        DataPage<MerchantAgent> data = result.getData();
        List<MerchantAgent> dataList = data.getDataList();
        if (CollectionUtil.isNotEmpty(dataList)){
            for (MerchantAgent merchantAgent : dataList) {
                SysUser sysUser = sysUserDao.selectByPrimaryKey(merchantAgent.getSysUserId());
                if (sysUser != null){
                    merchantAgent.setAgentAccount(sysUser.getUsername());
                }
            }
        }
        return Result.ok(data);
    }
}
