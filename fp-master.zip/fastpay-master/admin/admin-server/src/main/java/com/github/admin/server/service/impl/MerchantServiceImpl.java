package com.github.admin.server.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.entity.SysUserToken;
import com.github.admin.common.entity.UserDetail;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.enums.SuperAdminEnum;
import com.github.admin.common.enums.SysTypeEnums;
import com.github.admin.common.enums.SysTypeStatusEnums;
import com.github.admin.common.request.SysUserRequest;
import com.github.admin.common.utils.PasswordUtils;
import com.github.admin.server.dao.SysUserDao;
import com.github.admin.server.dao.SysUserTokenDao;
import com.github.admin.server.service.MerchantService;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import com.github.trans.front.client.MerchantAgentServiceClient;
import com.github.trans.front.client.MerchantServiceClient;
import com.github.trans.front.common.constants.TransConstants;
import com.github.trans.front.common.entity.Merchant;
import com.github.trans.front.common.entity.MerchantAgent;
import com.github.trans.front.common.enums.PaymentErrorMsgEnums;
import com.github.trans.front.common.request.MerchantRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.github.admin.common.utils.GenerateMerchantNoUtils.generateMerchantNo;

@Service
@Slf4j
public class MerchantServiceImpl implements MerchantService {

    @Resource
    private SysUserDao sysUserDao;

    @Resource
    private SysUserTokenDao sysUserTokenDao;

    @Resource
    private MerchantAgentServiceClient merchantAgentServiceClient;

    @Resource
    private MerchantServiceClient merchantServiceClient;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result save(MerchantRequest request) {
        Result result = checkSaveParams(request);
        if (!result.isSuccess()){
            return result;
        }
        String merchantAccount = request.getMerchantAccount();
        Long agentId = request.getAgentId();
        String password = request.getPassword();
        Integer status = request.getStatus();

        UserDetail userDetail = request.getUserDetail();
        String userDetailUsername = userDetail.getUsername();

        request.setCreateUser(userDetailUsername);
        request.setModifiedUser(userDetailUsername);
        SysUserRequest sysUserRequest = new SysUserRequest();
        sysUserRequest.setUsername(merchantAccount);
        sysUserRequest.setSysType(SysTypeEnums.merchant.value());
        SysUser user = sysUserDao.getByUsername(sysUserRequest);
        if (user != null){
            log.error("添加商户名称:merchantUname已存在");
            return Result.fail(AdminErrorMsgEnum.USER_NAME_ALREADY_EXISTS);
        }
        if (agentId == null){
            log.error("添加商户的商户代理ID:agentId为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        Result<MerchantAgent> agentResult = merchantAgentServiceClient.findById(agentId);
        log.info("添加商户查询商户代理结果:result = {}", JSON.toJSONString(agentResult));
        if (!agentResult.isSuccess()){
            log.error("添加商户查询商户代理结果失败:result = {}", JSON.toJSONString(agentResult));
            String code = agentResult.getCode();
            throw Ex.business(PaymentErrorMsgEnums.of(code));
        }
        MerchantAgent merchantAgent = agentResult.getData();
        request.setAgentName(merchantAgent.getAgentName());
        //密码加密
        String newPassword = PasswordUtils.encode(password);
        request.setPassword(newPassword);
        //保存用户
        SysUser sysUser = new SysUser();
        sysUser.setUsername(merchantAccount);
        sysUser.setPassword(newPassword);
        sysUser.setSuperAdmin(SuperAdminEnum.YES.value());
        sysUser.setSysType(SysTypeEnums.merchant.value());
        sysUser.setStatus(SysTypeStatusEnums.STOP.value());
        if (status == SysTypeStatusEnums.START.value()){
            sysUser.setStatus(SysTypeStatusEnums.START.value());
        }
        SysUser selectResult = sysUserDao.selectByUsername(sysUser);
        if (selectResult != null){
            log.error("保存商户,查询用户已存在,请求数据:request = {}",JSON.toJSONString(request));
            return Result.fail(AdminErrorMsgEnum.USER_NAME_ALREADY_EXISTS);
        }
        log.info("添加商户保存用户请求对象:sysUser = {}", JSON.toJSONString(sysUser));
        int row = sysUserDao.insertSelective(sysUser);
        if (row != 1) {
            log.error("添加用户失败:request = {}", sysUser);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        request.setSysUserId(sysUser.getId());
        request.setMerchantNo(generateMerchantNo());
        request.setRevision(TransConstants.REVERSION);
        Result<Merchant> saveMerchantResult = merchantServiceClient.save(request);
        if (!saveMerchantResult.isSuccess()){
            log.error("添加商户失败:result = {}", JSON.toJSONString(saveMerchantResult));
            String code = saveMerchantResult.getCode();
            throw Ex.business(PaymentErrorMsgEnums.of(code));
        }
        return Result.ok();
    }

    private Result checkSaveParams(MerchantRequest request) {
        log.info("添加商户请求对象:request = {}", JSON.toJSONString(request));
        if (request == null){
            log.error("添加商户请求对象request为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        String merchantName = request.getMerchantName();
        String merchantAccount = request.getMerchantAccount();
        Long agentId = request.getAgentId();
        String password = request.getPassword();
        String mobile = request.getMobile();
        Integer status = request.getStatus();
        if (StringUtils.isBlank(merchantAccount)){
            log.error("添加商户名称:merchantAccount为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_ACCOUNT_IS_EMPTY);
        }
        if (StringUtils.isBlank(merchantName)){
            log.error("添加商户名称:merchantName为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_NAME_IS_EMPTY);
        }
        if (StringUtils.isBlank(password)){
            log.error("添加商户密码:password为空");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_IS_EMPTY);
        }
        if (status == null){
            log.error("添加商户:status为空");
            return Result.fail(AdminErrorMsgEnum.STATUS_IS_EMPTY);
        }
        if (!password.trim().equals(password)){
            log.error("添加商户:password出现空格");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_CONTAINS_SPACE);
        }
        UserDetail userDetail = request.getUserDetail();
        if (userDetail == null){
            log.error("添加商户获取当前登录人信息:userDetail为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        String userDetailUsername = userDetail.getUsername();
        if (StringUtils.isBlank(userDetailUsername)){
            log.error("添加商户获取当前登录人信息:userDetailUsername为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        if (agentId == null){
            log.error("添加商户,代理:agentId为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_ID_IS_EMPTY);
        }

        if (StringUtils.isBlank(mobile)){
            log.error("添加商户,手机号:mobile为空");
            return Result.fail(AdminErrorMsgEnum.PHONE_IS_EMPTY);
        }

        if (!mobile.matches(TransConstants.PHONE_REGEXP)){
            log.error("添加商户,手机号:mobile不符合");
            return Result.fail(AdminErrorMsgEnum.PHONE_IS_NOT_MEET_SPECIFICATIONS);
        }
        return Result.ok();
    }

    @Override
    public Result update(MerchantRequest request) {
        Result checkResult = checkParams(request);
        if (!checkResult.isSuccess()){
            return checkResult;
        }
        String merchantAccount = request.getMerchantAccount();
        Long agentId = request.getAgentId();
        Long merchantId = request.getId();
        Integer status = request.getStatus();

        if (StringUtils.isBlank(merchantAccount)){
            log.error("添加商户名称:merchantAccount为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_ACCOUNT_IS_EMPTY);
        }

        UserDetail userDetail = request.getUserDetail();
        String userDetailUsername = userDetail.getUsername();
        if (StringUtils.isBlank(userDetailUsername)){
            log.error("修改商户获取当前登录人信息:userDetailUsername为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        log.info("修改商户获取当前登录人信息:userDetail = {}", JSON.toJSONString(userDetail));
        Date date = new Date();
        request.setModifiedUser(userDetailUsername);

        Result<Merchant> merchantResult = merchantServiceClient.findById(merchantId);
        if (!merchantResult.isSuccess()){
            log.error("修改商户信息查询商户信息失败:result = {}", JSON.toJSONString(merchantResult));
            return merchantResult;
        }
        Merchant merchant = merchantResult.getData();
        Long sysUserId = merchant.getSysUserId();
        if (sysUserId == null){
            log.error("修改商户信息查询商户对应的系统用户信息失败:sysUserId为空");
            return Result.fail(AdminErrorMsgEnum.SYSTEM_USERID_IS_EMPTY);
        }
        Result<MerchantAgent> agentResult = merchantAgentServiceClient.findById(agentId);
        log.info("修改商户查询商户代理结果:result = {}", JSON.toJSONString(agentResult));
        if (!agentResult.isSuccess()){
            log.error("修改商户查询商户代理结果失败:result = {}", JSON.toJSONString(agentResult));
            throw Ex.business(agentResult.getCode(),agentResult.getMessage());
        }
        MerchantAgent merchantAgent = agentResult.getData();
        request.setAgentName(merchantAgent.getAgentName());
        request.setRevision(TransConstants.REVERSION);
        SysUser user = new SysUser();
        user.setId(sysUserId);
        user.setUsername(merchantAccount);
        user.setStatus(1);
        if (status == 2){
            user.setStatus(0);
        }
        user.setUpdateDate(date);
        user.setModifiedUser(userDetailUsername);
        user.setSysType(2);
        SysUser selectResult = sysUserDao.selectByUsername(user);
        if (selectResult != null && !StringUtils.equals(selectResult.getId().toString(),sysUserId.toString())){
            log.error("修改商户,查询用户已存在,请求数据:request = {}",JSON.toJSONString(request));
            return Result.fail(AdminErrorMsgEnum.USER_NAME_ALREADY_EXISTS);
        }
        int updateRow = sysUserDao.updateByPrimaryKeySelective(user);
        if (updateRow == 0){
            log.error("修改商户信息更新商户对应的系统用户信息失败:updateRow = {}", updateRow);
            return Result.fail(AdminErrorMsgEnum.UPDATE_MERCHANT_ERROR);
        }

        Result<Merchant> updateMerchantResult = merchantServiceClient.update(request);
        if (!updateMerchantResult.isSuccess()){
            log.error("修改商户失败:result = {}", JSON.toJSONString(updateMerchantResult));
            throw Ex.business(updateMerchantResult.getCode(),updateMerchantResult.getMessage());
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result delete(MerchantRequest request) {
        List<Long> ids = request.getIds();
        if (CollectionUtil.isEmpty(ids)){
            log.error("删除商户:ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        UserDetail userDetail = request.getUserDetail();
        if (userDetail == null){
            log.error("删除商户获取当前登录人信息异常:userDetail为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        String userDetailUsername = userDetail.getUsername();
        if (StringUtils.isBlank(userDetailUsername)){
            log.error("删除商户获取当前登录人信息:userDetailUsername为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }

        Date date = new Date();
        request.setModifiedUser(userDetailUsername);

        Result<List<Merchant>> listResult = merchantServiceClient.findByIds(request);
        if (!listResult.isSuccess()){
            log.error("删除商户:查询商户失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        List<Merchant> merchants = listResult.getData();
        List<Long> sysUserIds = merchants.stream().map(Merchant::getSysUserId).collect(Collectors.toList());
        SysUser user = new SysUser();
        user.setModifiedUser(userDetailUsername);
        user.setUpdateDate(date);
        user.setIds(sysUserIds);
        int row = sysUserDao.updateBySelective(user);
        if (row == 0){
            log.error("删除商户,删除商户对应的系统用户失败,请求参数:request = {}",JSON.toJSONString(user));
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        Result deleteResult = merchantServiceClient.delete(request);
        if (!deleteResult.isSuccess()){
            log.error("删除商户失败,请求参数:request = {}",JSON.toJSONString(request));
            throw Ex.business(PaymentErrorMsgEnums.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result updatePassword(MerchantRequest request) {
        Long merchantId = request.getId();
        String password = request.getPassword();
        if (StringUtils.isBlank(password)){
            log.error("修改商户密码:password为空");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_IS_EMPTY);
        }
        if (merchantId == null){
            log.error("修改商户资金密码:merchantId为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_ID_IS_EMPTY);
        }
        if (!password.trim().equals(password)){
            log.error("修改商户:password出现空格");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_CONTAINS_SPACE);
        }
        Result<Merchant> merchantResult = merchantServiceClient.findById(merchantId);
        if (!merchantResult.isSuccess()){
            log.error("修改商户密码查询商户信息失败");
            return merchantResult;
        }
        Merchant merchant = merchantResult.getData();
        SysUser sysUser = sysUserDao.selectByPrimaryKey(merchant.getSysUserId());
        if (sysUser == null){
            log.error("修改商户密码查询系统用户数据不存在");
            return Result.fail(PaymentErrorMsgEnums.DATA_IS_NOT_EXIST);
        }
        String newPassword = PasswordUtils.encode(password);
        SysUser user = new SysUser();
        user.setId(merchant.getSysUserId());
        user.setPassword(newPassword);
        int row = sysUserDao.updateByPrimaryKeySelective(user);
        if (row == 0){
            log.error("修改商户密码操作失败");
            return Result.fail(PaymentErrorMsgEnums.OPERATION_FAIL);
        }
        SysUserToken sysUserToken = new SysUserToken();
        sysUserToken.setUserId(merchant.getSysUserId());
        sysUserTokenDao.deleteBySelective(sysUserToken);
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result updateFundPassword(MerchantRequest request) {
        Long merchantId = request.getId();
        String fundPassword = request.getFundPassword();

        if (StringUtils.isBlank(fundPassword)){
            log.error("修改商户资金密码:fundPassword为空");
            return Result.fail(AdminErrorMsgEnum.FUND_PASSWORD_IS_EMPTY);
        }
        if (merchantId == null){
            log.error("修改商户资金密码:merchantId为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_ID_IS_EMPTY);
        }
        if (!fundPassword.trim().equals(fundPassword)){
            log.error("修改商户:fundPassword出现空格");
            return Result.fail(AdminErrorMsgEnum.PASSWORD_CONTAINS_SPACE);
        }
        String newFundPassword = PasswordUtils.encode(fundPassword);
        request.setFundPassword(newFundPassword);
        Result result = merchantServiceClient.update(request);
        if (!result.isSuccess()){
            log.error("修改商户资金密码操作失败:request = {}",JSON.toJSONString(request));
            String code = result.getCode();
            throw Ex.business(PaymentErrorMsgEnums.of(code));
        }
        return Result.ok();
    }

    @Override
    public Result<Merchant> findById(Long id) {
        if (id == null){
            log.error("根据id查询商户请求参数:id为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_ID_IS_EMPTY);
        }
        Result<Merchant> merchantResult = merchantServiceClient.findById(id);
        if (!merchantResult.isSuccess()){
            log.error("根据id查询商户操作失败,请求参数:id = {}",id);
            return merchantResult;
        }
        Merchant merchant = merchantResult.getData();
        Long sysUserId = merchant.getSysUserId();
        SysUser sysUser = sysUserDao.selectByPrimaryKey(sysUserId);
        if (sysUser == null){
            log.error("根据id查询商户,查询系统用户信息不存在,请求参数:sysUserId = {}",sysUserId);
            return Result.fail(AdminErrorMsgEnum.USER_NOT_EXISTS);
        }
        merchant.setMerchantAccount(sysUser.getUsername());
        return Result.ok(merchant);
    }

    @Override
    public Result<DataPage<Merchant>> page(MerchantRequest request) {
        Result<DataPage<Merchant>> result = merchantServiceClient.page(request);
        if (!result.isSuccess()){
            log.error("分页查询商户数据操作失败,请求数据:request = {}",JSON.toJSONString(request));
            return result;
        }
        DataPage<Merchant> data = result.getData();
        List<Merchant> dataList = data.getDataList();
        if (CollectionUtil.isNotEmpty(dataList)){
            for (Merchant merchant : dataList) {
                SysUser sysUser = sysUserDao.selectByPrimaryKey(merchant.getSysUserId());
                if (sysUser != null){
                    merchant.setMerchantAccount(sysUser.getUsername());
                }
            }
        }
        return Result.ok(data);
    }

    private Result checkParams(MerchantRequest request) {
        log.info("修改商户请求对象:request = {}", JSON.toJSONString(request));
        if (request == null){
            log.error("修改商户请求对象request为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        String merchantName = request.getMerchantName();
        Long agentId = request.getAgentId();
        Long merchantId = request.getId();
        Integer status = request.getStatus();
        String mobile = request.getMobile();

        if (merchantId == null){
            log.error("修改商户请求:merchantId为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_ID_IS_EMPTY);
        }
        if (status == null){
            log.error("修改商户请求:status为空");
            return Result.fail(AdminErrorMsgEnum.STATUS_IS_EMPTY);
        }
        if (StringUtils.isBlank(merchantName)){
            log.error("修改商户名称:merchantName为空");
            return Result.fail(AdminErrorMsgEnum.MERCHANT_NAME_IS_EMPTY);
        }
        UserDetail userDetail = request.getUserDetail();
        if (userDetail == null){
            log.error("修改商户获取当前登录人信息:userDetail为空");
            return Result.fail(AdminErrorMsgEnum.USER_INFORMATION_EXCEPTION);
        }
        if (agentId == null){
            log.error("修改商户的商户代理ID:agentId为空");
            return Result.fail(AdminErrorMsgEnum.AGENT_ID_IS_EMPTY);
        }
        if (StringUtils.isBlank(mobile)){
            log.error("添加商户,手机号:mobile为空");
            return Result.fail(AdminErrorMsgEnum.PHONE_IS_EMPTY);
        }

        if (!mobile.matches(TransConstants.PHONE_REGEXP)){
            log.error("添加商户,手机号:mobile不符合");
            return Result.fail(AdminErrorMsgEnum.PHONE_IS_NOT_MEET_SPECIFICATIONS);
        }
        return Result.ok();
    }

}
