package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.NewsRequest;
import com.github.admin.common.entity.TbNews;
import com.github.admin.server.dao.TbNewsDao;
import com.github.admin.server.service.NewsService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


@Service
@Slf4j
public class NewsServiceImpl implements NewsService {

    @Resource
    private TbNewsDao tbNewsDao;

    @Override
    public Result<DataPage<TbNews>> newsPage(NewsRequest request) {
        log.info("新闻管理查询分页请求参数：{}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<TbNews> dataPage = new DataPage<TbNews>(pageNo,pageSize);
        Map<String,Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex",dataPage.getStartIndex());
        map.put("offset",dataPage.getPageSize());
        long userCount = tbNewsDao.findTbNewsCountByPage(map);
        List<TbNews> list = tbNewsDao.findTbNewsListByPage(map);
        log.info("查询新闻管理大小数量totalCount:{}",userCount);
        dataPage.setTotalCount(userCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result save(NewsRequest request) {
        if (request == null){
            log.error("添加新闻管理请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        BaseRequestUtils.createAssemble(request);
        TbNews tbNews = new TbNews();
        BeanUtil.copyProperties(request,tbNews);
        int row = tbNewsDao.insertSelective(tbNews);
        if (row == 0){
            log.error("添加新闻管理操作失败，request = {}",tbNews);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result<TbNews> findById(Long id) {
        if (id == null){
            log.error("查询新闻管理请求id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        TbNews tbNews = tbNewsDao.selectByPrimaryKey(id);
        if (tbNews == null){
            log.error("查询新闻管理操作失败，id = {}",id);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok(tbNews);
    }

    @Override
    public Result update(NewsRequest request) {
        if (request == null){
            log.error("更新新闻管理请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        BaseRequestUtils.updateAssemble(request);
        TbNews tbNews = new TbNews();
        BeanUtil.copyProperties(request,tbNews);
        int row = tbNewsDao.updateByPrimaryKeySelective(tbNews);
        if (row == 0){
            log.error("更新新闻管理操作失败，request = {}",tbNews);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result delete(List<Long> ids) {
        if (CollectionUtil.isEmpty(ids)){
            log.error("删除新闻管理请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        int row = tbNewsDao.deleteByIds(ids);
        if (row == 0){
            log.error("添加新闻管理操作失败，ids = {}",ids);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }
}
