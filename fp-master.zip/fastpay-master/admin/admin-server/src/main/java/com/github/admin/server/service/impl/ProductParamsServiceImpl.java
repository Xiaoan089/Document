package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.github.admin.common.entity.TbProductParams;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.TbProductParamsRequest;
import com.github.admin.common.request.ProductRequest;
import com.github.admin.server.dao.TbProductParamsDao;
import com.github.admin.server.service.ProductParamsService;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * 产品参数管理
 */
@Service
@Slf4j
public class ProductParamsServiceImpl implements ProductParamsService {

    @Resource
    private TbProductParamsDao tbProductParamsDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result saveOrUpdate(ProductRequest request) {
        log.info("产品参数管理修改:请求参数request = {}", request);
        if (request == null) {
            log.error("产品参数管理修改:请求参数 为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_ERROR);
        }
        Long productId = request.getId();
        List<TbProductParamsRequest> list = request.getSubList();
        if (productId == null) {
            log.error("产品参数管理修改:请求参数 productId 为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_ERROR);
        }

        //先删除子表数据
        int row = tbProductParamsDao.deleteByPrimaryKey(productId);
        if (row != 1) {
            log.error("产品参数管理修改:删除失败,操作数据库失败, productId = {}", productId);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        if (CollUtil.isEmpty(list)) {
            return Result.ok();
        }

        //保存子表数据
        for (TbProductParamsRequest dto : list) {
            TbProductParamsRequest tbProductParamsRequest = new TbProductParamsRequest();
            tbProductParamsRequest.setUserDetail(request.getUserDetail());
            tbProductParamsRequest.setProductId(productId);
            tbProductParamsRequest.setParamName(dto.getParamName());
            tbProductParamsRequest.setParamValue(dto.getParamValue());
            TbProductParams entity = new TbProductParams();
            BeanUtil.copyProperties(entity, tbProductParamsRequest);

            //保存
            int saveRow = tbProductParamsDao.insertSelective(entity);
            if (saveRow != 1) {
                log.error("产品参数管理修改:新增失败,操作数据库失败, request = {}", entity);
                throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
            }
        }
        return Result.ok();
    }

    @Override
    public Result<List<TbProductParams>> selectBySelective(TbProductParamsRequest request) {
        log.info("查询子表数据列表:request = {}", request);
        // 查询子表数据列表
        TbProductParams tbProductParams = new TbProductParams();
        List<TbProductParams> list = null;
        if (request == null) {
            tbProductParamsDao.selectBySelective(null);
        }
        BeanUtil.copyProperties(request, tbProductParams);
        list = tbProductParamsDao.selectBySelective(tbProductParams);
        return Result.ok(list);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteByProductIds(List<Long> ids) {
        log.info("删除子表数据列表:ids = {}",ids);
        if (CollectionUtils.isEmpty(ids)) {
            log.error("删除子表数据列表请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        int row = tbProductParamsDao.deleteByProductIds(ids);
        if (row != ids.size()) {
            log.error("删除子表数据列表失败:操作数据库失败,ids = {}",ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

}
