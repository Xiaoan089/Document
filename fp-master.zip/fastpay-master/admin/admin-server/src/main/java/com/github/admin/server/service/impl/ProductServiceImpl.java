package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.TbProduct;
import com.github.admin.common.entity.TbProductParams;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.ProductRequest;
import com.github.admin.common.request.TbProductParamsRequest;
import com.github.admin.server.dao.TbProductDao;
import com.github.admin.server.service.ProductParamsService;
import com.github.admin.server.service.ProductService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 产品管理
 */

@Service
@Slf4j
public class ProductServiceImpl implements ProductService {

    @Resource
    private ProductParamsService productParamsService;

    @Resource
    private TbProductDao tbProductDao;

    @Override
    public Result<TbProduct> findById(Long id) {
        if (id == null){
            log.error("根据id查询产品管理请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        TbProduct entity = tbProductDao.selectByPrimaryKey(id);
        // 获取子表数据
        TbProductParamsRequest tbProductParamsRequest = new TbProductParamsRequest();
        tbProductParamsRequest.setProductId(id);
        Result<List<TbProductParams>> result = productParamsService.selectBySelective(tbProductParamsRequest);
        if (!result.isSuccess()) {
            log.error("findById getList error,result = {}", result);
            return Result.fail(AdminErrorMsgEnum.SYSTEM_ERROR);
        }
        List<TbProductParams> subList = result.getData();
        entity.setSubList(subList);
        return Result.ok(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result save(ProductRequest request) {
        if (request == null){
            log.error("保存产品管理请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        BaseRequestUtils.createAssemble(request);
        TbProduct tbProduct = new TbProduct();
        BeanUtil.copyProperties(request, tbProduct);
        int row = tbProductDao.insertSelective(tbProduct);
        if (row == 0) {
            log.error("保存产品管理操作失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        // 保存子表数据
        request.setId(tbProduct.getId());
        Result productParamsResult = productParamsService.saveOrUpdate(request);
        if (!productParamsResult.isSuccess()) {
            log.error("保存产品管理操作失败:保存子表数据失败,request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result update(ProductRequest request) {
        if (request == null){
            log.error("修改产品管理请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        BaseRequestUtils.updateAssemble(request);
        TbProduct tbProduct = new TbProduct();
        BeanUtil.copyProperties(request,tbProduct);
        int row = tbProductDao.updateByPrimaryKeySelective(tbProduct);
        if (row == 0) {
            log.error("修改产品管理操作失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        // 更新子表数据
        Result result = productParamsService.saveOrUpdate(request);
        if (!result.isSuccess()) {
            log.error("修改产品管理操作失败:保存子表数据失败,request = {}", request);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result delete(List<Long> ids) {
        if (CollectionUtil.isEmpty(ids)){
            log.error("删除产品管理请求参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        int row = tbProductDao.delete(ids);
        if (row == 0){
            log.error("删除产品管理操作失败");
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        // 删除子表数据
        productParamsService.deleteByProductIds(ids);
        return Result.ok();
    }

    @Override
    public Result<DataPage<TbProduct>> productPage(ProductRequest request) {
        log.info("查询product日志分页参数:{}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<TbProduct> dataPage = new DataPage<TbProduct>(pageNo,pageSize);
        Map<String,Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex",dataPage.getStartIndex());
        map.put("offset",dataPage.getPageSize());
        Integer productCount = tbProductDao.findTbProductCountByPage(map);
        List<TbProduct> list = tbProductDao.findTbProductListByPage(map);
        log.info("查询product日志大小数量totalCount:{}",productCount);
        dataPage.setTotalCount(productCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }
}
