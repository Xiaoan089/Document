package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.ScheduleJobLog;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.ScheduleJobLogRequest;
import com.github.admin.server.dao.ScheduleJobLogDao;
import com.github.admin.server.service.ScheduleJobLogService;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ScheduleJobLogServiceImpl implements ScheduleJobLogService {

    @Resource
    private ScheduleJobLogDao scheduleJobLogDao;

    @Override
    public Result<DataPage<ScheduleJobLog>> page(ScheduleJobLogRequest request) {
        log.info("定时任务日志分页查询:request = {}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<ScheduleJobLog> dataPage = new DataPage<ScheduleJobLog>(pageNo, pageSize);
        Map<String, Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex", dataPage.getStartIndex());
        map.put("offset", dataPage.getPageSize());
        long userCount = scheduleJobLogDao.findUserCountByPage(map);
        List<ScheduleJobLog> list = scheduleJobLogDao.findUserListByPage(map);
        log.info("查询定时器日志大小数量totalCount:{}", userCount);
        dataPage.setTotalCount(userCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result<ScheduleJobLog> findById(Long id) {
        log.info("定时任务日志根据id查询:id = {}", id);
        if (id == null) {
            log.error("定时任务日志根据id查询请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        return Result.ok(scheduleJobLogDao.selectByPrimaryKey(id));
    }

    @Override
    public Result insert(ScheduleJobLog scheduleJobLog) {
        int row = scheduleJobLogDao.insertSelective(scheduleJobLog);
        if (row != 1) {
            log.error("定时任务新增失败:操作数据库失败,request = {}", scheduleJobLog);
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        return Result.ok();
    }

}
