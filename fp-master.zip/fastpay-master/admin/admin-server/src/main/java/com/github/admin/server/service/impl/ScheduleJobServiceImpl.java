package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;

import com.alibaba.fastjson2.JSON;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.ScheduleJob;
import com.github.admin.common.entity.ScheduleJobLog;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.ScheduleJobRequest;
import com.github.admin.common.utils.ConvertUtils;
import com.github.admin.server.dao.ScheduleJobDao;
import com.github.admin.server.dao.ScheduleJobLogDao;
import com.github.admin.server.service.ScheduleJobService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.admin.server.utils.ScheduleUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
@Slf4j
public class ScheduleJobServiceImpl implements ScheduleJobService {
    @Resource
    private Scheduler scheduler;

    @Resource
    private ScheduleJobDao scheduleJobDao;

    @Override
    public Result<DataPage<ScheduleJob>> page(ScheduleJobRequest request) {
        log.info("定时器任务分页查询:request = {}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<ScheduleJob> dataPage = new DataPage<ScheduleJob>(pageNo, pageSize);
        Map<String, Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex", dataPage.getStartIndex());
        map.put("offset", dataPage.getPageSize());
        long userCount = scheduleJobDao.findScheduleJobCountByPage(map);
        List<ScheduleJob> list = scheduleJobDao.findScheduleJobListByPage(map);
        log.info("查询定时bean大小数量totalCount:{}", userCount);
        dataPage.setTotalCount(userCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result save(ScheduleJobRequest request) {
        log.info("定时器任务新增:request = {}", request);

        request.setStatus(1);
        BaseRequestUtils.createAssemble(request);
        ScheduleJob scheduleJob = new ScheduleJob();
        BeanUtil.copyProperties(request,scheduleJob);
        int row = scheduleJobDao.insertSelective(scheduleJob);
        if (row != 1) {
            log.error("定时器任务新增失败:操作数据库失败,request = {}",scheduleJob);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        ScheduleUtils.createScheduleJob(scheduler, scheduleJob);
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result update(ScheduleJobRequest request) {
        log.info("定时器任务修改:request = {}",request);

        BaseRequestUtils.updateAssemble(request);
        ScheduleJob scheduleJob = new ScheduleJob();
        BeanUtil.copyProperties(request,scheduleJob);
        int row = scheduleJobDao.updateByPrimaryKeySelective(scheduleJob);
        if (row != 1) {
            log.error("定时器任务修改失败:操作数据库失败,request = {}",scheduleJob);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        ScheduleUtils.updateScheduleJob(scheduler, scheduleJob);
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteByIds(List<Long> ids) {
        log.info("定时器任务删除:ids = {}",ids);

        if (CollectionUtils.isEmpty(ids)) {
            log.error("定时器删除请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        //删除数据
        int row = scheduleJobDao.deleteByIds(ids);
        if (row != ids.size()) {
            log.error("定时器删除请求参数失败:操作数据库失败,ids = {}",ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        ids.forEach(id -> ScheduleUtils.deleteScheduleJob(scheduler, id));
        return Result.ok();
    }

    @Override
    public int updateBatch(List<Long> ids, int status) {
        Map<String, Object> map = new HashMap<>(2);
        map.put("ids", ids);
        map.put("status", status);
        return scheduleJobDao.updateBatch(map);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result run(List<Long> ids) {
        log.error("定时任务执行:ids = {}",ids);

        if (CollectionUtils.isEmpty(ids)){
            log.error("定时任务执行请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        for (Long id : ids) {
            ScheduleJob scheduleJob = scheduleJobDao.selectByPrimaryKey(id);
            ScheduleUtils.run(scheduler, scheduleJob);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result pause(List<Long> ids) {
        log.error("定时任务暂停:ids = {}",ids);

        if (CollectionUtils.isEmpty(ids)) {
            log.error("定时任务暂停请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        for (Long id : ids) {
            ScheduleUtils.pauseJob(scheduler, id);
        }
        updateBatch(ids, Constant.ScheduleStatus.PAUSE.getValue());
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result resume(List<Long> ids) {
        log.error("定时任务恢复:ids = {}",ids);

        if (CollectionUtils.isEmpty(ids)) {
            log.error("定时任务恢复请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        for (Long id : ids) {
            ScheduleUtils.resumeJob(scheduler, id);
        }
        updateBatch(ids, Constant.ScheduleStatus.NORMAL.getValue());
        return Result.ok();
    }

    @Override
    public Result<ScheduleJob> findById(Long id) {
        log.info("定时器根据id查询,id = {}", id);
        if (id == null) {
            log.error("定时器根据id查询请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        ScheduleJob scheduleJob = scheduleJobDao.selectByPrimaryKey(id);
        return Result.ok(scheduleJob);
    }

}
