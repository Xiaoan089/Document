/**
 * Copyright (c) 2018 人人开源 All rights reserved.
 * <p>
 * https://www.renren.io
 * <p>
 * 版权所有，侵权必究！
 */

package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.github.admin.common.constant.Constant;
import com.github.admin.common.entity.SysDept;
import com.github.admin.common.entity.SysUser;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.BaseAdminRequest;
import com.github.admin.common.request.SysDeptRequest;
import com.github.admin.common.utils.TreeUtils;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.admin.server.dao.SysDeptDao;
import com.github.admin.server.dao.SysUserDao;
import com.github.admin.server.service.SysDeptService;
import com.github.admin.server.service.SysUserService;
import com.github.framework.core.Result;
import com.github.admin.common.entity.UserDetail;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.github.admin.server.utils.BaseRequestUtils.verifyUserDetail;


@Service
@Slf4j
public class SysDeptServiceImpl implements SysDeptService {

    @Resource
    private SysUserDao sysUserDao;

    @Resource
    private SysUserService sysUserService;

    @Resource
    private SysDeptDao sysDeptDao;

    @Override
    public Result<List<SysDept>> list(SysDeptRequest request) {
        log.info("部门查询:request = {}", request);
        Result result = verifyUserDetail(request, "部门查询");
        if (!result.isSuccess()) {
            return Result.fail(result.getCode(), result.getMessage());
        }

        UserDetail userDetail = request.getUserDetail();

        SysDept sysDept = new SysDept();
        sysDept.setSysType(userDetail.getSysType());
        //普通管理员，只能查询所属部门及子部门的数据
        if (!BaseAdminRequest.isSuperAdmin(null, userDetail)) {
            List<Long> subDeptIdList = getSubDeptIdList(userDetail.getDeptId());
            sysDept.setDeptIdList(subDeptIdList);
        }

        //查询部门列表
        List<SysDept> entityList = sysDeptDao.getList(sysDept);

        return Result.ok(TreeUtils.build(entityList));
    }

    @Override
    public Result<SysDept> findByIdOnType(SysDeptRequest request) {
        log.info("部门根据id查询,request = {}", request);
        Result result = verifyUserDetail(request, "部门根据id查询");
        if (!result.isSuccess()) {
            return Result.fail(result.getCode(), result.getMessage());
        }

        Long id = request.getId();
        //超级管理员，部门ID为null
        if (id == null) {
            return Result.ok();
        }
        request.setSysType(request.getUserDetail().getSysType());
        List<SysDept> sysDeptList = sysDeptDao.selectBySelective(request);

        if (CollectionUtils.isEmpty(sysDeptList)) {
            return Result.ok();
        }
        SysDept sysDept = sysDeptList.get(0);
        return Result.ok(sysDept);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result save(SysDeptRequest request) {
        log.info("部门新增:request = {}", request);
        Result result = verifyUserDetail(request, "部门新增");
        if (!result.isSuccess()) {
            return Result.fail(result.getCode(), result.getMessage());
        }

        Integer sysType = request.getUserDetail().getSysType();
        if (request.getPid() != null && !request.getPid().equals(0)) {
            SysDept sysDept = sysDeptDao.selectByPrimaryKey(request.getPid());
            if (sysDept == null) {
                log.error("部门新增失败:父级部门不存在,request = {}", request);
                return Result.fail(AdminErrorMsgEnum.THE_PARENT_DOES_NOT_EXIST);
            }

            if (!sysType.equals(sysDept.getSysType())) {
                log.error("部门新增失败:父级部门类型与子级不一致,request = {}", request);
                return Result.fail(AdminErrorMsgEnum.THE_SYSTEM_TYPE_IS_INCONSISTENT);
            }
        }
        request.setSysType(sysType);
        BaseRequestUtils.createAssemble(request);
        request.setPids(getPidList(request.getPid()));
        SysDept sysDept = new SysDept();
        BeanUtil.copyProperties(request, sysDept);
        int row = sysDeptDao.insertSelective(sysDept);
        if (row != 1) {
            log.error("部门添加操作数据库失败:request = {}", sysDept);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result update(SysDeptRequest request) {
        log.info("部门修改:request = {}", request);
        Result result = verifyUserDetail(request, "部门修改");
        if (!result.isSuccess()) {
            return Result.fail(result.getCode(), result.getMessage());
        }

        //上级部门不能为自身
        if (request.getId().equals(request.getPid())) {
            log.error("部门修改异常:上级不能为自身,id = {},pid = {}", request.getPid(), request.getPid());
            return Result.fail(AdminErrorMsgEnum.SUPERIORS_CANNOT_BE_FOR_THEMSELVES);
        }

        //上级部门不能为下级部门
        List<Long> subDeptList = getSubDeptIdList(request.getId());
        if (subDeptList.contains(request.getPid())) {
            log.error("部门修改异常:上级部门不能为下级部门,id = {},pid = {},subDeptList = {}", request.getPid(), request.getPid(), subDeptList);
            return Result.fail(AdminErrorMsgEnum.SUPERIOR_CANNOT_BE_SUBORDINATE);
        }

        Integer sysType = request.getUserDetail().getSysType();
        Long pid = request.getPid();
        if (pid != null && pid != 0) {
            SysDept sysDept = sysDeptDao.selectByPrimaryKey(request.getPid());
            if (sysDept == null) {
                log.error("部门修改失败:父级部门不存在,request = {}", request);
                return Result.fail(AdminErrorMsgEnum.THE_PARENT_DOES_NOT_EXIST);
            }

            if (!sysType.equals(sysDept.getSysType())) {
                log.error("部门修改失败:父级部门类型与子级不一致,request = {}", request);
                return Result.fail(AdminErrorMsgEnum.THE_SYSTEM_TYPE_IS_INCONSISTENT);
            }
        }

        request.setPids(getPidList(request.getPid()));
        request.setSysType(request.getUserDetail().getSysType());
        BaseRequestUtils.updateAssemble(request);
        SysDept sysDept = new SysDept();
        BeanUtil.copyProperties(request, sysDept);
        int row = sysDeptDao.updateByPrimaryKeySelective(sysDept);
        if (row != 1) {
            log.error("部门修改异常:request = {}", sysDept);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result deleteByIds(SysDeptRequest sysDeptRequest) {
        log.info("部门根据id删除:request = {}", sysDeptRequest);
        Result result = verifyUserDetail(sysDeptRequest, "部门删除");
        if (!result.isSuccess()) {
            return Result.fail(result.getCode(), result.getMessage());
        }

        Long id = sysDeptRequest.getId();
        if (id == null) {
            log.error("部门根据id删除异常:请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_ERROR);
        }

        Integer sysType = sysDeptRequest.getUserDetail().getSysType();
        sysDeptRequest.setSysType(sysType);
        SysDept sysDept = new SysDept();
        //判断是否有子部门
        List<Long> subList = getSubDeptIdList(id);
        if (subList.size() > 1) {
            log.error("部门根据id删除异常:请先删除子级,id = {}",id);
            return Result.fail(AdminErrorMsgEnum.PLEASE_DELETE_THE_SUBMENU_FIRST);
        }

        //判断部门下面是否有用户
        int count = sysUserDao.getCountByDeptId(id);
        if (count > 0) {
            log.error("部门根据id删除异常:请先删除子级用户,id = {}",id);
            return Result.fail(AdminErrorMsgEnum.DELETE_SUBUSERS_FIRST);
        }

        //删除
        BeanUtil.copyProperties(sysDeptRequest, sysDept);
        int row = sysDeptDao.deleteByIdOnType(sysDept);
        if (row != 1){
            log.error("部门根据id删除异常:操作数据库异常,id = {}",id);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }


    public Result<SysDept> findById(Long id) {
        //超级管理员，部门ID为null
        if (id == null) {
            return Result.ok();
        }

        SysDept entity = sysDeptDao.getById(id);
        if (entity.getLeaderId() != null) {
            Result<SysUser> sysUserEntityResult = sysUserService.findById(entity.getLeaderId());
            if (!sysUserEntityResult.isSuccess()) {
                log.error("sysDeptService get fail, id:{}", id);
                return Result.ok(entity);
            }
            SysUser sysUser = sysUserEntityResult.getData();
            if (sysUser != null) {
                entity.setLeaderName(sysUser.getRealName());
            }
        }
        return Result.ok(entity);
    }


    @Override
    public List<Long> getSubDeptIdList(Long id) {
        List<Long> deptIdList = sysDeptDao.getSubDeptIdList("%" + id + "%");
        deptIdList.add(id);

        return deptIdList;
    }


    /**
     * 获取所有上级部门ID
     *
     * @param pid 上级ID
     */
    private String getPidList(Long pid) {
        //顶级部门，无上级部门
        if (Constant.DEPT_ROOT.equals(pid)) {
            return Constant.DEPT_ROOT + "";
        }

        //所有部门的id、pid列表
        List<SysDept> deptList = sysDeptDao.getIdAndPidList();

        //list转map
        Map<Long, SysDept> map = new HashMap<>(deptList.size());
        for (SysDept entity : deptList) {
            map.put(entity.getId(), entity);
        }

        //递归查询所有上级部门ID列表
        List<Long> pidList = new ArrayList<>();
        getPidTree(pid, map, pidList);

        return StringUtils.join(pidList, ",");
    }

    private void getPidTree(Long pid, Map<Long, SysDept> map, List<Long> pidList) {
        //顶级部门，无上级部门
        if (Constant.DEPT_ROOT.equals(pid)) {
            return;
        }

        //上级部门存在
        SysDept parent = map.get(pid);
        if (parent != null) {
            getPidTree(parent.getPid(), map, pidList);
        }

        pidList.add(pid);
    }
}
