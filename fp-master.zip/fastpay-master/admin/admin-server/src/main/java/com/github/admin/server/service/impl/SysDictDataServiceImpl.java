package com.github.admin.server.service.impl;
import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.SysDictData;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.SysDictDataRequest;
import com.github.admin.server.dao.SysDictDataDao;
import com.github.admin.server.service.SysDictDataService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class SysDictDataServiceImpl implements SysDictDataService {

    @Resource
    private SysDictDataDao sysDictDataDao;

    @Override
    public Result<DataPage<SysDictData>> page(SysDictDataRequest request) {
        log.info("字典数据查询分页,request = {}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<SysDictData> dataPage = new DataPage<SysDictData>(pageNo,pageSize);
        Map<String,Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex",dataPage.getStartIndex());
        map.put("offset",dataPage.getPageSize());
        long dictDataCount = sysDictDataDao.findSysDictCountByPage(map);
        List<SysDictData> list = sysDictDataDao.findSysDictListByPage(map);
        log.info("查询字典类型大小数量totalCount:{}",dictDataCount);
        dataPage.setTotalCount(dictDataCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public List<SysDictData> getDictDataList() {
        return sysDictDataDao.getDictDataList();
    }

    @Override
    public Result deleteByDictTypeIds(List<Long> dictTypeIds) {
        log.info("字典数据删除,dictTypeIds = {}",dictTypeIds);
        if (CollectionUtils.isEmpty(dictTypeIds)) {
            log.error("字典数据删除,请求参数dictTypeIds为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = sysDictDataDao.deleteByDictTypeIds(dictTypeIds);
        if (row == 0) {
            log.error("字典数据删除:操作数据库失败,dictTypeIds = {}",dictTypeIds);
        }
        return Result.ok();
    }

    @Override
    public Result<SysDictData> findById(Long id) {
        log.info("字典数据查询,id = {}",id);
        if (id == null) {
            log.error("字典数据根据id查询,请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        SysDictData sysDictData = sysDictDataDao.selectByPrimaryKey(id);
        return Result.ok(sysDictData);
    }

    @Override
    public Result save(SysDictDataRequest request) {
        log.info("字典数据新增,request = {}",request);
        BaseRequestUtils.createAssemble(request);
        SysDictData sysDictData = new SysDictData();
        BeanUtil.copyProperties(request,sysDictData);
        int row = sysDictDataDao.insertSelective(sysDictData);
        if (row != 1){
            log.error("字典数据新增失败:操作数据库失败,request = {}",sysDictData);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result update(SysDictDataRequest request) {
        log.info("字典数据修改,request = {}",request);
        BaseRequestUtils.updateAssemble(request);
        SysDictData sysDictData = new SysDictData();
        BeanUtil.copyProperties(request,sysDictData);
        int row = sysDictDataDao.insertSelective(sysDictData);
        if (row != 1){
            log.error("字典数据修改失败:操作数据库失败,request = {}",sysDictData);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result delete(List<Long> ids) {
        log.info("字典数据删除,ids = {}",ids);
        if (CollectionUtils.isEmpty(ids)) {
            log.error("字典数据删除,请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = sysDictDataDao.deleteByIds(ids);
        if (row != ids.size()) {
            log.error("字典数据删除:操作数据库失败,ids = {}",ids);
        }
        return Result.ok();
    }

}
