package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.SysDictData;
import com.github.admin.common.entity.SysDictType;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.SysDictTypeRequest;
import com.github.admin.server.dao.SysDictTypeDao;
import com.github.admin.server.service.SysDictDataService;
import com.github.admin.server.service.SysDictTypeService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.exception.Ex;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SysDictTypeServiceImpl implements SysDictTypeService {

    @Resource
    private SysDictDataService sysDictDataService;

    @Resource
    private SysDictTypeDao sysDictTypeDao;

    @Override
    public Result<DataPage<SysDictType>> page(SysDictTypeRequest request) {
        log.info("字典类型分页:request={}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<SysDictType> dataPage = new DataPage<SysDictType>(pageNo, pageSize);
        Map<String, Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex", dataPage.getStartIndex());
        map.put("offset", dataPage.getPageSize());
        long dictTypeCount = sysDictTypeDao.findSysDictTypeCountByPage(map);
        List<SysDictType> list = sysDictTypeDao.findSysDictTypeListByPage(map);
        log.info("查询字典类型大小数量totalCount:{}", dictTypeCount);
        dataPage.setTotalCount(dictTypeCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result<List<SysDictType>> getAllList() {
        List<SysDictType> typeList = sysDictTypeDao.getDictTypeList();
        List<SysDictData> dataList = sysDictDataService.getDictDataList();
        for (SysDictType type : typeList) {
            List<SysDictData> filterList = dataList.stream().filter(d -> d.getDictTypeId().equals(type.getId())).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(filterList)) {
                continue;
            }
            type.getDataList().addAll(filterList);
        }
        return Result.ok(typeList);
    }

    @Override
    public List<SysDictType> getDictTypeList() {
        return sysDictTypeDao.getDictTypeList();
    }

    @Override
    public Result<SysDictType> findById(Long id) {
        log.info("字典类型根据id查询:id = {}", id);
        if (id == null) {
            log.error("字典类型根据id查询:请求参数id为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_ERROR);
        }

        SysDictType sysDictType = sysDictTypeDao.selectByPrimaryKey(id);
        return Result.ok(sysDictType);
    }

    @Override
    public Result save(SysDictTypeRequest request) {
        log.info("字典类型新增:request={}", request);

        BaseRequestUtils.createAssemble(request);
        SysDictType sysDictType = new SysDictType();
        BeanUtil.copyProperties(request, sysDictType);
        int row = sysDictTypeDao.insertSelective(sysDictType);
        if (row != 1) {
            log.error("字典类型新增失败:操作数据库失败,request = {}", sysDictType);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    public Result update(SysDictTypeRequest request) {
        log.info("字典类型修改:request={}", request);

        BaseRequestUtils.updateAssemble(request);
        SysDictType sysDictType = new SysDictType();
        BeanUtil.copyProperties(request, sysDictType);
        int row = sysDictTypeDao.updateByPrimaryKeySelective(sysDictType);
        if (row != 1) {
            log.error("字典类型修改失败:操作数据库失败,request = {}", sysDictType);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result delete(List<Long> ids) {
        log.info("字典类型删除:ids={}", ids);

        if (CollectionUtils.isEmpty(ids)) {
            log.error("字典类型删除请求参数ids为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }

        int row = sysDictTypeDao.deleteByIds(ids);
        if (row != ids.size()) {
            log.error("字典类型删除失败:操作数据库失败,ids = {}", ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }

        Result result = sysDictDataService.deleteByDictTypeIds(ids);
        if (!result.isSuccess()) {
            log.error("字典类型删除失败:删除字典数据失败,ids = {}",ids);
            throw Ex.business(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

}
