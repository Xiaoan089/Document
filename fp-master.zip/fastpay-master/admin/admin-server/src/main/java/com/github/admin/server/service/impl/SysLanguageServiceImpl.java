package com.github.admin.server.service.impl;

import com.github.admin.common.entity.SysLanguage;
import com.github.admin.server.dao.SysLanguageDao;
import com.github.admin.server.service.SysLanguageService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class SysLanguageServiceImpl implements SysLanguageService {

    @Resource
    private SysLanguageDao sysLanguageDao;

    @Override
    public void saveOrUpdate(SysLanguage sysLanguage) {
        //判断是否有数据
        if(sysLanguageDao.getLanguage(sysLanguage) == null){
            sysLanguageDao.insert(sysLanguage);
        }else {
            sysLanguageDao.updateLanguage(sysLanguage);
        }
    }

    @Override
    public void deleteLanguage(String tableName, Long tableId) {
        sysLanguageDao.deleteLanguage(tableName, tableId);
    }
}
