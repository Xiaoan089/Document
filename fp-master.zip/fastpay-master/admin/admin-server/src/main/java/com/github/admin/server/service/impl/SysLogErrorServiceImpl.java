package com.github.admin.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson2.JSON;
import com.github.admin.common.entity.SysLogError;
import com.github.admin.common.enums.AdminErrorMsgEnum;
import com.github.admin.common.request.SysLogErrorRequest;
import com.github.admin.server.dao.SysLogErrorDao;
import com.github.admin.server.service.SysLogErrorService;
import com.github.admin.server.utils.BaseRequestUtils;
import com.github.framework.core.Result;
import com.github.framework.core.page.DataPage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 异常日志
 */
@Service
@Slf4j
public class SysLogErrorServiceImpl implements SysLogErrorService {

    @Resource
    private SysLogErrorDao sysLogErrorDao;

    @Override
    public Result<DataPage<SysLogError>> sysLogErrorPage(SysLogErrorRequest request) {
        log.info("查询异常日志列表分页参数为:{}", JSON.toJSONString(request));
        Integer pageNo = request.getPageNo();
        Integer pageSize = request.getPageSize();
        DataPage<SysLogError> dataPage = new DataPage<SysLogError>(pageNo,pageSize);
        if(StringUtils.isBlank(request.getAsc()) || StringUtils.isBlank(request.getOrderByColumn())){
            request.setOrderByColumn("create_date");
            request.setAsc("desc");
        }
        Map<String,Object> map = BeanUtil.beanToMap(request);
        map.put("startIndex",dataPage.getStartIndex());
        map.put("offset",dataPage.getPageSize());
        Integer errorCount = sysLogErrorDao.findSysLogErrorCountByPage(map);
        List<SysLogError> list = sysLogErrorDao.findSysLogErrorListByPage(map);
        log.info("查询异常日志大小数量totalCount:{}",errorCount);
        dataPage.setTotalCount(errorCount);
        dataPage.setDataList(list);
        return Result.ok(dataPage);
    }

    @Override
    public Result<List<SysLogError>> selectListSelective(Map<String, Object> params) {
        List<SysLogError> entityList = sysLogErrorDao.selectList();
        return Result.ok(entityList);
    }

    @Override
    public Result save(SysLogErrorRequest request) {
        if (request == null){
            log.error("保存异常日志失败，参数为空");
            return Result.fail(AdminErrorMsgEnum.REQUEST_PARAMS_EMPTY);
        }
        BaseRequestUtils.createAssemble(request);
        SysLogError sysLogError = new SysLogError();
        BeanUtil.copyProperties(request,sysLogError);
        int row = sysLogErrorDao.insertSelective(sysLogError);
        if (row == 0){
            log.error("保存异常日志失败，参数为:{}",request);
            return Result.fail(AdminErrorMsgEnum.OPERATION_FAIL);
        }
        return Result.ok();
    }

}
